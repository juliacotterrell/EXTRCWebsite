/*
 * File: FormulaServiceImplTest.java
 * Package: com.extrc.services
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Part of EXTRC project supporting rational closure reasoning.
 * Purpose: Educational use only.
 * To run: mvn -Dtest=FormulaServiceImplTest test
 */
package com.extrc.services;

import com.extrc.controllers.FormulaController;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.tweetyproject.logics.pl.syntax.PlFormula;
import org.tweetyproject.logics.pl.syntax.Proposition;
import com.extrc.models.DefeasibleImplication;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(FormulaController.class)
public class FormulaServiceImplTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private FormulaServiceImpl formulaService;

    /** 
     * @throws Exception
     */
    @Test
    public void testGetQueryFormula() throws Exception {

        PlFormula result = formulaService.getQueryFormula();
        Proposition p = new Proposition("p");
        Proposition w = new Proposition("w");
        PlFormula expectedDefault = new DefeasibleImplication(p, w);
        mockMvc.perform(get("/api/formula/query"))
               .andExpect(status().isOk());
    }
}
