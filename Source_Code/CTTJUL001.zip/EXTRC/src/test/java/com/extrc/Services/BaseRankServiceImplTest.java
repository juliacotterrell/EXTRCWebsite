/*
 * File: BaseRankServiceImplTest.java
 * Package: com.extrc.services
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Part of EXTRC project supporting rational closure reasoning.
 * Purpose: Educational use only.
 * To run: mvn -Dtest=BaseRankServiceImplTest test
 */

// src/test/java/com/extrc/services/BaseRankServiceImplTest.java
package com.extrc.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;


import com.extrc.models.KnowledgeBase;

import com.extrc.utils.DefeasibleParser;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.InputStream;
@SpringBootTest

public class BaseRankServiceImplTest {

    @Autowired
    private BaseRankService   baseRankService;

    @Autowired
    private DefeasibleParser  parser;

    @Test
    public void testWithEmptyKnowledgeBase() {
        KnowledgeBase kb = new KnowledgeBase();
        var baseRank = baseRankService.constructBaseRank(kb);

        assertNotNull(baseRank, "BaseRank should not be null for empty KB");
        assertEquals(0, baseRank.getSequence().size(), "Empty KB → zero sequence levels");

        var ranking = baseRank.getRanking();
        assertTrue(
            ranking.get(ranking.size() - 1).getFormulas().isEmpty(),
            "Empty KB → last (infinite) rank must have no formulas"
        );
    }

    /** 
     * @throws Exception
     */
    @Test
    public void testWithPenguinsKnowledgeBase() throws Exception {
        InputStream is = getClass().getClassLoader().getResourceAsStream("kb1.txt");
        assertNotNull(is, "kb1.txt must be on the test classpath");
        KnowledgeBase kb = parser.parseInputStream(is);
        var baseRank = baseRankService.constructBaseRank(kb);

        assertNotNull(baseRank);
        // sequence levels
        assertEquals(3, baseRank.getSequence().size());
        assertEquals(3, baseRank.getSequence().get(0).getFormulas().size());
        assertEquals(1, baseRank.getSequence().get(1).getFormulas().size());
        assertEquals(0, baseRank.getSequence().get(2).getFormulas().size());

        // ranking levels
        assertEquals(3, baseRank.getRanking().size());
        assertEquals(2, baseRank.getRanking().get(0).getFormulas().size());
        assertEquals(1, baseRank.getRanking().get(1).getFormulas().size());
        assertEquals(1, baseRank.getRanking().get(2).getFormulas().size());
    }

    /** 
     * @throws Exception
     */
    @Test
    public void testRanks10() throws Exception {
        InputStream is = getClass().getClassLoader().getResourceAsStream("ranks10.txt");
        assertNotNull(is, "ranks10.txt must be on the test classpath");
        KnowledgeBase kb = parser.parseInputStream(is);
        var baseRank = baseRankService.constructBaseRank(kb);

        assertNotNull(baseRank);
        assertEquals(11, baseRank.getSequence().size());
        assertEquals(11, baseRank.getRanking().size());
    }
}
