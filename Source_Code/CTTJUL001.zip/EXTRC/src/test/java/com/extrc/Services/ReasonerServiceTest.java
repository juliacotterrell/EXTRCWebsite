/*
 * File: ReasonerServiceTest.java
 * Package: com.extrc.services
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Part of EXTRC project supporting rational closure reasoning.
 * Purpose: Educational use only.
 * To run: mvn -Dtest=ReasonerServiceTest test
 */

// src/test/java/com/extrc/services/ReasonerServiceIntegrationTest.java
package com.extrc.services;

import com.extrc.models.KnowledgeBase;

import com.extrc.models.BaseRank;
import com.extrc.utils.DefeasibleParser;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import org.tweetyproject.logics.pl.syntax.PlFormula;

import java.io.InputStream;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class ReasonerServiceTest {

    @Autowired
    private ReasonerFactory   reasonerFactory;

    @Autowired
    private BaseRankService   baseRankService;

    @Autowired
    private DefeasibleParser  parser;

    /** 
     * @param resourceName
     * @return KnowledgeBase
     * @throws Exception
     */
    private KnowledgeBase loadKb(String resourceName) throws Exception {
        InputStream is = getClass().getClassLoader().getResourceAsStream(resourceName);
        assertNotNull(is, resourceName + " resource is missing");
        return parser.parseInputStream(is);
    }

    /** 
     * @throws Exception
     */
    @Test
    public void testRationalPenguinsKb() throws Exception {
        KnowledgeBase kb   = loadKb("kb1.txt");
        BaseRank     br    = baseRankService.constructBaseRank(kb);
        ReasonerService rational = reasonerFactory.createReasoner("rational");

        List<PlFormula> queries = List.of(
            parser.parseFormula("p ~> f"),
            parser.parseFormula("p ~> w"),
            parser.parseFormula("p ~> !f")
        );
        List<Boolean> expected = List.of(false, false, true);

        for (int i = 0; i < queries.size(); i++) {
            boolean entailed = rational.getEntailment(br, queries.get(i)).getEntailed();
            assertEquals(expected.get(i), entailed,
                "Rational entailment mismatch for query: " + queries.get(i));
        }
    }

    /** 
    //  * @throws Exception
    //  */
}
