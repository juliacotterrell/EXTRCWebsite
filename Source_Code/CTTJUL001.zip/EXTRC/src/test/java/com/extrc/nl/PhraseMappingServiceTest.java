/*
 * File: PhraseMappingServiceTest.java
 * Package: com.extrc.nl
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Part of EXTRC project supporting rational closure reasoning.
 * Purpose: Educational use only.
 * To run: mvn -Dtest=PhraseMappingServiceTest test
 */

// // src/test/java/com/extrc/services/PhraseMappingServiceTest.java

package com.extrc.nl;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = PhraseMappingServiceTest.TestConfig.class)
class PhraseMappingServiceTest {

  @Configuration
  @Import(PhraseMappingService.class) 
  static class TestConfig { }

  @Autowired PhraseMappingService svc;

  @Test
  void decodesAtoms() {
    String out = svc.decodeProposition("ab", 0);
    assertNotNull(out);
    assertFalse(out.isBlank());
  }
}
