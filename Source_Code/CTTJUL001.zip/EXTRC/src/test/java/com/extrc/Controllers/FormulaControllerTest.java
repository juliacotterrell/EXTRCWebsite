/*
 * File: FormulaControllerTest.java
 * Package: com.extrc.controllers
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Part of EXTRC project supporting rational closure reasoning.
 * Purpose: Educational use only.
 * To run: mvn -Dtest=FormulaControllerTest test
 */

package com.extrc.controllers;

import com.extrc.services.FormulaService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.tweetyproject.logics.pl.syntax.Proposition;
import com.extrc.config.ObjectMapperConfig;
import org.springframework.context.annotation.Import;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(FormulaController.class)
@Import(ObjectMapperConfig.class)
public class FormulaControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private FormulaService formulaService;

    /**
     * @throws Exception
     */
    @Test
    public void testGetQueryFormula() throws Exception {
        Mockito.when(formulaService.getQueryFormula()).thenReturn(new Proposition("b"));

        mockMvc.perform(get("/api/formula/query"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.queryFormula").exists());
    }

    /**
     * @throws Exception
     */
    @Test
    public void testCreateQueryFormula_valid() throws Exception {
        String formula = "a ~> b";

        mockMvc.perform(post("/api/formula/query/{queryFormula}", formula))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.queryFormula").exists());
    }

    /**
     * @throws Exception
     */
    @Test
    public void testCreateQueryFormula_invalidSyntax() throws Exception {
        String formula = "a ~>"; // Invalid formula

        mockMvc.perform(post("/api/formula/query/{queryFormula}", formula))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(containsString("Invalid formula")));
    }

    /**
     * @throws Exception
     */
    @Test
    public void testCreateQueryFormula_notDefeasible() throws Exception {
        String formula = "a && b"; // Not a defeasible implication

        mockMvc.perform(post("/api/formula/query/{queryFormula}", formula))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("Formula is not defeasible implication."));
    }
}
