/*
 * File: KnowledgeBaseServiceImplTest.java
 * Package: com.extrc.services
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Part of EXTRC project supporting rational closure reasoning.
 * Purpose: Educational use only.
 * To run: mvn -Dtest=KnowledgeBaseServiceImplTest test
 */


package com.extrc.services;

import com.extrc.controllers.KnowledgeBaseController;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import static org.junit.jupiter.api.Assertions.*;
import com.extrc.models.KnowledgeBase;



@WebMvcTest(KnowledgeBaseController.class)
public class KnowledgeBaseServiceImplTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private KnowledgeBaseServiceImpl kbService;

    /** 
     * @throws Exception
     */
    @Test
    public void testGetKnowledgeBase() throws Exception {
        KnowledgeBaseServiceImpl svc = new KnowledgeBaseServiceImpl();
        KnowledgeBase kb = svc.getKnowledgeBase();
        assertNotNull(kb, "KnowledgeBase should not be null");
        assertEquals(4, kb.size(),
            "Default KnowledgeBase should contain exactly 4 formulas");
    }
}
