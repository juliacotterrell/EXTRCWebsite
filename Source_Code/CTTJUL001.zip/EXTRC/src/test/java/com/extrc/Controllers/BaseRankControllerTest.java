/*
 * File: BaseRankControllerTest.java
 * Package: com.extrc.controllers
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Part of EXTRC project supporting rational closure reasoning.
 * Purpose: Educational use only.
 * To run: mvn -Dtest=BaseRankControllerTest test
 */

package com.extrc.controllers;

import com.extrc.models.KnowledgeBase;
import com.extrc.services.BaseRankService;
import com.extrc.dtos.KnowledgeBaseDTO;
import com.extrc.models.BaseRank;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.List;

@WebMvcTest(BaseRankController.class)
public class BaseRankControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BaseRankService baseRankService;

    @Autowired
    private ObjectMapper objectMapper;
    /** 
     * @throws Exception
     */
    // testing returning a base rank from a valid knowledge base
    @Test

    public void testValidKnowledgeBaseReturnsBaseRank() throws Exception {
        KnowledgeBaseDTO kbDto = new KnowledgeBaseDTO();
        kbDto.setFormulas(List.of("p => b", "b ~> f"));

        BaseRank mockRank = new BaseRank();
        when(baseRankService.constructBaseRank(any(KnowledgeBase.class))).thenReturn(mockRank);

        mockMvc.perform(post("/api/base-rank")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(kbDto)))
                .andExpect(status().isOk());
    }

    /** 
     * @throws Exception
     */
    // testing returning a base rank from an invalid knowledge base
    @Test
    public void testInvalidKnowledgeBaseReturnsBadRequest() throws Exception {
        KnowledgeBase kb = new KnowledgeBase();
        when(baseRankService.constructBaseRank(kb)).thenThrow(new RuntimeException("Invalid"));

        mockMvc.perform(post("/api/base-rank")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(kb)))
                .andExpect(status().isBadRequest());
    }
}
