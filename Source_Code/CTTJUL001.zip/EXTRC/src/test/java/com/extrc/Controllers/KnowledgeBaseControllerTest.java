/*
 * File: KnowledgeBaseControllerTest.java
 * Package: com.extrc.controllers
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Part of EXTRC project supporting rational closure reasoning.
 * Purpose: Educational use only.
 * To run: mvn -Dtest=KnowledgeBaseControllerTest test
 */

package com.extrc.controllers;

import com.extrc.models.KnowledgeBase;
import com.extrc.services.KnowledgeBaseService;
import com.extrc.config.ObjectMapperConfig;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.context.annotation.Import;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.springframework.http.MediaType;
import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;



@WebMvcTest(KnowledgeBaseController.class)
@Import(ObjectMapperConfig.class)
public class KnowledgeBaseControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private KnowledgeBaseService kbService;
    /** 
     * @throws Exception
     */
    // testing getting a knowledge base
    @Test
    public void testGetKnowledgeBase() throws Exception {
        Mockito.when(kbService.getKnowledgeBase()).thenReturn(new KnowledgeBase());

        mockMvc.perform(get("/api/knowledge-base"))
                .andExpect(status().isOk());
    }
    /** 
     * @throws Exception
     */
    // testing creating a valid knowledge base
    @Test
    public void testCreateKb_valid() throws Exception {
        String json = "{\"formulas\": [\"a ~> b\", \"b ~> c\"]}";

        doNothing().when(kbService).setKnowledgeBase(org.mockito.ArgumentMatchers.any());

        mockMvc.perform(post("/api/knowledge-base/create-knowledge-base")  
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
                .andExpect(status().isOk());
    }
    /** 
     * @throws Exception
     */
    // testing creating a valid knowledge base using a file
    @Test
    public void testCreateKbFromFile_validFile() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "kb.txt", "text/plain", "a ~> b\nb ~> c".getBytes());

        mockMvc.perform(multipart("/api/knowledge-base/file").file(file))
                .andExpect(status().isOk());
    }
    /** 
     * @throws Exception
     */
    // testing creating a knowledge base from a missing file
    @Test
    public void testCreateKbFromFile_missingFile() throws Exception {
        mockMvc.perform(multipart("/api/knowledge-base/file"))
                .andExpect(status().isBadRequest());
    }
}
