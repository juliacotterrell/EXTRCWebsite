/*
 * File: ReasonerControllerTest.java
 * Package: com.extrc.controllers
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Part of EXTRC project supporting rational closure reasoning.
 * Purpose: Educational use only.
 * To run: mvn -Dtest=ReasonerControllerTest test
 */
package com.extrc.controllers;

import com.extrc.config.ObjectMapperConfig;
import com.extrc.dtos.BaseRankDTO;
import com.extrc.models.BaseRank;
import com.extrc.models.RationalEntailment;
import com.extrc.services.ReasonerFactory;
import com.extrc.services.ReasonerService;
import com.extrc.services.BaseRankServiceImpl;
import com.extrc.utils.DefeasibleParser;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.tweetyproject.logics.pl.syntax.PlFormula;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import org.springframework.boot.test.mock.mockito.SpyBean;
import static org.mockito.Mockito.doThrow;

@WebMvcTest(ReasonerController.class)
@Import({ 
    ObjectMapperConfig.class,      // your Jackson config
    DefeasibleParser.class,        // real parser bean
    BaseRankServiceImpl.class      // real base‐rank service bean
})
public class ReasonerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ReasonerFactory reasonerFactory;

    @MockBean
    private ReasonerService reasonerService;

    @SpyBean
    private DefeasibleParser parser;



    /** 
     * @throws Exception
     */
    @Test
    public void testGetEntailmentSuccess() throws Exception {
        String reasoner     = "rational";
        String queryFormula = "p~>!f";

        // build payload
        BaseRankDTO dto = new BaseRankDTO();
        dto.setKnowledgeBase(List.of("p => b", "b ~> f", "b ~> w", "p ~> !f"));
        dto.setRanking(List.of());
        dto.setSequence(List.of());
        dto.setTimeTaken(0.1);
        String json = new ObjectMapper().writeValueAsString(dto);

        // stub factory -> service
        when(reasonerFactory.createReasoner(reasoner))
            .thenReturn(reasonerService);

        // stub service -> entailment result
        RationalEntailment mockEntailment = RationalEntailment.builder()
            .withEntailed(true)
            .withTimeTaken(0.1)
            .build();
        when(reasonerService.getEntailment(
                any(BaseRank.class),
                any(PlFormula.class)))
            .thenReturn(mockEntailment);

        mockMvc.perform(post("/api/entailment/{reasoner}/{queryFormula}", reasoner, queryFormula)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.entailed").value(true))
            .andExpect(jsonPath("$.timeTaken").value(0.1));
    }
    /** 
     * @throws Exception
     */
    @Test
    public void testGetEntailmentSuccessFromFile() throws Exception {
        String reasoner     = "rational";
        String queryFormula = "p~>!f";

        // — — — — — Read the KB from src/test/resources/kb1.txt — — — — — 
        InputStream is = 
            getClass().getClassLoader().getResourceAsStream("kb1.txt");
        // fail early if resource missing
        assert is != null : "Could not find kb1.txt in test resources";
        List<String> kbLines;
        try (BufferedReader reader = new BufferedReader(
                 new InputStreamReader(is, StandardCharsets.UTF_8))) {
            kbLines = reader.lines().collect(Collectors.toList());
        }

        // build payload from the file
        BaseRankDTO dto = new BaseRankDTO();
        dto.setKnowledgeBase(kbLines);
        dto.setRanking(List.of());
        dto.setSequence(List.of());
        dto.setTimeTaken(0.1);
        String json = new ObjectMapper().writeValueAsString(dto);

        // stub factory → service
        when(reasonerFactory.createReasoner(reasoner))
            .thenReturn(reasonerService);

        // stub service → entailment result
        RationalEntailment mockEntailment = RationalEntailment.builder()
            .withEntailed(true)
            .withTimeTaken(0.1)
            .build();
        when(reasonerService.getEntailment(
                any(BaseRank.class),
                any(PlFormula.class)))
            .thenReturn(mockEntailment);

        // exercise endpoint
        mockMvc.perform(post("/api/entailment/{reasoner}/{queryFormula}", reasoner, queryFormula)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.entailed").value(true))
            .andExpect(jsonPath("$.timeTaken").value(0.1));
    }
    /** 
     * @throws Exception
     */
    @Test
    public void testGetEntailmentInvalidReasoner() throws Exception {
        String reasonerType      = "invalid";
        String badFormula    = "p ~> w";

        // load KB from src/test/resources/kb1.txt
        InputStream is = getClass().getClassLoader().getResourceAsStream("kb1.txt");
        assert is != null : "kb1.txt resource is missing";
        List<String> kbLines;
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(is, StandardCharsets.UTF_8))) {
            kbLines = reader.lines().collect(Collectors.toList());
        }

        // build DTO
        BaseRankDTO dto = new BaseRankDTO();
        dto.setKnowledgeBase(kbLines);
        dto.setRanking(List.of());
        dto.setSequence(List.of());
        dto.setTimeTaken(0.1);
        String json = new ObjectMapper().writeValueAsString(dto);

        // stub the factory (service won't actually be called)
        when(reasonerFactory.createReasoner(reasonerType))
        .thenThrow(new IllegalArgumentException("Invalid reasoner: " + reasonerType));

        // perform request with invalid formula
        mockMvc.perform(post("/api/entailment/{reasoner}/{queryFormula}", reasonerType, badFormula)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
            .andExpect(status().isBadRequest());
    }
    /** 
     * @throws Exception
     */
    @Test
    public void testGetEntailmentInvalidQuery() throws Exception {
        String reasoner    = "rational";
        String badFormula  = "p ~> w";

        // — — load KB from src/test/resources/kb1.txt — —
        InputStream is = getClass().getClassLoader().getResourceAsStream("kb1.txt");
        assert is != null : "kb1.txt resource is missing";
        List<String> kbLines;
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(is, StandardCharsets.UTF_8))) {
            kbLines = reader.lines().collect(Collectors.toList());
        }

        // build the DTO
        BaseRankDTO dto = new BaseRankDTO();
        dto.setKnowledgeBase(kbLines);
        dto.setRanking(List.of());
        dto.setSequence(List.of());
        dto.setTimeTaken(0.1);
        String json = new ObjectMapper().writeValueAsString(dto);

        // stub factory -> service
        when(reasonerFactory.createReasoner(reasoner))
            .thenReturn(reasonerService);

        // force parser.parseFormula(...) to throw for bad formula
        doThrow(new IllegalArgumentException("Invalid query formula: " + badFormula))
            .when(parser).parseFormula(badFormula);

        // exercise the endpoint & assert 400 + correct error message
        mockMvc.perform(post("/api/entailment/{reasoner}/{queryFormula}", reasoner, badFormula)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.message")
                .value("Invalid query formula: " + badFormula));
    }

}
