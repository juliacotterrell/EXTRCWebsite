// src/lib.utils.ts
/*
 * File: utils.ts
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: TypeScript utility functions used across the EXTRC frontend.
 * Purpose: Educational use only.
 */

import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

/**
 * cn
 * ---
 * Utility function for combining Tailwind CSS class names.
 * Uses `clsx` for conditional className handling and merges conflicts
 * (e.g., `p-2` vs `p-4`) with `tailwind-merge`.
 *
 * @param inputs - class names, booleans, arrays, or objects
 * @returns merged className string
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * RankingLevel
 * -------------
 * A TypeScript type representing a single rank in the base ranking.
 * - `rankNumber`: numeric index of the rank (0, 1, 2, … or ∞).
 * - `formulas`: the formulas belonging to this rank.
 */
export interface RankingLevel {
  rankNumber: number;
  formulas: string[];
}

/**
 * computeBaseRanking
 * -------------------
 * Implements the **Base Rank Algorithm** used in Rational Closure.
 *
 * Input:
 *  - `materializedKB`: the initial knowledge base (𝒦), represented as an array of
 *    strings of the form "α -> β".
 *  - `entailsFn`: a classical entailment checker (function that decides whether
 *    a KB entails a given formula).
 *
 * Algorithm:
 *  1. Start with E₀ = 𝒦 (the full knowledge base).
 *  2. Identify formulas in Eᵢ that are "exceptional": i.e., whose antecedents (α)
 *     are inconsistent with Eᵢ (Eᵢ ⊨ ¬α).
 *  3. Move those formulas to rank Rᵢ.
 *  4. Repeat with the remainder (Eᵢ₊₁).
 *  5. If no more exceptions exist, stop. Any leftovers go to rank ∞.
 *
 * Output:
 *  - An array of RankingLevel objects, each containing the formulas at that rank.
 *
 * @param materializedKB - the initial KB (E₀)
 * @param entailsFn - entailment checker: (KB, formula) -> boolean
 * @returns RankingLevel[] - the computed ranking
 */
export function computeBaseRanking(
  materializedKB: string[],
  entailsFn: (KB: string[], formula: string) => boolean
): RankingLevel[] {
  const K = [...materializedKB];       // copy of initial KB
  const levels: RankingLevel[] = [];   // output array of ranks
  let Ei = [...K];                     // current Eᵢ
  let i = 0;

  while (true) {
    // Formulas whose antecedents are inconsistent in Eᵢ
    const EiPlus1 = Ei.filter(f => {
      const α = extractAntecedent(f);
      return entailsFn(Ei, `¬(${α})`);
    });

    // Rᵢ = all other formulas
    const Ri = Ei.filter(f => !EiPlus1.includes(f));

    if (Ri.length === 0) break; // stop if no formulas are exceptional at this level

    levels.push({ rankNumber: i, formulas: Ri });
    Ei = EiPlus1; // continue with remaining formulas
    i++;
  }

  // Any formulas left over get assigned to rank ∞
  if (Ei.length > 0) {
    levels.push({ rankNumber: Infinity, formulas: Ei });
  }

  return levels;
}

/**
 * extractAntecedent
 * ------------------
 * Utility function that extracts the antecedent (α) from an implication "α -> β".
 *
 * @param f - a formula string of the form "α -> β"
 * @returns the antecedent string (α), or empty if not found
 */
function extractAntecedent(f: string): string {
  const m = f.match(/^(.+?)->/);
  return m ? m[1].trim() : '';
}
