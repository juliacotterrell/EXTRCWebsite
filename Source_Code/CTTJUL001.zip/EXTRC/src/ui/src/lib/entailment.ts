// src/lib/entailment.ts
/*
 * File: entailment.ts
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Typescript component for computing entailment.
 * Purpose: Educational use only.
 *
 * Notes:
 * - This module wraps the backend endpoints used by the UI to:
 *   1) Compute the base ranking of a knowledge base, and
 *   2) Evaluate a rational-closure entailment query.
 * - It also exposes a tiny localEntailmentCheck helper for quick client-side
 *   demos (string inclusion), not for real reasoning.
 */

import type { RankingLevel } from "@/components/MainContent/MainContent";

// Base URL for the backend API. Falls back to localhost for local dev.
// Expect VITE_API_BASE to be set in the UI environment when deployed.
const API_BASE = import.meta.env.VITE_API_BASE ?? "http://localhost:8080";

// Shape of the combined response the UI expects after a query.
export type QueryResults = {
  baseRanking: RankingLevel[];
  rational: {
    entailed: boolean;
    removedRanking?: RankingLevel[];
    negation?: string;
    timeTaken?: number;
    strategyTimes?: Record<string, number>;
  };
};

/**
 * fetchJson
 * - Thin wrapper around fetch with:
 *   • AbortController-based timeout
 *   • Basic error decoding (JSON or text)
 * - Returns parsed JSON of the expected generic type T.
 */
async function fetchJson<T>(url: string, init: RequestInit, timeoutMs = 20000): Promise<T> {
  const ctrl = new AbortController();
  const id = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...init, signal: ctrl.signal });
    if (!res.ok) {
      // Try to surface a helpful message from the server if present.
      let msg = `${res.status} ${res.statusText}`;
      try {
        const err = await res.json();
        msg = typeof err === "string" ? err : err.message || JSON.stringify(err);
      } catch {
        try { msg = await res.text(); } catch { /* ignore if even that fails */ }
      }
      throw new Error(msg || `Request failed: ${res.status}`);
    }
    return (await res.json()) as T;
  } finally {
    clearTimeout(id);
  }
}

/**
 * handleQueryRequest
 * - Posts the user's KB to /api/base-rank to compute the ranking.
 * - Posts the KB + query to /api/entailment/rational/{query} to evaluate entailment.
 * - Returns a combined object the UI can render (ranking + rational result).
 *
 * @param kb    The knowledge base as an array of formula strings.
 * @param query The query string (e.g., "p ~> q").
 */
export async function handleQueryRequest(kb: string[], query: string): Promise<QueryResults> {
  const headers = { "Content-Type": "application/json" };

  // 1) Compute base ranking
  const base = await fetchJson<{ ranking: RankingLevel[] }>(
    `${API_BASE}/api/base-rank`,
    { method: "POST", headers, body: JSON.stringify({ formulas: kb }) }
  );

  // 2) Evaluate rational-closure entailment for the query
  const rational = await fetchJson<QueryResults["rational"]>(
    `${API_BASE}/api/entailment/rational/${encodeURIComponent(query)}`,
    { method: "POST", headers, body: JSON.stringify({ knowledgeBase: kb }) }
  );

  return {
    baseRanking: base.ranking ?? [],
    rational,
  };
}

/**
 * localEntailmentCheck
 * - Extremely naive client-side check (string presence).
 * - This is *not* the real logic; only useful for smoke tests / examples.
 */
export function localEntailmentCheck(kb: string[], query: string): boolean {
  return kb.includes(query);
}