/*
 * File: formula.ts
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Typescript component for displaying formulas.
 * Purpose: Educational use only.
 */
/**
 * Convert formula from plain text to Tex formula.
 * @param formula formula to convert.
 * @returns Tex string
 */
function toTex(formula: string): string {
  return formula
    .replaceAll("+", " \\top ")
    .replaceAll("-", " \\bot ")
    .replaceAll("!", " \\neg ")
    .replaceAll("&&", " \\land ")
    .replaceAll("||", " \\lor ")
    .replaceAll("<=>", " \\leftrightarrow ")
    .replaceAll("=>", " \\to ")
    .replaceAll("~>", " \\mid\\!\\sim ")
    .replaceAll("==", " \\mid\\hskip-0.40ex\\approx")
    .trim();
}


/**
 * Convert formula from plain text to materialized Tex formula.
 * @param formula formula to convert.
 * @returns Tex string
 */
function toTexMat(formula: string): string {
  return formula
    .replaceAll("+", " \\top ")
    .replaceAll("-", " \\bot ")
    .replaceAll("!", " \\neg ")
    .replaceAll("&&", " \\land ")
    .replaceAll("||", " \\lor ")
    .replaceAll("<=>", " \\leftrightarrow ")
    .replaceAll("=>", " \\to ")
    .replaceAll("~>", " \\to ")
    .trim();
}

/**
 * Gets the label for all ranks combined.
 * @param start The starting rank.
 * @param end The ending rank.
 * @returns Tex string representing union of all ranks.
 */
function allRanks(start: number, end: number) {
  const infiniteRank = "R_{\\infty}";
  const finiteRanks = `\\left( \\bigcup_{j=${start}}^{j < ${end}} R_j \\right)`;
  if (start >= end) {
    return infiniteRank;
  }
  return infiniteRank + " \\cup " + finiteRanks;
}

/**
 * Gets the label for the entailment of the ranks.
 * @param start The starting rank.
 * @param end The ending rank.
 * @param formula The formula to entail/not entail.
 * @param entailed Entailment.
 * @returns Tex string representing the entailment of the ranks.
 */
function allRanksEntail(
  start: number,
  end: number,
  formula: string,
  entailed: boolean = true
) {
  const ranks = allRanks(start, end);
  const symbol = entailed ? "\\models" : "\\not\\models";
  return ranks + " " + symbol + " " + toTex(formula);
}

export type RenderFormulaResponse =
  | { raw: string; explanation?: string }
  | { error: string; message: string };

const BASE_URL = import.meta.env.VITE_BACKEND_URL ?? "http://localhost:8080";

export async function renderFormula(
  formula: string,
  opts?: { explain?: boolean; rank?: number }
): Promise<RenderFormulaResponse> {
  const explain = opts?.explain ?? true;
  const rank = opts?.rank ?? 0;

  const url = new URL(`${BASE_URL}/api/formula/render`);
  url.searchParams.set("formula", formula);
  url.searchParams.set("explain", String(explain));
  url.searchParams.set("rank", String(rank));
  console.debug("[ExplanationPanel] GET", url.toString());


  const res = await fetch(url.toString(), { method: "GET" });
  const json = await res.json();
  return json;
}
export { allRanks, allRanksEntail, toTex, toTexMat };

