/*
 * File: queryUtils.ts
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Typescript utility for parsing queries into components.
 * Purpose: Educational use only.
 */

/**
 * parseQueryParts
 * - Splits a query string into its left-hand side (antecedent),
 *   right-hand side (consequent), and operator.
 *
 * - Supports two types of operators:
 *   • "~>" (defeasible implication)
 *   • "=>" (material/strict implication)
 *
 * - Trims whitespace around parts for clean parsing.
 *
 * @param q optional query string, e.g. "penguin ~> bird"
 * @returns object with { left, right, op } if recognised,
 *          otherwise an empty object
 *
 * Example:
 *   parseQueryParts("p ~> q")
 *   // { left: "p", right: "q", op: "~>" }
 */
export function parseQueryParts(
  q?: string
): { left?: string; right?: string; op?: "~>" | "=>" } {
  if (!q) return {}; // no query -> return empty object
  const t = q.trim();

  // Match defeasible implication
  const m1 = t.match(/^\s*(.+?)\s*~>\s*(.+)\s*$/);

  // Match strict/material implication
  const m2 = t.match(/^\s*(.+?)\s*=>\s*(.+)\s*$/);

  // Return structured parts if matched
  if (m1) return { left: m1[1].trim(), right: m1[2].trim(), op: "~>" };
  if (m2) return { left: m2[1].trim(), right: m2[2].trim(), op: "=>" };

  // Default: unrecognised format
  return {};
}
