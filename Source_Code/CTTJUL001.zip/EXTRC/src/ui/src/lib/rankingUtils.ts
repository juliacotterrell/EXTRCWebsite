// src/utils/rankingUtils.ts
/*
 * File: rankingUtils.ts
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Typescript utility for computing base ranking steps with reasons.
 * Purpose: Educational use only.
 */

export interface RankingStep {
  rankNumber: number | '∞'   // which rank this step belongs to
  Ei: string[]               // current knowledge base at step i
  Ri: string[]               // formulas found to be exceptional at Ei
  EiPlus1: string[]          // remaining KB after removing Ri
  reasonMap: Record<string, string> // explanations of why formulas are exceptional
}

/**
 * computeBaseRankingWithReasons
 * - Iteratively computes the base ranking of a materialized KB.
 * - At each step:
 *    • Identify exceptional formulas (Ri)
 *    • Remove them from Ei to form Ei+1
 *    • Record reasons for removal
 * - Stops when no more exceptional formulas are found.
 * - Any leftovers are assigned to the infinite rank (R∞).
 *
 * @param materializedKB list of formulas to rank
 * @param entailsFn function that checks whether a KB entails a formula
 * @returns an array of RankingStep objects showing each stage
 */
export function computeBaseRankingWithReasons(
  materializedKB: string[],
  entailsFn: (KB: string[], formula: string) => boolean
): RankingStep[] {
  let Ei = [...materializedKB] // start with the full KB
  let i = 0
  const steps: RankingStep[] = []

  while (true) {
    // Find exceptional formulas: those whose antecedent is inconsistent
    const exceptional = Ei.filter(f => {
      const α = extractAntecedent(f)
      return entailsFn(Ei, `¬(${α})`)
    })

    const Ri = exceptional
    if (Ri.length === 0) break // no more exceptions, stop iterating

    // Remove Ri to form Ei+1
    const EiPlus1 = Ei.filter(f => !Ri.includes(f))

    // Map reasons for each formula in Ri
    const reasonMap: Record<string, string> = {}
    for (const f of Ri) {
      const α = extractAntecedent(f)
      reasonMap[f] = `Antecedent "${α}" is exceptional in E${i}`
    }

    // Save this step
    steps.push({ rankNumber: i, Ei: [...Ei], Ri, EiPlus1, reasonMap })

    // Prepare for next iteration
    Ei = EiPlus1
    i++
  }

  // Handle remaining formulas -> assign them to infinite rank
  if (Ei.length > 0) {
    const reasonMap: Record<string,string> = {}
    for (const f of Ei) {
      reasonMap[f] = `No further exceptions—goes to R∞`
    }
    steps.push({ rankNumber: '∞', Ei: [...Ei], Ri: [...Ei], EiPlus1: [], reasonMap })
  }

  return steps
}

/**
 * extractAntecedent
 * - extracts the left-hand side (antecedent) of a formula
 *
 * @param f formula string
 * @returns the antecedent text, or "(unknown)" if not matched
 */
function extractAntecedent(f: string) {
  const m = f.match(/^(.+?)->/)
  return m ? m[1].trim() : '(unknown)'
}
