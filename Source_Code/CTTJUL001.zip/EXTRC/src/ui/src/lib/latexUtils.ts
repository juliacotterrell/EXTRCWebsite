// src/utils/latexUtils.ts
/*
 * File: latexUtils.tsx
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Typescript component for converting latex.
 * Purpose: Educational use only.
 */
import { toTex, toTexMat } from '@/lib/formula';

/**
 * setPreviewTex(items, cap)
 * renders "{φ1, φ2, …}" with an optional ellipsis if length > cap
 */
export function setPreviewTex(items: string[], cap = 5): string {
  if (!items || items.length === 0) {
    return '\\varnothing'
  }
  const shown = items
    .slice(0, cap)
    .map(formula => toTex(formula))
  const ellipsis = items.length > cap ? ',\\dots' : ''
  return `\\{ ${shown.join(', ')}${ellipsis} \\}`
}