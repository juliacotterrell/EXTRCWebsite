/*
 * File: useFormulaExplanation.ts
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: React hook for fetching a rendered/annotated view of a formula.
 * Purpose: Educational use only.
 *
 * Notes:
 * - Given a raw formula string, this hook calls the backend renderer
 *   and returns: loading state, any error, the raw canonical string,
 *   and an optional structured explanation.
 * - No UI side effects here; consumers decide how to display results.
 */

import { useEffect, useState } from "react";
import { renderFormula, type RenderFormulaResponse } from "../formula";

/**
 * useFormulaExplanation
 * - Triggers a render/explain request whenever (formula | explain | rank) changes.
 * - Handles in-flight cancellation to avoid setting state after unmount.
 * - Returns a small tuple of derived fields for convenience.
 *
 * @param formula the input formula (plain text)
 * @param explain whether to ask the server for an explanation payload
 * @param rank optional rank context for the renderer
 */
export function useFormulaExplanation(formula: string, explain = true, rank = 0) {
  const [data, setData] = useState<RenderFormulaResponse | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Empty formula: reset state and skip the request.
    if (!formula?.trim()) { setData(null); return; }

    // Simple cancellation flag to prevent state updates on unmounted component.
    let cancelled = false;

    (async () => {
      try {
        setLoading(true);
        // Call the API helper with current inputs.
        const res = await renderFormula(formula, { explain, rank });
        if (!cancelled) setData(res);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    // Cleanup to flip the cancellation flag when dependencies change.
    return () => { cancelled = true; };
  }, [formula, explain, rank]);

  const error =
    (data && "error" in data) ? (data.message || data.error) : undefined;

  const raw =
    (data && "raw" in data) ? data.raw : undefined;

  const explanation =
    (data && "explanation" in data) ? data.explanation : undefined;

  return { loading, error, raw, explanation };
}
