// src/lib/uploadKnowledgeBase.ts
/*
 * File: uploadKnowledgeBase.ts
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Typescript utility for handling Knowledge Base (KB) uploads.
 * Purpose: Educational use only.
 */

/**
 * handleKbUpload
 * ----------------
 * Reads a `.txt` file uploaded by the user and converts it into
 * a list of formulas (strings) suitable for use as a Knowledge Base (𝒦).
 *
 * Process:
 *  1. Uses FileReader to read the file as text.
 *  2. Splits the file content into lines.
 *  3. Trims whitespace and discards any empty lines.
 *  4. Returns an array of formulas as strings.
 *
 * @param file - The text file uploaded by the user
 * @returns Promise<string[]> - array of formulas
 */
export async function handleKbUpload(file: File): Promise<string[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    // When the file has been successfully read
    reader.onload = () => {
      const text = reader.result as string;
      const lines = text
        .split(/\r?\n/)          // split on newlines (Windows/Mac/Linux safe)
        .map(line => line.trim()) // remove surrounding whitespace
        .filter(line => line.length > 0); // skip blank lines
      resolve(lines);
    };

    // Handle file read errors
    reader.onerror = () => {
      reject("Failed to read file");
    };

    // Start reading the file as plain text
    reader.readAsText(file);
  });
}
