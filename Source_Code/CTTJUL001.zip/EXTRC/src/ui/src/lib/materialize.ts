// src/lib/materialize.ts
/*
 * File: materialize.ts
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Utility functions for converting ("materialising") formulas
 *          from their defeasible syntax into their classical/material
 *          logic LaTeX equivalents for rendering in the UI.
 * Purpose: Educational use only.
 */

import { toTexMat } from "@/lib/formula";

/**
 * normalizeTeX
 * - Cleans up generated LaTeX strings:
 *   • Collapses multiple backslashes into a single one
 *   • Collapses multiple spaces into one
 *   • Trims leading/trailing whitespace
 *
 * @param s raw LaTeX string
 * @returns cleaned LaTeX string
 */
const normalizeTeX = (s: string) =>
  s.replace(/\\+/g, "\\")
    .replace(/\s+/g, " ")
    .trim();

/**
 * materializeKB
 * - Takes a knowledge base (array of formula strings in defeasible syntax)
 * - Converts each formula into its *materialised* LaTeX form
 *   using `toTexMat`, then normalises spacing and slashes.
 *
 * @param kb array of formulas (strings)
 * @returns array of LaTeX-rendered formulas
 */
export function materializeKB(kb: string[]): string[] {
  return kb.map((f) => normalizeTeX(toTexMat(f)));
}

/**
 * MaterializedLevel
 * - Type alias for a rank level where formulas are already converted to LaTeX.
 */
export type MaterializedLevel = { rankNumber: number; formulas: string[] };

/**
 * materializeRanking
 * - Applies `materializeKB` logic rank by rank across an entire ranking.
 * - Converts each rank’s formulas to LaTeX while preserving rank numbers.
 *
 * @param levels array of objects { rankNumber, formulas }
 * @returns array of materialised rank levels
 */
export function materializeRanking(
  levels: { rankNumber: number; formulas: string[] }[]
): MaterializedLevel[] {
  return levels.map((lvl) => ({
    rankNumber: lvl.rankNumber,
    formulas: lvl.formulas.map((f) => normalizeTeX(toTexMat(f))),
  }));
}
