/*
 * File: App.tsx
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: React component for generating the App.
 * Purpose: Educational use only.
 */

import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Header } from "@/components/sections/Header";
import { Footer } from "@/components/sections/Footer";
import { MainContent } from "@/components/MainContent/MainContent";
import { Syntax } from "@/components/pages/Syntax";
import Tutorial from "@/components/pages/Tutorial";
import NLMappingDemo from "./components/pages/NLMappingDemo";

export default function App() {
  return (
    <BrowserRouter>
      {/* App container: ensures full viewport width and height */}
      <div className="w-screen min-h-[100dvh]">
        {/* Persistent header at top of every page */}
        <Header className="w-full" />
        {/* Main section: switches between routes */}
        <main className="flex-1 overflow-auto">
          <Routes>
            {/* Default route -> main reasoning interface */}
            <Route path="/" element={<MainContent />} />
            {/* Syntax page (symbols, rules, typing guide) */}
            <Route path="/syntax" element={<Syntax />} />
            {/* Tutorial page (examples and guided steps) */}
            <Route path="/tutorial" element={<Tutorial />} />
            {/* Demo for natural language mapping */}
            <Route path="/NLMappingdemo" element={<NLMappingDemo />} />
          </Routes>
        </main>
        {/* Persistent footer at bottom of every page */}
        <Footer className="w-full" />
      </div>
    </BrowserRouter>
  );
}
