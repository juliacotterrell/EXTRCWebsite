// ui/src/types/react-katex.d.ts
/*
 * File: react-katex.d.ts
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: TypeScript declaration file to provide typing support for the `react-katex` package.
 * Purpose: Educational use only.
 */

declare module 'react-katex' {
  import * as React from 'react';

  /**
   * Props accepted by both InlineMath and BlockMath components.
   */
  export interface KatexProps {
    /** LaTeX math string to render */
    math?: string;
    /** Alternative: render children instead of `math` prop */
    children?: React.ReactNode;
    /** KaTeX rendering settings (e.g., { displayMode: true }) */
    settings?: Record<string, unknown>;
    /** Custom renderer for error handling */
    renderError?: (error: Error) => React.ReactNode;
    /** Color applied to error text */
    errorColor?: string;
    /** Custom CSS class */
    className?: string;
    /** Inline style overrides */
    style?: React.CSSProperties;
  }

  /**
   * Inline math component (renders within text flow).
   * Example: <InlineMath math="a^2 + b^2 = c^2" />
   */
  export const InlineMath: React.FC<KatexProps>;

  /**
   * Block math component (renders as a centered block).
   * Example: <BlockMath math="\int_0^1 x^2 dx" />
   */
  export const BlockMath: React.FC<KatexProps>;
}
