/*
 * File: Header.tsx
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: React component for displaying the header.
 * Purpose: Educational use only.
 */
import { NavLink } from "react-router-dom";
import logo from "@/assets/logo.svg";

interface HeaderProps {
  className?: string;
}

function Header({ className }: HeaderProps) {
  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `text-gray-700 hover:text-black ${isActive ? "font-semibold underline" : ""}`;

  return (
    <header
      className={`
        w-full
        border-b
        bg-background
        px-4 md:px-6 lg:px-8   /* ← horizontal padding */
        py-3                  /* ← vertical padding */
        ${className ?? ""}
      `}
    >
      <div className="flex items-center justify-between">
        <NavLink to="/" className="flex items-center gap-2" aria-label="Go to home">
          <img src={logo} alt="logo" className="w-6 h-6" />
        </NavLink>
        <nav className="space-x-6">
          <NavLink to="/syntax" className={linkClass}>
            Syntax
          </NavLink>
          <NavLink to="/tutorial" className={linkClass}>
            Tutorial
          </NavLink>
          <NavLink to="/NLMappingdemo" className={linkClass}>
            NL Knowledge Base
          </NavLink>
        </nav>
      </div>
    </header>
  );
}

export { Header };
