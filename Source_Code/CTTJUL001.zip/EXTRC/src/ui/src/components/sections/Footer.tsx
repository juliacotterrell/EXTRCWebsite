
/*
 * File: Footer.tsx
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: React component for displaying the footer.
 * Purpose: Educational use only.
 */
import github from "@/assets/github-mark.svg";
import { cn } from "@/lib/utils";

interface FooterProps {
  className?: string;
}

function Footer({ className }: FooterProps) {
  return (
    <footer
      className={cn("text-center flex justify-center p-6 border-t", className)}
    >
      <a
        className="font-semibold flex items-center hover:underline"
        href="https://github.com/juliacotterrell/EXTRC"
        target="_blank"
      >
        <img src={github} alt="GitHub logo" className="w-6 mr-2" />
        <span>juliacotterrell</span>
      </a>
    </footer>
  );
}

export { Footer };
