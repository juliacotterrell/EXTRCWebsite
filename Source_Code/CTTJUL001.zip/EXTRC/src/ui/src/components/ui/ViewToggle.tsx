// src/components/ViewToggle.tsx
/*
 * File: ViewToggle.tsx
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: React component for displaying different view toggles.
 * Purpose: Educational use only.
 */
import React from "react";
import type { ViewMode } from "../MainContent/MainContent";

export function ViewToggle({
  value,
  onChange,
}: {
  value: ViewMode;
  onChange: (m: ViewMode) => void;
}) {
  return (
    <div
      role="tablist"
      aria-label="View mode"
      className="flex justify-center space-x-2 border-b border-border"
    >
      <button
        role="tab"
        aria-selected={value === "explanatory"}
        onClick={() => onChange("explanatory")}
        className={`px-3 py-1 ${value === "explanatory" ? "text-primary border-b-2 border-primary"
          : "text-muted-foreground hover:text-foreground"}`}
      >
        Explanatory
      </button>
      <button
        role="tab"
        aria-selected={value === "math"}
        onClick={() => onChange("math")}
        className={`px-3 py-1 border-l ${value === "math" ? "text-primary border-b-2 border-primary"
          : "text-muted-foreground hover:text-foreground"}`}
      >
        Mathematical
      </button>
    </div>
  );
}

export default ViewToggle;
