// src/components/MainContent/Tabs.tsx
/*
 * File: Tabs.tsx
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: React component for creating different tabs.
 * Purpose: Educational use only.
 */
import React from "react";

export function Tabs({
  tabs,
  current,
  onSelect
}: {
  tabs: string[];
  current: string;
  onSelect: (tab: string) => void;
}) {
  return (
    <div className="flex justify-center space-x-2 border-b border-border">
      {tabs.map(t => (
        <button
          key={t}
          onClick={() => onSelect(t)}
          className={`px-4 py-2 text-sm font-medium transition-all ${current === t
              ? "text-primary border-b-2 border-primary"
              : "text-muted-foreground hover:text-foreground"
            }`}
        >
          {t}
        </button>
      ))}
    </div>
  );
}
