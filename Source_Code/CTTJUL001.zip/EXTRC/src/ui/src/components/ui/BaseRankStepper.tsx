// src/components/BaseRankStepper.tsx
/*
 * File: BaseRankStepper.tsx
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: React component for displaying the base rank explorer.
 * Purpose: Educational use only.
 */

import React, { useState } from 'react'
import { InlineMath } from 'react-katex'
import { setPreviewTex } from '@/lib/latexUtils'

// Helper to force the "infinite" rank slot.
const isInfiniteRank = (rank: number) => rank > 999;

/**
 * A single step shown in the stepper:
 * - i: the iteration label ("M" for materialisation, 0..n, or "∞")
 * - Ei: current working KB at iteration i
 * - Ri: formulas identified as Rank_i at this step
 * - EiPlus1: remainder after removing exceptional formulas
 * - description: human-readable narrative for this step
 */
export type Step = {
  i: "M" | number | '∞'
  Ei: string[]
  Ri: string[]
  EiPlus1: string[]
  description: React.ReactNode[]
}

type Props = {
  // Ordered list of steps to render in the explorer 
  steps: Step[]
}

export default function BaseRankStepper({ steps }: Props) {
  // Index of the currently viewed step
  const [idx, setIdx] = useState(0)

  // Destructure the current step for convenience
  const { i, Ei, Ri, EiPlus1, description } = steps[idx]

  // Special-case flags used to tweak the header/table
  const isMat = i === "M"
  const isLast = idx === steps.length

  // Label for the heading (M, numeric i, or ∞)
  const rankLabel = isLast
    ? '∞'
    : isMat
      ? 'M'
      : String(steps[idx].i)

  return (
    <section className="p-4 border rounded space-y-4">
      {/* Step title */}
      <h3 className="text-lg font-semibold">
        {isMat
          ? "Materialization"
          : isLast
            ? "Infinite Rank (R∞)"
            : `Iteration ${rankLabel}`}
      </h3>

      {/* Narrative explanation for this step */}
      <div className="space-y-1 text-sm text-gray-700">
        {description.map((line, j) => (<p key={j}>{line}</p>))}
      </div>

      {/* Either show the materialised KB (step M) or the Ei / Ri / Ei+1 table */}
      {isMat ? (
        <div className="mt-2">
          <InlineMath math={setPreviewTex(EiPlus1)} />
        </div>
      ) : (
        <table className="w-full table-auto text-sm border-collapse">
          <thead>
            <tr>
              <th className="border px-2"><InlineMath math="\Large \varepsilon" /><sub>{i}</sub></th>
              <th className="border px-2">Rank <sub>{i}</sub></th>
              <th className="border px-2"><InlineMath math="\Large \varepsilon" /><sub>{i}+1</sub></th>
            </tr>
          </thead>
          <tbody>
            <tr>
              {/* Ei: active KB at step i */}
              <td className="border px-2">
                <InlineMath math={setPreviewTex(Ei)} />
              </td>
              {/* Ri: formulas selected as the i-th rank */}
              <td className="border px-2">
                <InlineMath math={setPreviewTex(Ri)} />
              </td>
              {/* Ei+1: remainder after removing Ri (unless ∞ row, where we just show a dash) */}
              <td className="border px-2">
                {i === '∞' ? '—' : <InlineMath math={setPreviewTex(EiPlus1)} />}
              </td>
            </tr>
          </tbody>
        </table>
      )}

      {/* Pager controls to move through steps */}
      <div className="flex justify-between">
        <button
          onClick={() => setIdx(idx - 1)}
          disabled={idx === 0}
          className="px-3 py-1 border rounded disabled:opacity-50"
        >
          Prev
        </button>
        <button
          onClick={() => setIdx(idx + 1)}
          disabled={idx === steps.length - 1}
          className="px-3 py-1 border rounded disabled:opacity-50"
        >
          Next
        </button>
      </div>
    </section>
  )
}
