/*
 * File: rankingTable.tsx
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: React component for displaying ranking tables.
 * Purpose: Educational use only.
 */

import React from "react";
import { InlineMath } from "react-katex";
import { toTex } from "@/lib/formula";
import type { RankingLevel } from "../MainContent/MainContent";

/** Helper: treat any very large rank index as the "infinite" bucket (R∞) */
const isInfiniteRank = (rank: number) => rank > 999;

/** Props:
 *  - title: section heading shown above the table
 *  - ranking: array of { rankNumber, formulas } rows to render
 *  - colorClass: optional Tailwind class for title colouring (e.g., red/green)
 */
type Props = {
  title: string;
  ranking: RankingLevel[];
  colorClass?: string;
};

/**
 * RankingTable
 * - Renders a two-column table:
 *   (Rank | Formulas in that rank), with LaTeX rendering for each formula.
 * - Shows "None" if there are no formulas across all ranks.
 */
export const RankingTable = ({ title, ranking, colorClass = "" }: Props) => {
  // if every level is empty, show a short "None" message.
  const hasFormulas = ranking.some(level => level.formulas.length > 0);

  if (!hasFormulas) {
    return (
      <div className="mb-6">
        <h2 className={`text-xl font-bold mb-2 ${colorClass}`}>{title}</h2>
        <p className="text-gray-500 italic">None</p>
      </div>
    );
  }

  // Default rendering using table with one row per rank.
  return (
    <div className="overflow-x-auto mb-6">
      <h2 className={`text-xl font-bold mb-2 ${colorClass}`}>{title}</h2>
      <table className="table-auto text-sm w-full border-collapse">
        <thead>
          <tr className="bg-gray-100">
            <th className="border px-4 py-2 text-left">Rank</th>
            <th className="border px-4 py-2 text-left">Formulas</th>
          </tr>
        </thead>
        <tbody>
          {ranking.map(level => (
            <tr key={level.rankNumber}>
              {/* Show ∞ for the infinite bucket, otherwise the numeric rank */}
              <td className="border px-4 py-2">{isInfiniteRank(level.rankNumber) ? "∞" : level.rankNumber}</td>
              <td className="border px-4 py-2">
                {/* Render each formula in LaTeX bullet pointed*/}
                <ul className="list-disc ml-4">
                  {level.formulas.map(f => (
                    <li key={f}><InlineMath math={toTex(f)} /></li>
                  ))}
                </ul>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
