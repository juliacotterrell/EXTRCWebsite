/*
 * File: Syntax.tsx
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: React component for displaying all of the syntax used in the website.
 * Purpose: Educational use only.
 */

import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { InlineMath } from "react-katex";
import { toTex } from "@/lib/formula";

/**
 * Table row model for the syntax reference.
 * - latex: how to render the symbol in KaTeX
 * - symbol: short label/name of the operator
 * - typing: what users type in the input UI
 * - meaning: brief description for the table
 * - definition: longer glossary-style explanation
 * - example: example string that will be rendered with toTex()
 */
type Row = {
  latex: string;       // LaTeX to render the operator itself
  symbol: string;      // short name of the symbol
  typing: string;      // how to type it in the app
  meaning: string;     // brief label shown in the table
  definition: string;  // definition for the glossary
  example?: string;    // typed example rendered via toTex()
};

/**
 * Static list of connectives and meta symbols supported by the app.
 * These drive both the "Connectives & Notation" table and the glossary below.
 */
const rows: Row[] = [
  {
    latex: "p,\\ q,\\ r,\\dots",
    symbol: "Atoms",
    typing: "p",
    meaning: "Atoms (propositional variables)",
    definition:
      "Lowercase letters (p, q, r, …) that stand for simple statements that are either true or false.",
    example: "p",
  },
  {
    latex: "\\top",
    symbol: "Tautology",
    typing: "+",
    meaning: "Tautology",
    definition:
      "A formula that is always true in every situation (e.g., ‘True’). Useful as a neutral truth.",
    example: "+",
  },
  {
    latex: "\\bot",
    symbol: "Contradiction",
    typing: "-",
    meaning: "Contradiction / Falsum",
    definition:
      "Always false in every situation. Represents an impossible or contradictory statement.",
    example: "-", 
  },
  {
    latex: "\\neg",
    symbol: "Negation",
    typing: "!",
    meaning: "Negation",
    definition:
      "‘Not’. The statement ¬p is true exactly when p is false, and false when p is true.",
    example: "!p",
  },
  {
    latex: "\\land",
    symbol: "Conjunction",
    typing: "&&",
    meaning: "Conjunction",
    definition:
      "‘And’. The statement (p ∧ q) is true only when both p and q are true.",
    example: "p && q",
  },
  {
    latex: "\\lor",
    symbol: "Disjunction",
    typing: "||",
    meaning: "Disjunction",
    definition:
      "‘Or’ (inclusive). The statement (p ∨ q) is true when at least one of p or q is true (or both).",
    example: "p || q",
  },
  {
    latex: "\\to",
    symbol: "Material implication",
    typing: "=>",
    meaning: "Material implication",
    definition:
      "‘If … then …’ under classical logic. (p → q) is false only when p is true and q is false; otherwise true.",
    example: "p => q",
  },
  {
    latex: "\\leftrightarrow",
    symbol: "Equivalence",
    typing: "<=>",
    meaning: "Equivalence",
    definition:
      "‘If and only if’. (p ↔ q) is true when p and q have the same truth value (both true or both false).",
    example: "p <=> q",
  },
  {
    latex: "\\mid\\!\\sim",
    symbol: "Defeasible implication",
    typing: "~>",
    meaning: "Defeasible implication (object-level)",
    definition:
      "A defeasible rule inside the knowledge base. ‘Typically …’. (p ~> q) says q normally follows from p unless there are stronger exceptions.",
    example: "p ~> q",
  },
  {
    latex: "\\mid\\hskip-0.40ex\\approx",
    symbol: "Defeasible entailment",
    typing: "==",
    meaning: "Defeasible entailment (meta-level)",
    definition:
      "Used in queries to ask whether something follows defeasibly from the ranked knowledge base.",
    example: "K == (p ~> q)",
  },
  {
    latex: "\\left(\\cdot\\right)",
    symbol: "Grouping",
    typing: "( )",
    meaning: "Grouping",
    definition:
      "Parentheses control order of operations and make structure explicit, e.g., (p ∧ q) → r.",
    example: "(p && q) => r",
  },
];

/**
 * Example knowledge base used in the "KB format" section.
 * Rendered both as raw text (for uploads) and as LaTeX (for preview).
 */
const exampleKB = ["(p => b)", "(b ~> f)", "(b ~> w)", "(p ~> !f)"];

function Syntax() {
  return (
    <div className="w-full p-6 space-y-8">
      {/* Page header and short description */}
      <header>
        <h1 className="text-2xl font-bold mb-2">Syntax</h1>
        <p className="text-sm text-muted-foreground">
          This page can be used as a tutorial to understand the input language used for your Knowledge Base (𝒦) and queries.
        </p>
      </header>

      {/* Operators table (quick reference) */}
      <Card className="w-full">
        <CardContent className="p-6">
          <h2 className="text-lg font-semibold mb-3">Connectives & Notation</h2>
          <div className="overflow-x-auto">
            <table className="min-w-full table-auto border border-gray-300 text-sm" aria-describedby="operators-caption">
              <caption id="operators-caption" className="text-left text-muted-foreground p-2">
                Symbols you can use, their meaning, and how to type them. Definitions are explaned on below.
              </caption>
              <thead>
                <tr className="bg-gray-100">
                  <th scope="col" className="border px-3 py-2 text-left">Symbol</th>
                  <th scope="col" className="border px-3 py-2 text-left">Meaning</th>
                  <th scope="col" className="border px-3 py-2 text-left">Type this</th>
                  <th scope="col" className="border px-3 py-2 text-left">Example</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r, i) => (
                  <tr key={i}>
                    {/* Render the connective itself via KaTeX */}
                    <td className="border px-3 py-2 align-middle"><InlineMath math={r.latex} /></td>
                    {/* Short meaning for the table view */}
                    <td className="border px-3 py-2 align-middle">{r.meaning}</td>
                    {/* What users type in the input fields */}
                    <td className="border px-3 py-2 align-middle"><kbd className="px-1 py-0.5 rounded border bg-muted/50">{r.typing}</kbd></td>
                    {/* Example shown both rendered and as plain text */}
                    <td className="border px-3 py-2">
                      {r.example ? (
                        <div className="flex flex-col gap-1">
                          <span className="sr-only">Rendered:</span>
                          <InlineMath math={toTex(r.example)} />
                          <span className="text-xs text-muted-foreground">typed: <code>{r.example}</code></span>
                        </div>
                      ) : (
                        <span aria-hidden>—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Definitions / Glossary (longer explanations) */}
      <Card>
        <CardContent className="p-6">
          <h2 className="text-lg font-semibold mb-3">Definitions</h2>
          <dl className="grid md:grid-cols-2 gap-4">
            {rows.map((r, i) => (
              <div key={i} className="rounded border p-3">
                {/* Term header: KaTeX symbol + human label */}
                <dt className="font-medium flex items-center gap-2">
                  <InlineMath math={r.latex} />
                  <span className="text-muted-foreground">{r.symbol}</span>
                </dt>
                {/* Long description */}
                <dd className="mt-1 text-sm">{r.definition}</dd>
                {/* Optional example in LaTeX */}
                {r.example && (
                  <div className="mt-2 text-sm">
                    <span className="text-muted-foreground mr-1">Example:</span>
                    <InlineMath math={toTex(r.example)} />
                  </div>
                )}
              </div>
            ))}
          </dl>
        </CardContent>
      </Card>

      {/* Knowledge Base format: how uploads should look */}
      <Card>
        <CardContent className="p-6">
          <h2 className="text-lg font-semibold mb-3">Knowledge Base (𝒦) Format</h2>
          <ul className="list-disc ml-6 space-y-1 text-sm">
            <li>One formula per line when uploading a file (e.g. <span className="font-mono">.txt</span>).</li>
            <li>Spaces are optional; parentheses are recommended for clarity.</li>
            <li>Comments are not supported—omit them before uploading.</li>
          </ul>

          {/* Raw text preview of a sample .txt upload */}
          <div className="mt-3">
            <p className="text-sm mb-1">Example upload (.txt):</p>
            <pre className="p-3 bg-muted rounded text-sm overflow-x-auto" aria-label="Example Knowledge Base file contents">
{exampleKB.join("\n")}
            </pre>

            {/* Same content rendered with KaTeX for clarity */}
            <p className="text-sm mt-3">
              This renders as:{" "}
              {exampleKB.map((f, i) => (
                <React.Fragment key={f}>
                  <InlineMath math={toTex(f)} />
                  {i < exampleKB.length - 1 && <span>, </span>}
                </React.Fragment>
              ))}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Query syntax explanation + examples */}
      <Card>
        <CardContent className="p-6">
          <h2 className="text-lg font-semibold mb-3">Query Syntax</h2>
          <p className="text-sm mb-3">
            Queries typically use the defeasible connective:{" "}
            <InlineMath math={"a \\mid\\!\\sim b"} /> (typed as <span className="font-mono">a ~&gt; b</span>).
            The entailment engines (Rational) evaluate whether the query follows from the ranked 𝒦.
          </p>
          <div className="space-y-2 text-sm">
            <p>
              <strong>Example:</strong> <InlineMath math={toTex("p ~> b")} /> — “Typically, if <InlineMath math={"p"} /> then <InlineMath math={"b"} />.”
            </p>
            <p>Classical queries are allowed too, e.g. <InlineMath math={toTex("(p && q) => r")} />.</p>
          </div>
        </CardContent>
      </Card>

      {/* Quick mapping snippet for reference (typing -> LaTeX) */}
      <Card>
        <CardContent className="p-6">
          <h2 className="text-lg font-semibold mb-3">Typing → LaTeX Rendering</h2>
          <p className="text-sm">The app converts plain text to LaTeX using these mappings (see <span className="font-mono">toTex()</span>):</p>
          <pre className="p-3 bg-muted rounded text-xs overflow-x-auto mt-2" aria-label="Typing to LaTeX mapping table">
{`!  -> \\neg
&& -> \\land
|| -> \\lor
<=> -> \\leftrightarrow
=>  -> \\to
~>  -> \\mid\\!\\sim
+   -> \\top
-   -> \\bot
==  -> \\mid\\hskip-0.40ex\\approx`}
          </pre>
        </CardContent>
      </Card>

      {/* Final tips / best practices for writing inputs */}
      <Card>
        <CardContent className="p-6">
          <h2 className="text-lg font-semibold mb-3">Tips</h2>
          <ul className="list-disc ml-6 space-y-1 text-sm">
            <li>Use parentheses to disambiguate: <InlineMath math={toTex("(p && q) => r")} />.</li>
            <li>Prefer short, consistent atom names (<span className="font-mono">p</span>, <span className="font-mono">b</span>, <span className="font-mono">f</span>).</li>
            <li>
              Defeasible rules are ranked; strict contradictions are isolated at higher ranks (or ∞) by the ranking step.
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}

export {Syntax};
