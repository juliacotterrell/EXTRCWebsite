/*
 * File: Tutorial.tsx
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: React component for displaying a tutorial page.
 * Purpose: Educational use only.
 */

import React from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { InlineMath } from "react-katex";
import { toTex } from "@/lib/formula";

/**
 * Small shape for a demo tutorial scenario.
 * - label: card title
 * - description: short blurb under the title
 * - kb: example Knowledge Base lines
 * - query: example query to run
 */
type Demo = { label: string; description?: string; kb: string[]; query: string };

/**
 * Demo scenarios the user can load.
 * These get written into localStorage and then hydrated on the home page.
 */
const demos: Demo[] = [
  {
    label: "Penguins & Flying",
    description:
      "Illustrates exceptions: birds typically fly, but penguins do not.",
    kb: [
      "(penguin => bird)",
      "(bird ~> fly)",
      "(bird ~> wings)",
      "(penguin ~> !fly)"
    ],
    query: "(penguin ~> bird)",
  },
  {
    label: "Animal Trait Inheritance",
    description:
      "Warm-blooded animals tend to give live birth; mammals are warm-blooded.",
    kb: [
      "(mammal => warmBlooded)",
      "(warmBlooded ~> liveBirth)",
      "(mammal)",
      "(liveBirth ~> nursesYoung)"
    ],
    query: "(mammal ~> nursesYoung)",
  },
  {
    label: "Conflicting Preferences",
    description:
      "A person likes tea and coffee, but tea and coffee are exclusive choices here.",
    kb: [
      "(person ~> likesTea)",
      "(person ~> likesCoffee)",
      "(person)"
    ],
    query: "(person ~> likesTea)",
  },
  {
    label: "Cars vs. Emissions (Tesla Exception)",
    description:
      "Cars typically emit CO₂, but Teslas are cars that typically do not.",
    kb: [
      "(car ~> emitsCO2)",
      "(Tesla => car)",
      "(Tesla ~> !emitsCO2)"
    ],
    query: "(Tesla ~> emitsCO2)",
  },

];

export default function Tutorial() {
  // Router helper for returning to the main page after loading a demo.
  const navigate = useNavigate();

  /**
   * Persist the chosen demo to localStorage so the landing page can read it,
   * then navigate back to "/" where MainContent will hydrate state from storage.
   */
  const loadDemo = (demo: Demo) => {
    localStorage.setItem("extrc.demo", JSON.stringify(demo));
    navigate("/");
  };

  return (
    <div className="w-full px-4 md:px-8 lg:px-12 py-6 space-y-8">
      {/* Page header */}
      <header>
        <h1 className="text-3xl md:text-4xl font-bold">Tutorial</h1>
        <p className="text-sm text-muted-foreground mt-2">
          This app helps you explore{" "}
          <strong>defeasible reasoning</strong> — reasoning with typical rules
          and exceptions. You’ll enter a Knowledge Base (𝒦) of statements,
          choose a query, and see how different reasoning closures handle it.
        </p>
      </header>

      {/* A walkthrough of the flow of the app*/}
      <Card className="w-full">
        <CardContent className="p-6 space-y-3 text-sm">
          <h2 className="text-lg font-semibold">How the app works</h2>
          <ol className="list-decimal ml-5 space-y-2">
            <li>
              <strong>Enter your Knowledge Base (𝒦):</strong> one statement per line.
              Use{" "}
              <InlineMath math={toTex("~>")} /> for *typical/defeasible* rules (e.g., "Birds ~`{'>'}` Fly").
              Use{" "}
              <InlineMath math={toTex("=>")} /> for *strict* rules (always true).
            </li>
            <li>
              <strong>Pick a query</strong> you want to test — e.g.,
              <em>"If something is a penguin, does it typically fly?"</em>
            </li>
            <li>
              Click <strong>Query</strong>. The system will compute:
              <ul className="list-disc ml-5 mt-1 space-y-1">
                <li>
                  <strong>Base Rank:</strong> sorts your rules into levels from most
                  certain (rank 0) to least certain (higher ranks), with impossible
                  ones at ∞.
                </li>
                <li>
                  <strong>Rational Closure:</strong> draws cautious conclusions that
                  hold in the most specific consistent scenarios.
                </li>
              </ul>
            </li>
            <li>
              Check the <strong>Summary</strong>, <strong>Base Rank</strong>, and {" "}
              <strong>Rational Closure</strong> tabs.
            </li>
          </ol>
        </CardContent>
      </Card>

      {/* Prebuilt examples loded into the app that the user can try*/}
      <Card className="w-full">
        <CardContent className="p-6 space-y-4">
          <h2 className="text-lg font-semibold">Try these examples</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {demos.map((d) => (
              <div key={d.label} className="border rounded-md p-4 text-sm">
                {/* Demo header + blurb */}
                <h3 className="font-semibold mb-1">{d.label}</h3>
                <p className="text-muted-foreground mb-3">
                  {d.description}
                </p>
                {/* Show KB lines as a plain-text block for easy copy/scan */}
                <p className="mb-1 font-medium">Knowledge Base (𝒦)</p>
                <pre className="bg-muted p-2 rounded text-xs overflow-x-auto">
                  {d.kb.join("\n")}
                </pre>
                {/* Render the query in LaTeX for readability */}
                <p className="mt-2">
                  <span className="font-medium">Query:</span>{" "}
                  <InlineMath math={toTex(d.query)} />
                </p>

                {/* Persist + navigate back to main page */}
                <Button variant="outline" onClick={() => loadDemo(d)}>
                  Load this example
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick advice for writing inputs and reading outputs */}
      <Card className="w-full">
        <CardContent className="p-6 space-y-2 text-sm">
          <h2 className="text-lg font-semibold">Tips</h2>
          <ul className="list-disc ml-5 space-y-1">
            <li>
              Use everyday concepts for easier understanding — like animals, traits,
              or simple preferences.
            </li>
            <li>
              Group with parentheses for clarity:{" "}
              <InlineMath math={toTex("(bird && penguin) => swims")} />.
            </li>
            <li>
              ∞ rank rules never apply in cautious inference (Rational Closure).
            </li>
            <li>
              Lexicographical Closure sometimes accepts queries Rational Closure
              rejects, especially when more specific rules exist.
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
