/*
 * File: NLMappingDemo.tsx
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Demo component that loads NL resources, derives symbolic rules,
 *          auto-assigns atoms, and renders a searchable table.
 * Purpose: Educational use only.
 */

import React, { useEffect, useMemo, useState } from "react";
import { InlineMath } from "react-katex";
function toTexNL(sym: string): string {
  if (!sym) return "";
  let s = sym.replace(/\s+/g, " ").trim();
  // operators (longer patterns first)
  s = s.replace(/<->/g, "\\leftrightarrow ");
  s = s.replace(/~>/g, "\\mid\\!\\sim "); // defeasible implication
  s = s.replace(/->/g, "\\to ");           // material implication
  s = s.replace(/\|\|/g, "\\lor ");
  s = s.replace(/&&/g, "\\land ");
  // negation patterns: !(x) or !x
  s = s.replace(/!\s*\(/g, "\\lnot (");
  s = s.replace(/!\s*([A-Za-z][A-Za-z0-9_]*)/g, "\\lnot $1");
  return s;
}

/**
 * NLMappingDemo (computed, single-file, defensive)
 * - Fetch one JSON/NDJSON from /api/nl or /nl
 * - Accepts Array JSON, NDJSON, or {rules|rows|data}
 * - Computes simple NL sentences for (~>, ->, negation)
 * - Auto-assigns symbols to phrases when needed
 * - Renders a small KB map (symbols → phrases)
 */

const API_BASE = import.meta.env.VITE_BACKEND_URL ?? "http://localhost:8080/api";
const FRONT_BASE = import.meta.env.BASE_URL || "/"; // e.g. "/" or "/app/"

const FILE_OPTIONS = [
  { label: "Structured output", path: "JsonStructuredAIOutput.json" },
  { label: "Manual sentences", path: "ManualJsonSentences.json" },
];

// ---------------- types ----------------

type RuleRow = {
  symbolic?: string;
  atoms?: Record<string, string>;
  sections?: { part1?: string; part2?: string };
  rank?: number;
  sentence?: string; // optional direct sentence
  [k: string]: any;
};

// ---------------- parsing helpers (DEFENSIVE) ----------------

function detectOp(symbolic: unknown): "DEF" | "MAT" | "UNKNOWN" {
  // Quick operator detection for (~>) or (->)
  if (typeof symbolic !== "string" || !symbolic) return "UNKNOWN";
  if (symbolic.includes("~>")) return "DEF"; // defeasible
  if (symbolic.includes("->")) return "MAT"; // material
  return "UNKNOWN";
}

function splitSides(symbolic: unknown): { lhs: string; rhs: string } {
  // Split into LHS/RHS on first occurrence of ~> or ->
  const s = typeof symbolic === "string" ? symbolic : "";
  const i = s.indexOf("~>");
  const j = s.indexOf("->");
  if (i >= 0) return { lhs: s.slice(0, i).trim(), rhs: s.slice(i + 2).trim() };
  if (j >= 0) return { lhs: s.slice(0, j).trim(), rhs: s.slice(j + 2).trim() };
  return { lhs: s.trim(), rhs: "" };
}

function stripParens(s: string) {
  // Remove a single matching pair of () or []
  const t = s?.trim?.() ?? "";
  if ((t.startsWith("(") && t.endsWith(")")) || (t.startsWith("[") && t.endsWith("]"))) {
    return t.slice(1, -1).trim();
  }
  return t;
}

function isNegated(term: string) {
  // negation test
  return !!term && (term.startsWith("!") || term.startsWith("¬") || term.startsWith("not "));
}

function normalizeAtomKey(term: string) {
  let x = (term || "").trim();
  if (x.startsWith("!")) x = x.slice(1).trim();
  x = stripParens(x);
  return x;
}

function humanizeTerm(term: string, atoms: Record<string, string>) {
  // Map a symbolic term to a human phrase, with basic negation handling
  const neg = isNegated(term);
  const key = normalizeAtomKey(term);
  const phrase = atoms?.[key] ?? atoms?.[key.toLowerCase?.() || key] ?? key;
  return neg ? `not ${phrase}` : phrase;
}

function computeSentence(row: RuleRow) {
  // Build an English sentence from row info
  if (typeof row?.sentence === "string" && row.sentence.trim()) return row.sentence;

  if (typeof row?.symbolic === "string" && row.symbolic.trim()) {
    const op = detectOp(row.symbolic);
    const { lhs, rhs } = splitSides(row.symbolic);
    const atoms = row?.atoms || {};
    const L = humanizeTerm(lhs || "", atoms);
    const R = humanizeTerm(rhs || "", atoms);
    switch (op) {
      case "DEF": return `Typically, ${L} implies ${R}.`;
      case "MAT": return `If ${L}, then ${R}.`;
      default: return (L && R) ? `${L} therefore ${R}` : (L || R || "");
    }
  }

  // Fallback for "sections" rows without symbolic form
  if (row?.sections && (row.sections.part1 || row.sections.part2)) {
    const L = (row.sections.part1 ?? "").trim();
    const R = (row.sections.part2 ?? "").trim();
    if (L && R) return `Typically, ${L.replace(/^[()]/, "").replace(/[()]$/, "")} implies ${R.replace(/^[()]/, "").replace(/[()]$/, "")}.`;
    return L || R || "";
  }
  return "";
}

function label(n: number): string {
  n = n % 26;
  return String.fromCharCode(97 + n);
}

function stripLeadingNeg(s: string) {
  // Remove a leading negation for symbol assignment
  return s.replace(/^(\!|¬|not\s+)/i, "").trim();
}

function enrichWithAutoSymbols(rows: RuleRow[]) {
  // Assign symbols to phrases if missing
  const used = new Set<string>();
  const phraseToSym = new Map<string, string>();
  const symToPhrase = new Map<string, string>();

  // Seed maps from any explicit atoms
  for (const r of rows) {
    const atoms = r?.atoms || {};
    for (const [sym, phrase] of Object.entries(atoms)) {
      used.add(sym);
      phraseToSym.set(phrase, sym);
      symToPhrase.set(sym, phrase);
    }
  }

  // Allocate a new symbol when needed
  const nextLabel = () => {
    let s = "";
    do { s = label(Math.floor(Math.random() * 2000)); } while (used.has(s));
    used.add(s);
    return s;
  };

  const ensureSymbolFor = (phrase?: string | null) => {
    const p = (phrase || "").trim();
    if (!p) return null;
    if (!phraseToSym.has(p)) {
      const sym = nextLabel();
      phraseToSym.set(p, sym);
      symToPhrase.set(sym, p);
    }
    return phraseToSym.get(p)!;
  };

  // Build enriched rows: ensure atoms + symbolic are present
  const rows2: RuleRow[] = rows.map(r => {
    const atoms = { ...(r.atoms || {}) };
    let symbolic = r.symbolic?.trim();

    if (!symbolic && r.sections) {
      const rawL = r.sections.part1 || "";
      const rawR = r.sections.part2 || "";

      const negL = isNegated(rawL);
      const negR = isNegated(rawR);

      const phrL = stripParens(stripLeadingNeg(rawL));
      const phrR = stripParens(stripLeadingNeg(rawR));

      const sL = ensureSymbolFor(phrL);
      const sR = ensureSymbolFor(phrR);

      if (sL && sR) {
        const lhs = negL ? `!(${sL})` : sL;
        const rhs = negR ? `!(${sR})` : sR;
        symbolic = `${lhs} ~> ${rhs}`;
      }

      if (sL && !atoms[sL]) atoms[sL] = phrL;
      if (sR && !atoms[sR]) atoms[sR] = phrR;
    }

    return { ...r, atoms, symbolic };
  });

  // Export a KB mapping 
  const kbPairs = Array.from(symToPhrase.entries())
    .sort((a, b) => a[0].localeCompare(b[0]));

  return { rows2, kbPairs };
}

async function httpGet(url: string) {
  // GET wrapper; returns raw text
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
  const text = await res.text();
  return { text, url };
}

function normalizeToRows(payload: any): RuleRow[] {
  // Accept: array, {rules|rows|data}, or NDJSON lines
  if (Array.isArray(payload)) return payload as RuleRow[];

  if (payload && typeof payload === "object") {
    const candidate = (payload.rules || payload.rows || payload.data) as any;
    if (Array.isArray(candidate)) return candidate as RuleRow[];
  }

  if (typeof payload === "string") {
    const rows: RuleRow[] = [];
    for (const line of payload.split(/\r?\n/)) {
      const t = line.trim();
      if (!t) continue;
      try { rows.push(JSON.parse(t)); } catch { /* ignore non-JSON lines */ }
    }
    if (rows.length > 0) return rows;
  }

  throw new Error("Unsupported JSON shape: expected array, {rules|rows|data}, or NDJSON");
}

async function loadOne(file: string): Promise<{ source: string; rows: RuleRow[] }> {
  // Tries the backend path (/api/nl) first then the static path (/nl)
  const candidates = [
    `${API_BASE}/nl/${file}`,
    `${FRONT_BASE.replace(/\/$/, "")}/nl/${file}`,
  ];
  let lastErr: unknown = null;
  for (const u of candidates) {
    try {
      console.debug("[NLMappingDemo] GET", u);
      const { text, url } = await httpGet(u);
      let parsed: any; try { parsed = JSON.parse(text); } catch { parsed = text; }
      const rows = normalizeToRows(parsed);
      return { source: url, rows };
    } catch (e) { lastErr = e; }
  }
  throw new Error(`Could not load ${file} from /api/nl or /nl. Last error: ${String(lastErr)}`);
}

export default function NLMappingDemo() {
  const [rows, setRows] = useState<RuleRow[]>([]);
  const [sources, setSources] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<"ALL" | "DEF" | "MAT">("ALL");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(FILE_OPTIONS[0]);

  useEffect(() => {
    // Load on mount / when file selection changes
    let cancelled = false;
    (async () => {
      setLoading(true); setError(null); setRows([]); setSources([]);
      try {
        const { source, rows } = await loadOne(selected.path);
        if (!cancelled) { setRows(rows); setSources([source]); }
      } catch (e: any) {
        if (!cancelled) setError(e?.message ?? String(e));
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [selected.path]);

  const { rows2, kbPairs } = useMemo(() => enrichWithAutoSymbols(rows), [rows]);

  // Builds KB map for display
  const kbMap = kbPairs;

  // Prepare computed table rows 
  const computed = useMemo(() => {
    const base = rows2.filter(r => typeof r.symbolic === "string" && r.symbolic!.length > 0);
    let enriched = base.map((r, idx) => ({
      idx,
      op: detectOp(r.symbolic),
      rank: r.rank ?? 0,
      sentence: computeSentence(r),
      symbolic: r.symbolic as string,
    }));
    // Apply operator filter if set
    if (filter !== "ALL") enriched = enriched.filter(e => e.op === filter);
    // text search across symbolic and sentence
    if (query.trim()) {
      const q = query.toLowerCase();
      enriched = enriched.filter(e => e.symbolic.toLowerCase().includes(q) || e.sentence.toLowerCase().includes(q));
    }
    // Sort by (rank, then original index)
    return enriched.sort((a, b) => (a.rank - b.rank) || (a.idx - b.idx));
  }, [rows2, filter, query]);

  // summary of how many rows per rank
  const rankBuckets = useMemo(() => {
    const map = new Map<number, number>();
    for (const r of rows2) map.set(r.rank ?? 0, (map.get(r.rank ?? 0) ?? 0) + 1);
    return Array.from(map.entries()).sort((a, b) => a[0] - b[0]);
  }, [rows2]);

  return (
    <div className="p-4 flex flex-col gap-4 h-full">
      {/* Header + fetched source(s) */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="font-semibold text-base">NL Mapping Demo (computed)</div>
        {sources.length > 0 && (
          <div className="flex gap-2 text-xs flex-wrap">
            {sources.map((s, i) => (
              <a key={i} className="underline opacity-80" href={s} target="_blank" rel="noreferrer">source {i + 1}</a>
            ))}
          </div>
        )}
      </div>

      {/* Controls: file selector, operator filter, search */}
      <div className="flex flex-wrap items-center gap-2">
        <label className="text-sm">File:</label>
        <select
          className="border rounded px-2 py-1"
          value={selected.path}
          onChange={(e) => {
            const found = FILE_OPTIONS.find(f => f.path === e.target.value)!;
            setSelected(found);
          }}
        >
          {FILE_OPTIONS.map((f) => (
            <option key={f.path} value={f.path}>{f.label}</option>
          ))}
        </select>

        <label className="text-sm ml-2">Filter:</label>
        <select className="border rounded px-2 py-1" value={filter} onChange={(e) => setFilter(e.target.value as any)}>
          <option value="ALL">All</option>
          <option value="DEF">Defeasible (~&gt;)</option>
          <option value="MAT">Material (-&gt;)</option>
        </select>

        <input
          className="border rounded px-2 py-1 ml-2 flex-1 min-w-[12rem]"
          placeholder="Search…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      {/* KB map: simple view of atoms */}
      <div className="border rounded-lg p-3">
        <div className="font-semibold text-sm mb-2">KB (symbols → phrases)</div>
        {kbMap.length === 0 ? (
          <div className="text-xs opacity-70">No atoms found.</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-1 text-sm">
            {kbMap.map(([k, v]) => (
              <div key={k} className="flex gap-2"><span className="font-mono font-semibold">{k}</span><span className="opacity-80">→</span><span>{v}</span></div>
            ))}
          </div>
        )}
      </div>

      {/* Table: computed rows with KaTeX preview and NL sentence */}
      {loading && <div className="text-sm opacity-70">Loading…</div>}
      {error && <div className="text-sm text-red-600">Error: {error}</div>}

      {!loading && !error && (
        <div className="relative border rounded-lg overflow-auto max-h-[65vh]">
          <table className="min-w-full text-sm">
            <thead className="sticky top-0 bg-gray-50 shadow-[inset_0_-1px_0_0_rgba(0,0,0,0.06)]">
              <tr>
                <th className="text-left px-3 py-2 w-12">#</th>
                <th className="text-left px-3 py-2 w-16">Rank</th>
                <th className="text-left px-3 py-2">Symbolic</th>
                <th className="text-left px-3 py-2">Computed explanation</th>
              </tr>
            </thead>
            <tbody>
              {computed.length === 0 ? (
                <tr><td className="px-3 py-3 text-sm opacity-70" colSpan={4}>No rows match.</td></tr>
              ) : (
                computed.map((r, i) => (
                  <tr key={r.idx} className="odd:bg-white even:bg-gray-50 hover:bg-gray-100 transition-colors">
                    <td className="px-3 py-2">{i + 1}</td>
                    <td className="px-3 py-2">{r.rank}</td>
                    <td className="px-3 py-2 whitespace-pre-wrap break-words">
                      <InlineMath math={toTexNL(r.symbolic)} />
                    </td>
                    <td className="px-3 py-2 whitespace-pre-wrap break-words">{r.sentence}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Footer: simple counts per rank */}
      <div className="text-xs opacity-70">{rows2.length} rows • ranks: {rankBuckets.map(([r, c]) => `${r}(${c})`).join(", ")}</div>
    </div>
  );
}
