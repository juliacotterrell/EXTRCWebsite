// src/components/MainContent/MainContent.tsx
/*
 * File: MainContent.tsx
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town) University of Cape Town)
 * Status: Original work.
 * Context: React component for displaying the main content including all panels.
 * Purpose: Educational use only.
 */

import React, { useState, useRef, useEffect } from "react";
import { QueryCard } from "./QueryCard";
import { KnowledgeBaseCard } from "./KnowledgeBaseCard";
import { Tabs } from "../ui/Tabs";
import { SummaryPanel } from "./SummaryPanel";
import { BaseRankPanel } from "./BaseRankPanel";
import { RationalClosurePanel } from "./RationalClosurePanel";
import { handleQueryRequest } from "@/lib/entailment";
import ViewToggle from "../ui/ViewToggle";

export type ViewMode = "explanatory" | "math";

export type RankingLevel = { rankNumber: number; formulas: string[] };
export type QueryResponse = {
  error?: string;
  entailed?: boolean;
  timeTaken?: number;
  baseRanking?: RankingLevel[];
  removedRanking?: RankingLevel[];
  negation?: string;
  strategyTimes?: Record<string, number>;
};

export function MainContent() {
  // Demo defaults (KB + example query)
  const [kb, setKb] = useState<string[]>(["(penguins=>birds)", "(birds~>fly)", "(birds~>wings)", "(penguins~>!fly)"]);
  const [query, setQuery] = useState("penguins ~> birds");

  // Loading state while calling backend
  const [loading, setLoading] = useState(false);

  // Base rank (sequence of ranks with formulas)
  const [baseRanking, setBaseRanking] = useState<RankingLevel[]>([]);

  // Rational closure response payload
  const [ratResponse, setRatResponse] = useState<QueryResponse>({});

  // Track whether we populated KB from localStorage/upload
  const hydratedRef = useRef(false);

  // UI tab selection
  const [tab, setTab] = useState<"Summary" | "Base Rank" | "Rational Closure">("Summary");

  // View mode (persist to localStorage)
  const [viewMode, setViewMode] = useState<ViewMode>(() => {
    return (localStorage.getItem("viewMode") as ViewMode) || "explanatory";
  });

  // Persist view mode
  useEffect(() => {
    localStorage.setItem("viewMode", viewMode);
  }, [viewMode]);

  // Keyboard shortcut: press "m" to toggle view mode
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() === "m") {
        setViewMode((v) => (v === "explanatory" ? "math" : "explanatory"));
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // Call backend to compute base rank + rational closure
  const handleEntailment = async () => {
    const t0 = performance.now();
    setLoading(true);
    try {
      const results = await handleQueryRequest(kb, query);
      const t1 = performance.now();
      console.log("[API] /base-rank + /entailment/rational response:", results);
      console.log(`[Timing] Frontend total: ${(t1 - t0).toFixed(2)} ms`);

      // Save base ranking for both panels
      setBaseRanking(results.baseRanking);

      // Save rational closure details
      setRatResponse({
        entailed: results.rational.entailed,
        baseRanking: results.baseRanking,
        removedRanking: results.rational.removedRanking,
        negation: results.rational.negation,
        timeTaken: results.rational.timeTaken,
        strategyTimes: results.rational.strategyTimes
      });
    } catch (err) {
      console.error("Query failed:", err);
    } finally {
      setLoading(false);
      console.groupEnd();
    }
  };

  // Hydrate KB/query from a local demo payload if present
  useEffect(() => {
    const raw = localStorage.getItem("extrc.demo");
    if (!raw) return;
    try {
      const demo = JSON.parse(raw) as { kb: string[]; query?: string };
      if (Array.isArray(demo.kb) && demo.kb.length > 0) {
        setKb(() => [...demo.kb]);
        console.log(kb)
        if (typeof demo.query === "string") setQuery(demo.query);
        hydratedRef.current = true;
        console.info("[Main] KB hydrated from demo:", demo.kb);
      }
    } catch (e) {
      console.warn("[Main] Bad demo payload:", e);
    } finally {
      setLoading(false);
      localStorage.removeItem("extrc.demo");
    }
  }, []);

  // Basic debug when KB changes
  useEffect(() => {
    console.log("[kb changed]", kb);
  }, [kb]);

  // Handle upload from KnowledgeBaseCard
  const handleUpload = (formulas: string[]) => {
    setKb(formulas);
    hydratedRef.current = true;
    console.info("[Main] KB uploaded:", kb);
  };

  return (
    <div className="flex-1 w-full p-6 space-y-10 font-sans overflow-auto">
      {/* Input cards: query + knowledge base */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 w-full px-4">
        <QueryCard
          query={query}
          onEdit={() => setQuery(prompt("Edit Query", query) || query)}
          onQuery={handleEntailment}
          loading={loading}
        />
        <KnowledgeBaseCard
          kb={kb}
          onEdit={() => {
            const raw = prompt("Edit KB (comma-separated)", kb.join(", "));
            if (raw !== null) setKb(raw.split(/\s*,\s*/));
          }}
          onUpload={handleUpload}
        />
      </div>

      {/* Tabs for output panels */}
      <Tabs
        tabs={["Summary", "Base Rank", "Rational Closure"]}
        current={tab}
        onSelect={t => {
          setTab(t as any);
          console.log(`[UI] Tab selected → ${t}`);
        }}
      />

      {/* Render panels */}
      {(ratResponse.entailed !== undefined || baseRanking.length > 0) ? (
        <div className="mt-8 p-6 space-y-4 rounded-md border bg-background shadow-sm">
          {/* Show view toggle for panels that support it */}
          {(tab === "Base Rank" || tab === "Rational Closure") && (
            <div className="mt-2 mb-3 flex items-center justify-center">
              <ViewToggle value={viewMode} onChange={setViewMode} />
            </div>
          )}

          {/* Summary panel */}
          {tab === "Summary" && (
            <SummaryPanel
              query={query}
              rational={ratResponse}
              kb={kb}
              baseRanking={baseRanking}
            />
          )}

          {/* Base rank construction and table */}
          {tab === "Base Rank" && baseRanking.length > 0 && (
            <BaseRankPanel
              viewMode={viewMode}
              baseRanking={baseRanking}
              kb={kb}
              query={query}
              negation={ratResponse.negation}
            />
          )}

          {/* Rational closure visualisation (needs removedRanking + baseRanking) */}
          {tab === "Rational Closure" &&
            ratResponse.removedRanking && baseRanking.length > 0 && (
              <RationalClosurePanel
                removedRanking={ratResponse.removedRanking ?? []}
                baseRanking={baseRanking}
                entailed={!!ratResponse.entailed}
                negation={ratResponse.negation}
                query={query}
                kb={kb}
                viewMode={viewMode}
                strategyTimes={ratResponse.strategyTimes}
              />
            )}
        </div>

      ) : (
        <p className="text-center italic">
          No results yet. Click “Query” to run the reasoning process.
        </p>
      )}
    </div>
  );
}
