// src/components/MainContent/RationalClosurePanel.tsx
/*
 * File: RationalClosurePanel.tsx
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: React component for displaying the mathematical and explanatory versions of rational closure. 
 * Purpose: Educational use only.
 */

import React, { useMemo } from "react";
import { InlineMath } from "react-katex";
import { toTex } from "@/lib/formula";
import type { RankingLevel } from "./MainContent";
import { RankingTable } from "../ui/rankingTable";
import { parseQueryParts } from "@/lib/queryUtils";
import { materializeRanking } from "@/lib/materialize";
import { ViewMode } from "./MainContent";

type Props = {
  removedRanking: RankingLevel[];
  baseRanking: RankingLevel[];
  entailed: boolean;
  negation?: string;
  query?: string;
  kb: string[];
  viewMode: ViewMode;
  strategyTimes?: Record<string, number>
};

export function RationalClosurePanel({
  removedRanking,
  baseRanking,
  entailed,
  negation,
  query,
  kb,
  viewMode,
  strategyTimes
}: Props) {
  // Compute the final ranking by removing formulas flagged as "removed"
  const finalRanking = useMemo<RankingLevel[]>(() => {
    return baseRanking
      .map(level => {
        const removed = removedRanking.find(r => r.rankNumber === level.rankNumber);
        const removedSet = new Set(removed?.formulas ?? []);
        return {
          rankNumber: level.rankNumber,
          formulas: level.formulas.filter(f => !removedSet.has(f)),
        };
      })
      .filter(lvl => lvl.formulas.length > 0);
  }, [baseRanking, removedRanking]);

  // Quick stats about how many formulas were in base, removed, and retained
  const stats = useMemo(() => {
    const baseTotal = baseRanking.reduce((s, r) => s + r.formulas.length, 0);
    const removedTotal = removedRanking.reduce((s, r) => s + r.formulas.length, 0);
    const finalTotal = finalRanking.reduce((s, r) => s + r.formulas.length, 0);
    return { baseTotal, removedTotal, finalTotal };
  }, [baseRanking, removedRanking, finalRanking, kb]);

  // Split query into parts (α, β, operator)
  const { left, right, op } = useMemo(() => parseQueryParts(query), [query]);

  return (
    <div className="space-y-6">
      {/* ===================== QUERY RESULT ===================== */}
      <div>
        <h4 className="font-medium mb-1">Query Result</h4>
        <p className="text-sm">
          The query&nbsp;
          <InlineMath math={query ? toTex(query) : "??"} />&nbsp;
          is{" "}
          {entailed ? (
            <span className="text-green-700 font-semibold">entailed</span>
          ) : (
            <>
              <span className="text-red-700 font-semibold">not entailed</span>
              {negation ? (
                <>
                  {" "}— considered negation:&nbsp;
                  <InlineMath math={toTex(negation)} />
                </>
              ) : null}
            </>
          )}
          .
        </p>
      </div>

      {/* ===================== EXPLANATORY MODE ===================== */}
      {viewMode === "explanatory" && (
        <>
          {/* Short explanation of what rational closure checks */}
          <div className="rounded border p-3 text-sm space-y-2">
            <p className="text-muted-foreground">
              Rational closure checks the <strong>least-exceptional level</strong> where{" "}
              <InlineMath math={toTex(left ?? "α")} /> is consistent with the accepted
              ranks and asks whether the strict core entails{" "}
              <InlineMath math={toTex(`${left ?? "α"} => ${right ?? "β"}`)} />.
            </p>
          </div>

          {/* Longer explanation of the decision rule */}
          <section className="text-sm text-gray-800 leading-relaxed space-y-2">
            <h4 className="font-medium">What is decided here?</h4>
            <p>
              We accept{" "}
              <InlineMath math={toTex(`${left ?? "α"} ~> ${right ?? "β"}`)} /> when{" "}
              <strong>the base rank of</strong> <InlineMath math={toTex(left ?? "α")} />{" "}
              is <strong>lower</strong> than the base rank of{" "}
              <InlineMath math={toTex(`${left ?? "α"} && !(${right ?? "β"})`)} />
              , or when <InlineMath math={toTex(left ?? "α")} /> has infinite rank. This
              is the standard rational-closure condition, expressed with your symbols.
            </p>
          </section>

          {/* Walkthrough of steps */}
          <div className="rounded border p-3 text-sm space-y-2 bg-gray-50">
            <h4 className="font-medium">Step-by-step reasoning for this query</h4>
            <ol className="list-decimal list-inside space-y-1">
              <li>Start from the <strong>Base Ranking</strong>, which orders defaults from least to most exceptional.</li>
              <li>Check if <InlineMath math={toTex(left ?? "α")} /> is <em>exceptional</em> at the current rank.</li>
              <li>If exceptional, remove that rank’s defaults and move up to the next rank.</li>
              <li>Once it is no longer exceptional, check whether the remaining rules entail <InlineMath math={toTex(`${left ?? "α"} => ${right ?? "β"}`)} />.</li>
            </ol>
          </div>

          {/* Highlight what changed between base and final */}
          <div className="rounded border p-3 text-sm bg-blue-50">
            <h4 className="font-medium">What changed between Base and Final?</h4>
            <p>
              In rational closure, formulas are removed when they belong to ranks that
              make the query’s antecedent inconsistent. Remaining rules can still support
              the conclusion if they don’t conflict.
            </p>
          </div>
        </>
      )}
      {/* ===================== MATHEMATICAL MODE ===================== */}
      {viewMode === "math" && (
        <>
          {/* General mathematical definition of rational closure */}
          <p className="text-sm">
            Rational closure can be characterised in terms of base ranks. For a knowledge base{" "}
            <InlineMath math="\mathcal{K}" /> and formula{" "}
            <InlineMath math="\alpha" />, let{" "}
            <InlineMath math={`br_\\mathcal{K}(\\alpha)`} /> be the smallest{" "}
            <InlineMath math="r" /> such that{" "}
            <InlineMath math="\mathcal{E}^\mathcal{K}_r \not\vDash_R \top \mid\!\sim \lnot \alpha" />, or{" "}
            <InlineMath math="\infty" /> if no such{" "}
            <InlineMath math="r" /> exists.
          </p>

          {/* Formal condition */}
          <div className="ml-6 mt-2">
            <InlineMath math="br_\mathcal{K}(\alpha) \equiv_{\mathrm{def}} \min \{ r \mid \mathcal{E}^\mathcal{K}_r \not\vDash_R \top \mid\!\sim \lnot \alpha \}" />
          </div>
          <p className="text-sm mt-4">Then the rational-closure entailment condition is:</p>
          <div className="ml-6">
            <InlineMath math="\mathcal{K} \vDash_{RC} \alpha \mid\!\sim \beta \quad \text{iff} \quad br_\mathcal{K}(\alpha) < br_\mathcal{K}(\alpha \land \lnot \beta) \;\; \text{or} \;\; br_\mathcal{K}(\alpha) = \infty" />
          </div>

          {/* Instantiated with current query */}
          {left && right && (
            <div className="ml-6 mt-4 p-3 border rounded bg-gray-50 text-sm">
              <p className="font-medium mb-1">For your current query:</p>
              <p>
                <InlineMath math={`\\alpha = ${toTex(left)}`} />,{" "}
                <InlineMath math={`\\beta = ${toTex(right)}`} />, and{" "}
              </p>
              <p>
                <InlineMath math="\mathcal{K} = \{" />
                {kb.map((f, i) => (
                  <React.Fragment key={i}>
                    <InlineMath math={toTex(f)} />
                    {i < kb.length - 1 && <>, </>}
                  </React.Fragment>
                ))}
                <InlineMath math="\}" />.
              </p>
              <p className="mt-2">
                Hence we evaluate:
              </p>
              <div className="mt-1">
                <InlineMath
                  math={`br_\\mathcal{K}${toTex(left)}) < br_\\mathcal{K}${toTex(
                    `${left} && !(${right}`
                  )}) \\;\\; \\text{or} \\;\\; br_\\mathcal{K}${toTex(left)}) = \\infty`}
                />
              </div>
            </div>
          )}
        </>
      )}

      {/* ===================== TABLES ===================== */}
      <RankingTable title="Initial Base Ranking" ranking={materializeRanking(baseRanking)} />
      <RankingTable
        title="Removed Formulas"
        ranking={materializeRanking(removedRanking)}
        colorClass="text-red-700"
      />
      <RankingTable
        title="Final Retained Ranking"
        ranking={finalRanking}
        colorClass="text-green-700"
      />

      {/* Quick data summary */}
      <div className="rounded border p-3 text-sm bg-green-50">
        <h4 className="font-medium">Why this verdict?</h4>
        {entailed ? (
          <p>
            The retained rules still allow us to derive{" "}
            <InlineMath math={toTex(`${left ?? "α"} => ${right ?? "β"}`)} /> from the strict core.
          </p>
        ) : (
          <p>
            After removing conflicting defaults, no remaining combination entailed{" "}
            <InlineMath math={toTex(`${left ?? "α"} => ${right ?? "β"}`)} />.
          </p>
        )}
      </div>

      {/* Performance timing (if available) */}
      {strategyTimes && (
        <div className="rounded border p-3 text-sm mt-4 bg-gray-50">
          <h4 className="font-medium mb-2">Strategy performance</h4>
          <ul className="space-y-1">
            {Object.entries(strategyTimes).map(([name, ms]) => (
              <li key={name}>
                <span className="font-mono">{name}</span>: {ms.toFixed(2)} ms
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
