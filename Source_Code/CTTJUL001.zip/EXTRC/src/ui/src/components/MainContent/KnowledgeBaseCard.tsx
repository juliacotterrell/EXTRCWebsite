// src/components/MainContent/KnowledgeBaseCard.tsx
/*
 * File: KnowledgeBaseCard.tsx
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: React component for inputting the knowledge base
 * Purpose: Educational use only.
 */

import React, { useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { InlineMath } from "react-katex";
import { toTex } from "@/lib/formula";
import { handleKbUpload } from "@/lib/uploadKnowledgeBase";

export function KnowledgeBaseCard({
  kb,
  onEdit,
  onUpload
}: {
  kb: string[];
  onEdit: () => void;
  onUpload: (formulas: string[]) => void;
}) {
  // File input ref for triggering hidden <input type="file" />
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Open file selector
  const triggerUpload = () => fileInputRef.current?.click();

  // Read .txt file and convert to formulas via helper
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const formulas = await handleKbUpload(file);
    onUpload(formulas);
  };

  return (
    <Card>
      <CardContent className="text-center p-6 space-y-4">
        <h2 className="text-lg font-semibold">Knowledge Base (𝒦)</h2>

        {/* Compact preview of KB: show first/last few items with an ellipsis */}
        <p className="text-xl">
          {(() => {
            const limit = 5;      // how many items to show at head/tail
            const n = kb.length;
            let display: string[] = [];

            if (n <= limit * 2) {
              display = kb;
            } else {
              display = [
                ...kb.slice(0, limit),
                "...",
                ...kb.slice(n - limit),
              ];
            }

            return display.map((cl, i) => (
              <React.Fragment key={i}>
                {cl === "..." ? (
                  <span className="mx-2">…</span>
                ) : (
                  <InlineMath math={toTex(cl)} />
                )}
                {i < display.length - 1 && ", "}
              </React.Fragment>
            ));
          })()}
        </p>

        {/* Actions: upload KB from file or open editor */}
        <div className="flex justify-center gap-4">
          <Button variant="outline" onClick={triggerUpload}>Upload</Button>
          <Button variant="outline" onClick={onEdit}>Edit</Button>

          {/* Hidden file input for .txt knowledge base files */}
          <input
            type="file"
            accept=".txt"
            ref={fileInputRef}
            className="hidden"
            onChange={handleFileChange}
          />
        </div>
      </CardContent>
    </Card>
  );
}
