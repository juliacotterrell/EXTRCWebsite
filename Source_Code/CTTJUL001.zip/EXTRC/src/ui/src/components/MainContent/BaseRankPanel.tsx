// src/components/MainContent/BaseRankPanel.tsx
/*
 * File: BaseRankPanel.tsx
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town) University of Cape Town)
 * Status: Original work.
 * Context: React component for displaying the base rank.
 * Purpose: Educational use only.
 */

import React, { useMemo } from "react";
import { InlineMath } from "react-katex";
import { RankingTable } from "../ui/rankingTable";
import { toTex, toTexMat } from "@/lib/formula";
import type { RankingLevel } from "./MainContent";
import BaseRankStepper, {Step} from '@/components/ui/BaseRankStepper'
import { setPreviewTex } from '@/lib/latexUtils'
import { materializeKB, materializeRanking} from "@/lib/materialize";
import { ViewMode } from "./MainContent";

/**
 * Basic English rendering for quick explanations in the UI.
 * Very lightweight replacement of symbols so users can skim.
 */
function toEnglish(formula: string): string {
  return formula
    .replace(/~>/g, " typically are ")
    .replace(/=>/g, " are ")
    .replace(/<=>/g, " is equivalent to ")
    .replace(/&&/g, " and ")
    .replace(/\|\|/g, " or ")
    .replace(/!/g, "not ")
    .replace(/\b/g, " ")
    .replace(/\s+/g, " ") 
    .trim();
}

/** Props for BaseRankPanel */
type Props = {
  /** Final base ranking result (each level with formulas). */
  baseRanking: RankingLevel[];
  /** Original knowledge base strings. */
  kb: string[];
  /** Current user query (string form). */
  query: string;    
  /** Optional negation display for explanations. */
  negation?: string
  /** Switch between explanatory vs compact (formal) view. */
  viewMode: ViewMode
};

/** Helper: treat very large rank numbers as inifinite rank in the UI. */
const isInfiniteRank = (rank: number) => rank>999;

/**
 * Main panel for showing:
 * - a stepper view of the BaseRank construction, and
 * - the resulting ranking table
 */
export function BaseRankPanel({ baseRanking, kb, query, negation, viewMode }: Props) {
  // Fallback negation symbol for math display
  const negationTex = toTex(negation ?? "\\lnot \\alpha");

  /**
   * Quick stats to reference in text:
   * - sizes of R0 and R∞
   * - count of finite ranks
   * - total formulas placed across all ranks
   */
  const stats = useMemo(() => {
    const finite = baseRanking.filter(r => !isInfiniteRank(r.rankNumber));
    const infinite = baseRanking.find(r => isInfiniteRank(r.rankNumber));
    const r0 = baseRanking.find(r => r.rankNumber === 0);
    const totalInRanks = baseRanking.reduce((s, r) => s + r.formulas.length, 0);
    return {
      kSize: kb.length,
      rankCount: finite.length,
      r0Size: r0?.formulas.length ?? 0,
      rInfSize: infinite?.formulas.length ?? 0,
      r0Formulas: r0?.formulas ?? [],
      rInfFormulas: infinite?.formulas ?? [],
      totalPlaced: totalInRanks
    };
  }, [baseRanking, kb]);

  // Materialized versions (convert ~> to => for preview/stepper clarity)
  const materializedKB   = useMemo(() => materializeKB(kb), [kb]);
  const materializedRank = useMemo(() => materializeRanking(baseRanking), [baseRanking]);

  /**
   * Build step-by-step rows for the BaseRankStepper.
   * Each step shows E_i, removed exceptionals to get E_{i+1}, and Ri.
   */
  const rankSteps: Step[] = useMemo(() => {
    let Ei = materializedRank
      .filter(r => Number.isFinite(r.rankNumber))
      .sort((a, b) => a.rankNumber - b.rankNumber)
      .flatMap(r => r.formulas);

    const rows: Step[] = [];

    const finite = materializedRank
      .filter(r => Number.isFinite(r.rankNumber))
      .sort((a, b) => a.rankNumber - b.rankNumber);

    for (const { rankNumber: i, formulas: Ri } of finite) {
      // E_{i+1} = E_i \ Ri (remove exceptionals at this level)
      const EiPlus1 = Ei.filter(f => !Ri.includes(f));

      // logging left in for debugging
      console.log("Ei: ")
      console.log(Ei)
      console.log("Ri: " )
      console.log(Ri)
      console.log("Ei plus 1: " )
      console.log(EiPlus1)
      console.log(
        `Iteration ${i}: Ei had ${Ei.length}, Ri had ${Ri.length}, Ei+1 has ${EiPlus1.length}`
      );

      // description blocks rendered by the stepper
      const desc: React.ReactNode[] = [
        <>
          Start <InlineMath math="\Large \varepsilon" /><sub>{i}</sub> = <InlineMath math={setPreviewTex(Ei)} />.
        </>,
        Ri.length > 0 ? (
          <>
            Check which formulas are exceptional at this level.  
            A formula is exceptional if{" "}
            <InlineMath math={negationTex} /> is entailed by <InlineMath math="\Large \varepsilon" /><InlineMath math="_i" />.
            <br />
            Remove exceptional formulas: <InlineMath math={setPreviewTex(EiPlus1)} /> → <InlineMath math="\Large \varepsilon" /><sub>{i+1}</sub>.
          </>
        ) : (
          <>No exceptional formulas at this level.</>
        ),
        <>
          Leaving Rank<sub>{i}</sub> = <InlineMath math={setPreviewTex(Ri)} />.
        </>
      ];

      rows.push({ i, Ei: [...Ei], Ri: [...Ri], EiPlus1, description: desc });
      Ei = EiPlus1;
    }

    if (rows.length) {
      const last = rows[rows.length - 1];
      const remaining = last.Ei;
      rows.push({
        i: "∞",                               
        Ei: [...remaining],
        Ri: [...remaining],                  
        EiPlus1: [],                  
        description: [
          <>
            Identify <InlineMath math="R_\infty" /> and its source level.
          </>,
          <>
            Final group: <InlineMath math={setPreviewTex(remaining)} /> is the last remaining set.
          </>,
          <>
            This set was produced at <InlineMath math="\varepsilon" /> <sub>{last.i}</sub> and now becomes <InlineMath math="R_\infty" />.
          </>,
          <>
            Therefore, assign <InlineMath math={`R_\\infty = E_{${last.i}}`} />.
          </>
        ],
      });
    }

    return rows;
  }, [materializedKB, materializedRank]);

  /**
   * First step shown by the stepper: materialisation hint + show K (raw KB).
   * This is visual guidance only; does not change the underlying data.
   */
  const materialStep: Step = {
    i: "M",
    Ei: [],
    Ri: [],
    EiPlus1: materializedKB,
    description: [
      <>Convert each defeasible conditional into its material form (change all implies to is)</>,
      <>
        <InlineMath math="\Large \varepsilon" /><sub>0</sub> = <InlineMath math={setPreviewTex(kb)} />.
      </>
    ]
  };

  const steps = [materialStep, ...rankSteps];

  return (
    <>
      {viewMode === "explanatory" ? (
        <>
          {/* Explanatory Mode: plain-language overview + stepper + table */}
          <p>
            The BaseRank algorithm takes your knowledge base{" "}
            <InlineMath math="\mathcal{K}" /> with{" "}
            <strong>{stats.kSize}</strong> formulas. The algorithm organises them
            into levels <InlineMath math="R_0, R_1, \ldots, R_{\infty}" /> by
            performing an iterative process to assign a base rank to each
            statement, which indicates its level of typicality or specificity.
            Valuations with a lower rank are considered more normal or typical
            than those with a higher rank.
          </p>

          <section className="mt-6 text-sm text-gray-800 leading-relaxed space-y-4">
            <h3 className="text-base font-semibold">
              Let’s start with unpacking how the base rank is computed
            </h3>

            {query && (
              <div className="space-y-1">
                <p>
                  <span className="font-medium">Your current query:</span>{" "}
                  <InlineMath math={toTex(query)} />
                </p>
                <p>
                  In other words, you are trying to find out if{" "}
                  <span className="italic">{toEnglish(query)}</span> holds, given
                  your current knowledge base.
                </p>
              </div>
            )}

            <p>
              This means we look for the lowest level{" "}
              <InlineMath math="r" /> where the knowledge base{" "}
              <InlineMath math="\large \varepsilon" />{" "}
              <InlineMath math="^{\mathcal{K}}_r" /> supports the defeasible
              inference that <InlineMath math="\lnot \alpha" /> is not typically
              true.
            </p>
          </section>

          <h2 className="text-xl font-bold">Defeasible BaseRank Explorer</h2>
          <BaseRankStepper steps={steps} />

          <RankingTable title="Base Ranking" ranking={materializedRank} />
        </>
      ) : (
        <>
          {/* Formal Mode: compact, definition-first presentation */}
          <p>
            A propositional sentence <InlineMath math="\alpha" /> is said to be{" "}
            <em>exceptional</em> with respect to{" "}
            <InlineMath math="\mathcal{K}" /> if{" "}
            <InlineMath math="\mathcal{K} \vDash_R \top \mid\!\sim \lnot \alpha" />.
          </p>

          <p>
            A sequence of knowledge bases{" "}
            <InlineMath math="\mathcal{E}^\mathcal{K}_0, \mathcal{E}^\mathcal{K}_1, \dots, \mathcal{E}^\mathcal{K}_\infty" />{" "}
            is defined as follows:
          </p>

          <div className="ml-6 mt-2 space-y-2">
            <p>
              <InlineMath math="\mathcal{E}^\mathcal{K}_0 \equiv_{\mathrm{def}} \mathcal{K}" />
            </p>
            <p>
              <InlineMath math="\mathcal{E}^\mathcal{K}_i \equiv_{\mathrm{def}} \varepsilon(\mathcal{E}^\mathcal{K}_{i-1}), \quad 0 < i < n" />
            </p>
            <p>
              <InlineMath math="\mathcal{E}^\mathcal{K}_\infty \equiv_{\mathrm{def}} \mathcal{E}^\mathcal{K}_n" />{" "}
              where <InlineMath math="n" /> is the smallest index such that{" "}
              <InlineMath math="\mathcal{E}^\mathcal{K}_n = \mathcal{E}^\mathcal{K}_{n+1}" />.
            </p>
          </div>

          <p className="mt-4">
            The <strong>base rank</strong>{" "}
            <InlineMath math="br_\mathcal{K}(\alpha)" /> of a propositional statement{" "}
            <InlineMath math="\alpha" /> with respect to{" "}
            <InlineMath math="\mathcal{K}" /> is defined to be the smallest{" "}
            <InlineMath math="r" /> such that <InlineMath math="\alpha" /> is{" "}
            <em>not exceptional</em> with respect to{" "}
            <InlineMath math="\mathcal{E}^\mathcal{K}_r" />:
          </p>

          <div className="ml-6 mt-2">
            <InlineMath math="br_\mathcal{K}(\alpha) \equiv_{\mathrm{def}} \min \{ r \mid \mathcal{E}^\mathcal{K}_r \not\vDash_R \top \mid\!\sim \lnot \alpha \}" />
          </div>

          {/* Instantiation with actual query */}
          {query && (
            <div className="p-2 border rounded bg-gray-50">
              <p className="font-medium mb-2">For your current query:</p>
              <p>
                <InlineMath math={`\\alpha = ${toTex(query)}`} />
              </p>
              <p>
                <InlineMath math="\mathcal{K} = \{" />
                {kb.map((f, i) => (
                  <React.Fragment key={i}>
                    <InlineMath math={toTex(f)} />
                    {i < kb.length - 1 && <>, </>}
                  </React.Fragment>
                ))}
                <InlineMath math="\}" />.
              </p>
              <p className="mt-2">
                So we are evaluating:{" "}
                <InlineMath
                  math={`br_\\mathcal{K}(${toTex(query)}) = \\min \\{ r \\mid \\mathcal{E}^\\mathcal{K}_r \\not\\vDash_R \\top \\mid\\!\\sim \\lnot (${toTex(
                    query
                  )}) \\}`}
                />
              </p>
            </div>
          )}

          <h3 className="text-lg font-semibold mt-6">Observation</h3>
          <p>
            <InlineMath math="\mathcal{K} \vDash_{RC} \alpha \mid\!\sim \beta \quad \text{iff} \quad br_\mathcal{K}(\alpha) < br_\mathcal{K}(\alpha \land \lnot \beta)" />{" "}
            or <InlineMath math="br_\mathcal{K}(\alpha) = \infty" />.
          </p>
          <RankingTable title="Base Ranking" ranking={materializedRank} />
        </>
      )}
    </>
  );
}
