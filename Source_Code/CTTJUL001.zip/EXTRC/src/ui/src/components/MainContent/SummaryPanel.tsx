// src/components/MainContent/SummaryPanel.tsx
/*
 * File: SummaryPanel.tsx
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: React component for displaying the summary panel.
 * Purpose: Educational use only.
 */

import React, { useMemo, useState } from "react";
import { InlineMath } from "react-katex";
import { toTex } from "@/lib/formula";
import type { RankingLevel } from "./MainContent";
import { RankingTable } from "../ui/rankingTable";

/**
 * Extracts unique propositional atoms from the KB.
 * Ignores operators and punctuation.
 */
function extractKBAtoms(kb: string[]): string[] {
  const ops = new Set(["~>", "=>", "<=>", "&&", "||", "!", "(", ")", "+"]);
  const seen = new Set<string>();
  const tokenRe = /[A-Za-z0-9_][A-Za-z0-9_]*/g;

  for (const line of kb) {
    const tokens = line.match(tokenRe) ?? [];
    for (const t of tokens) {
      if (!ops.has(t)) seen.add(t);
    }
  }
  return Array.from(seen).sort();
}

/**
 * basic English rendering of a formula.
 * Replaces logical operators with basic text.
 */
function toEnglish(formula: string): string {
  return formula
    .replace(/~>/g, " typically implies ")
    .replace(/=>/g, " implies ")
    .replace(/<=>/g, " is equivalent to ")
    .replace(/&&/g, " and ")
    .replace(/\|\|/g, " or ")
    .replace(/!/g, "not ");
}

// Type for summarised rational closure results
type Result = {
  entailed?: boolean;
  negation?: string;
  timeTaken?: number;
};

export function SummaryPanel({
  query,
  rational,
  kb,
  baseRanking,
}: {
  query: string;
  rational?: Result;
  kb: string[];
  baseRanking: RankingLevel[];
}) {
  // Stats: detected atoms from KB
  const stats = useMemo(() => ({ atoms: extractKBAtoms(kb) }), [kb]);

  // Pagination for KB table (show first 10, then expand)
  const [visibleCount, setVisibleCount] = useState(10);
  const visibleKb = useMemo(() => kb.slice(0, visibleCount), [kb, visibleCount]);
  const hasMore = kb.length > visibleCount;

  // Toggle for inline help block
  const [showHelp, setShowHelp] = useState(false);

  // English translation of the query
  const qEnglish = toEnglish(query);

  /**
   * Inner component to show entailment results.
   * Displays query, verdict, negation, runtime, and reasoning explanation.
   */
  const Explain = ({
    title,
    result,
  }: {
    title: string;
    result?: Result;
  }) => {
    if (!result || result.entailed === undefined) return null;

    const yes = result.entailed;
    const verdict = yes ? (
      <span className="text-green-700 font-semibold">Yes ✅</span>
    ) : (
      <span className="text-red-700 font-semibold">No ❌</span>
    );

    const reason = yes
      ? "In the lowest rank where the premise is consistent, the strict part entails the conclusion."
      : "At the relevant rank, the conclusion could not be derived without contradiction.";

    return (
      <div className="rounded border p-4">
        <div className="font-semibold mb-1">{title}</div>

        <div className="text-sm space-y-2">
          <p className="text-muted-foreground">
            Rational Closure checks the query in the lowest rank where its premise is consistent.
          </p>

          <div>
            <span className="font-medium">Query:</span>{" "}
            <InlineMath math={toTex(query)} />{" "}
            <span className="text-muted-foreground">— {qEnglish}</span>
          </div>

          <div>
            <span className="font-medium">Entailed:</span> {verdict}
          </div>

          {result.negation && (
            <div>
              <span className="font-medium">Negation considered:</span>{" "}
              <InlineMath math={toTex(result.negation)} />{" "}
              <span className="text-muted-foreground">
                — {toEnglish(result.negation)}
              </span>
            </div>
          )}

          {typeof result.timeTaken === "number" && (
            <div>
              <span className="font-medium">Time taken:</span>{" "}
              {result.timeTaken.toFixed(3)}s
            </div>
          )}

          <div className="text-muted-foreground">{reason}</div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {/* Intro / Help section */}
      <div className="rounded border p-3 bg-gray-50 text-sm leading-relaxed">
        <p className="font-medium">What you’re looking at</p>
        <p>
          This panel summarises your knowledge base (𝒦), lists the symbols it
          uses, and shows whether your query is entailed under{" "}
          <em>Rational Closure</em>.
        </p>
        <p className="text-muted-foreground">
          Tip: the left column shows the symbolic formula; the right column
          explains it in plain English.
        </p>

        {/* Toggleable help block */}
        <div className="mt-2">
          <button
            type="button"
            className="text-xs underline underline-offset-2"
            onClick={() => setShowHelp((s) => !s)}
            aria-expanded={showHelp}
            aria-controls="summary-help"
          >
            {showHelp ? "Hide help" : "How to read this"}
          </button>
        </div>

        {showHelp && (
          <div
            id="summary-help"
            className="rounded border p-3 bg-white text-sm mt-2 space-y-1"
          >
            <p>
              <strong>1)</strong> Check the KB table for the facts and defaults
              you entered.
            </p>
            <p>
              <strong>2)</strong> Use “KB Symbols” to catch naming mistakes
              (e.g., <code>penguin</code> vs <code>penguins</code>).
            </p>
            <p>
              <strong>3)</strong> “Base Ranking” shows typical rules (lower
              ranks) and exceptions (higher ranks).
            </p>
            <p>
              <strong>4)</strong> “Rational Closure” gives the final entailment
              verdict for your query.
            </p>
          </div>
        )}
      </div>

      {/* KB heading */}
      <p className="font-medium">
        Knowledge Base (𝒦) ={" "}
        <span className="font-normal">(Consists of {kb.length} formulas)</span>
      </p>

      {/* KB Table (symbolic + English explanation) */}
      <table className="table-auto text-sm w-full border-collapse">
        <thead>
          <tr className="bg-gray-100">
            <th className="border px-4 py-2 text-left">Symbolic Form</th>
            <th className="border px-3 py-2 text-left">Explanation</th>
          </tr>
        </thead>
        <tbody>
          {visibleKb.map((formula, i) => (
            <tr key={i}>
              <td className="border px-3 py-2">
                • <InlineMath math={toTex(formula)} />
              </td>
              <td className="border px-3 py-2">• {toEnglish(formula)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Operator legend */}
      <p className="text-xs text-muted-foreground mt-1">
        <span className="font-medium">Legend:</span>{" "}
        <code>~&gt;</code> typically implies, <code>=&gt;</code> implies,{" "}
        <code>&amp;&amp;</code> and, <code>||</code> or, <code>!</code> not.
      </p>

      {/* Pagination controls */}
      {kb.length > 10 && (
        <div className="mt-2 flex items-center justify-center gap-3">
          {hasMore ? (
            <>
              <button
                type="button"
                onClick={() => setVisibleCount((n) => Math.min(n + 10, kb.length))}
                className="px-3 py-1 rounded border hover:bg-gray-50"
                aria-label={`Show 10 more (showing ${visibleCount} of ${kb.length})`}
              >
                Show 10 more
              </button>
              <button
                type="button"
                onClick={() => setVisibleCount(kb.length)}
                className="px-3 py-1 rounded border hover:bg-gray-50"
                aria-label="Show all formulas"
              >
                Show all
              </button>
            </>
          ) : (
            <button
              type="button"
              onClick={() => setVisibleCount(10)}
              className="px-3 py-1 rounded border hover:bg-gray-50"
              aria-label="Show only first 10 formulas"
            >
              Show less
            </button>
          )}
        </div>
      )}

      {/* Extra notes under KB */}
      {kb.length === 0 && (
        <p className="text-sm text-muted-foreground">
          Add formulas to the knowledge base to see results here.
        </p>
      )}
      {kb.length > 10 && (
        <p className="text-xs text-muted-foreground text-center">
          Showing {Math.min(visibleCount, kb.length)} of {kb.length}. Use “Show
          10 more” or “Show all”.
        </p>
      )}

      {/* Atom summary */}
      <div className="rounded border p-3 text-sm space-y-2">
        <div className="font-medium">KB Symbols Detected</div>
        <p className="text-muted-foreground">
          These are the propositional atoms found in 𝒦. They’re useful for
          spotting typos (e.g., <code>penguin</code> vs <code>penguins</code>).
        </p>
        {stats.atoms.length > 0 ? (
          <p className="flex flex-wrap gap-x-3 gap-y-1">
            {stats.atoms.map((a) => (
              <span key={a} className="inline-flex items-center">
                <InlineMath math={toTex(a)} />{" "}
              </span>
            ))}
          </p>
        ) : (
          <p className="text-muted-foreground">No symbols detected.</p>
        )}
      </div>

      {/* Base ranking view */}
      <RankingTable title="Base Ranking" ranking={baseRanking} />
      <p className="text-xs text-muted-foreground -mt-2">
        Lower ranks contain more typical (less exceptional) information; higher
        ranks collect exceptions.
      </p>

      {/* Rational closure verdict */}
      <Explain title="Rational Closure" result={rational} />
    </div>
  );
}
