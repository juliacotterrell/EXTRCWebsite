// src/components/MainContent/QueryCard.tsx
/*
 * File: QueryCard.tsx
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: React component for allowing the user to add in a query.
 * Purpose: Educational use only.
 */

import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { InlineMath } from "react-katex";
import { toTex } from "@/lib/formula";

export function QueryCard({
  query,
  onEdit,
  onQuery,
  loading
}: {
  query: string;
  onEdit: () => void;   // trigger editing of the query string
  onQuery: () => void;  // run the backend entailment check
  loading: boolean;     // true while query is running
}) {
  return (
    <Card>
      <CardContent className="text-center p-6 space-y-4">
        <h2 className="text-lg font-semibold">
          Query Formula (<InlineMath math=" \alpha" />)
        </h2>

        {/* Show query rendered with KaTeX */}
        <p className="text-xl">
          <InlineMath math={toTex(query)} />
        </p>

        {/* Actions: edit or run query */}
        <div className="flex justify-center gap-4">
          <Button variant="outline" onClick={onEdit}>Edit</Button>
          <Button variant="outline" onClick={onQuery} disabled={loading}>
            {loading ? "Querying..." : "Query"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
