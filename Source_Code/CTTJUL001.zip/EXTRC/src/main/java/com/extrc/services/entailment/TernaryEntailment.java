/*
 * File: TernaryEntailment.java
 * Package: com.extrc.services.entailment
 *
 * Original Author: Nevaniah (2025 Honours Project, University of Cape Town)
 * Status: Unmodified – reused in full for EXTRC.
 * Context: Incorporated into Julia Cotterrell's Honours Project (2025) as part of the EXTRC system.
 * Purpose: Educational use only.
 */

/* Originally modified by Maqhobosheane Mohlerepe, changed by Nevaniah Gounden for current approach */

package com.extrc.services.entailment;

import java.util.Arrays;

import org.tweetyproject.logics.pl.reasoner.SatReasoner;
import org.tweetyproject.logics.pl.sat.Sat4jSolver;
import org.tweetyproject.logics.pl.sat.SatSolver;
import org.tweetyproject.logics.pl.syntax.PlBeliefSet;
import org.tweetyproject.logics.pl.syntax.PlFormula;

import com.extrc.utils.FormulaUtils;

public class TernaryEntailment implements EntailmentStrategy{

    private static final ThreadLocal<Integer> rankRemove = ThreadLocal.withInitial(() -> -1); // for safe parallisation

    // Constructor to accept rankedKB and formula
    public TernaryEntailment() {
        // Initialize the SAT solver and reasoner
        SatSolver.setDefaultSolver(new Sat4jSolver());
    }

    /** 
     * @param rankedKB
     * @param formula
     * @param infiniteRankEmpty
     * @return boolean
     */
    @Override
    public boolean rationalQuery(PlBeliefSet[] rankedKB, PlFormula formula, boolean infiniteRankEmpty) {
        int rlength = rankedKB.length;
        PlFormula negation = FormulaUtils.negateAntecedent(formula);
        rankRemove.set(-1);

        return checkEntailmentRecursive(rankedKB, formula, 0, rlength, negation);
    }

    /** 
     * @param rankedKB
     * @param formula
     * @param left
     * @param right
     * @param negation
     * @return boolean
     */
    private boolean checkEntailmentRecursive(PlBeliefSet[] rankedKB, PlFormula formula, int left, int right,
            PlFormula negation) {
        SatReasoner reasoner = new SatReasoner();

        if (right > left) {
            int mid = left + (right - left) / 3;
            int mid2 = right - (right - left) / 3;

            if (mid + 1 < rankedKB.length
                    && reasoner.query(combine(Arrays.copyOfRange(rankedKB, mid + 1, rankedKB.length)), negation)) {
                if (mid2 + 1 < rankedKB.length
                        && reasoner.query(combine(Arrays.copyOfRange(rankedKB, mid2 + 1, rankedKB.length)), negation)) {
                    return checkEntailmentRecursive(rankedKB, formula, mid2 + 1, right, negation);
                } else if (mid2 < rankedKB.length) {
                    if (reasoner.query(combine(Arrays.copyOfRange(rankedKB, mid2, rankedKB.length)), negation)) {
                        rankRemove.set(mid2);
                    } else {
                        return checkEntailmentRecursive(rankedKB, formula, mid + 1, mid2 - 1, negation);
                    }
                } else {
                    return checkEntailmentRecursive(rankedKB, formula, mid + 1, mid2 - 1, negation);
                }
            } else {
                if (mid < rankedKB.length
                        && reasoner.query(combine(Arrays.copyOfRange(rankedKB, mid, rankedKB.length)), negation)) {
                    rankRemove.set(mid);
                } else {
                    return checkEntailmentRecursive(rankedKB, formula, left, mid, negation);
                }
            }
        } else {
            if (right == left) {
                rankRemove.set(right);
            }

            if (rankRemove.get() >= 0 && rankRemove.get() < rankedKB.length) {
                if (!reasoner.query(combine(Arrays.copyOfRange(rankedKB, rankRemove.get(), rankedKB.length)),
                        negation)) {
                    rankRemove.set(rankRemove.get() - 1);

                }
            } else {
                return false;
            }
        }

        if (rankRemove.get() + 1 >= 0 && rankRemove.get() + 1 < rankedKB.length) {
            return reasoner.query(combine(Arrays.copyOfRange(rankedKB, rankRemove.get() + 1, rankedKB.length)),
                    formula);
        } else {
            return true;
        }
    }

    /** 
     * @param ranks
     * @return PlBeliefSet
     */
    private PlBeliefSet combine(PlBeliefSet[] ranks) {
        PlBeliefSet combined = new PlBeliefSet();
        for (PlBeliefSet rank : ranks) {
            combined.addAll(rank);
        }
        return combined;
    }
}
