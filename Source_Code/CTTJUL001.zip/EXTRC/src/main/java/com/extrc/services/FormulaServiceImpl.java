/*
 * File: FormulaServiceImplied.java
 * Package: com.extrc.services
 *
 * Original Author: Thabo Vincent Moloi , Honours Project (2024), University of Cape Town
 * Adapted by: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 *
 * Status: Modified – Springboot use.
 * Context: Used in EXTRC project for rational closure reasoning.
 * Purpose: Educational use only.
 */
package com.extrc.services;

import org.tweetyproject.logics.pl.syntax.PlFormula;
import org.tweetyproject.logics.pl.syntax.Proposition;
import com.extrc.models.DefeasibleImplication;
import com.extrc.nl.PhraseMappingService;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class FormulaServiceImpl implements FormulaService {

  private PlFormula getDefault() {
    Proposition p = new Proposition("p");
    Proposition w = new Proposition("w");
    return new DefeasibleImplication(p, w);
  }
    @Override
  public PlFormula getQueryFormula() {
    return getDefault();
  }


  private final PhraseMappingService phraseMapping;

  public FormulaServiceImpl(PhraseMappingService phraseMapping) {
    this.phraseMapping = phraseMapping;
  }

  public Map<String, String> renderFormula(PlFormula f, int rank) {
    String raw = f.toString();
    String nl  = phraseMapping.decodeProposition(extractAtoms(raw), rank);
    return Map.of("raw", raw, "explanation", nl);
  }

  private String extractAtoms(String raw) {
    return raw.replaceAll("[^A-Za-z]", "");
  }
}


