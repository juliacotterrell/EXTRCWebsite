/*
 * File: BaseRankDTO.java
 * Package: com.extrc.dtos
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Developed for EXTRC project to support rational closure reasoning
 * and encrypted communication.
 * Purpose: Educational use only.
 */

package com.extrc.dtos;

import java.util.List;

// Data Transfer Object (DTO) for passing base rank data between backend and frontend
public class BaseRankDTO {

    // Formulas in the knowledge base
    public List<String> knowledgeBase;

    // The sequence of ranks during construction
    public List<RankDTO> sequence;

    // The final ranking of formulas
    public List<RankDTO> ranking;

    // Execution time taken to compute the ranking
    public double timeTaken;

    // Default constructor
    public BaseRankDTO() {
    }

    // Constructor with all fields
    public BaseRankDTO(List<String> knowledgeBase, List<RankDTO> sequence, List<RankDTO> ranking, double timeTaken) {
        this.knowledgeBase = knowledgeBase;
        this.sequence = sequence;
        this.ranking = ranking;
        this.timeTaken = timeTaken;
    }
    // --- Getters and setters ---
    /** 
     * @param knowledgeBase
     */

    public void setKnowledgeBase(List<String> knowledgeBase) {
        this.knowledgeBase = knowledgeBase;
    }

    /** 
     * @return List<String>
     */
    public List<String> getKnowledgeBase() {
        return knowledgeBase;
    }

    /** 
     * @return List<RankDTO>
     */
    public List<RankDTO> getRanking() {
        return ranking;
    }

    /** 
     * @param ranking
     */
    public void setRanking(List<RankDTO> ranking) {
        this.ranking = ranking;
    }

    /** 
     * @return List<RankDTO>
     */
    public List<RankDTO> getSequence() {
        return sequence;
    }

    /** 
     * @param sequence
     */
    public void setSequence(List<RankDTO> sequence) {
        this.sequence = sequence;
    }

    /** 
     * @return double
     */
    public double getTimeTaken() {
        return timeTaken;
    }

    /** 
     * @param timeTaken
     */
    public void setTimeTaken(double timeTaken) {
        this.timeTaken = timeTaken;
    }
}
