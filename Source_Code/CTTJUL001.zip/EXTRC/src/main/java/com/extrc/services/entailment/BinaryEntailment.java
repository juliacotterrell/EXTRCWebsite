/*
 * File: BinaryEntailment.java
 * Package: com.extrc.services.entailment
 *
 * Original Author: Nevaniah (2025 Honours Project, University of Cape Town)
 * Status: Unmodified – reused in full for EXTRC.
 * Context: Incorporated into Julia Cotterrell's Honours Project (2025) as part of the EXTRC system.
 * Purpose: Educational use only.
 */

package com.extrc.services.entailment;

import java.util.Arrays;
import org.tweetyproject.logics.pl.syntax.PlBeliefSet;
import org.tweetyproject.logics.pl.syntax.PlFormula;
import com.extrc.utils.FormulaUtils;


public class BinaryEntailment implements EntailmentStrategy {

    /** 
     * @param rankedKB
     * @param formula
     * @param infiniteRankEmpty
     * @return boolean
     */
    @Override
    public boolean rationalQuery(PlBeliefSet[] rankedKB, PlFormula formula, boolean infiniteRankEmpty) {
        int low = 0;
        int high = rankedKB.length - (infiniteRankEmpty ? 1 : 0);

        while (high > low) {
            int mid = (low + high) / 2;
            PlBeliefSet combined = combine(Arrays.copyOfRange(rankedKB, mid, rankedKB.length));
            PlFormula negatedAntecedent = FormulaUtils.negateAntecedent(formula);
            if (query(combined, negatedAntecedent )) {
                low = mid + 1;
            } else {
                high = mid;
            }
        }

        PlBeliefSet finalCombined = combine(Arrays.copyOfRange(rankedKB, low, rankedKB.length));
        return query(finalCombined, formula);
    }

    /** 
     * @param ranks
     * @return PlBeliefSet
     */
    private PlBeliefSet combine(PlBeliefSet[] ranks) {
        PlBeliefSet combined = new PlBeliefSet();
        for (PlBeliefSet r : ranks) combined.addAll(r);
        return combined;
    }
}
