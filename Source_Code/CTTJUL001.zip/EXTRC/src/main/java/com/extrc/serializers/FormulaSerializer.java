/*
 * File: FormulaSerializer.java
 * Package: com.extrc.serializers
 *
 * Original Author: Thabo Vincent Moloi , Honours Project (2024), University of Cape Town
 * Adapted by: Julia Cotterrell (2025 Honours Project, University of Cape Town) University of Cape Town)
 *
 * Status: Modified – Spring Boot use.
 * Context: Used in EXTRC project for rational closure reasoning.
 * Purpose: Educational use only.
 */

package com.extrc.serializers;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import java.io.IOException;
import org.tweetyproject.logics.pl.syntax.PlFormula;

/**
 * Custom Jackson serializer for propositional formulas.
 * Converts a {@link PlFormula} object into its string representation
 * for use in JSON responses.
 */
public class FormulaSerializer extends JsonSerializer<PlFormula> {

  /**
   * Serialize a {@link PlFormula} into JSON as a plain string.
   *
   * @param formula       the formula to serialize
   * @param gen           the JSON generator
   * @param serializers   the serializer provider
   * @throws IOException if writing fails
   */
  @Override
  public void serialize(PlFormula formula, JsonGenerator gen, SerializerProvider serializers) throws IOException {
    gen.writeString(formula.toString());
  }
}
