/* 
 * File: FormulaUtils.java
 * Package: com.extrc.utils
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Developed for EXTRC project to deal with formula utils.
 * Purpose: Educational use only.
 */
package com.extrc.utils;

import org.tweetyproject.logics.pl.syntax.Implication;
import org.tweetyproject.logics.pl.syntax.Negation;
import org.tweetyproject.logics.pl.syntax.PlFormula;

public final class FormulaUtils {
    private FormulaUtils() {}

    /** 
     * @param formula
     * @return PlFormula
     */
    public static PlFormula negateAntecedent(PlFormula formula) {
        if (formula instanceof Implication imp) {
            return new Negation(imp.getFirstFormula());
        }
        return new Negation(formula);
    }
}
