/*
 * File: FormulaDeserializer.java
 * Package: com.extrc.serializers
 *
 * Original Author: Thabo Vincent Moloi , Honours Project (2024), University of Cape Town
 * Adapted by: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 *
 * Status: Modified – Spring Boot use.
 * Context: Used in EXTRC project for rational closure reasoning.
 * Purpose: Educational use only.
 */

package com.extrc.serializers;

import java.io.IOException;

import org.tweetyproject.logics.pl.syntax.PlFormula;

import com.extrc.utils.DefeasibleParser;
import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

/**
 * Custom Jackson deserializer for parsing propositional formulas.
 * Converts JSON string values into {@link PlFormula} objects
 * using the {@link DefeasibleParser}.
 */
public class FormulaDeserializer extends JsonDeserializer<PlFormula> {

  /**
   * Deserialize a JSON string into a {@link PlFormula}.
   *
   * @param p     the JSON parser
   * @param ctxt  deserialization context
   * @return parsed PlFormula
   * @throws IOException if parsing fails or formula is invalid
   */
  @Override
  public PlFormula deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JacksonException {
    String formulaString = p.getValueAsString();
    try {
      DefeasibleParser parser = new DefeasibleParser();
      return parser.parseFormula(formulaString);
    } catch (Exception e) {
      throw new IOException("The formula \"" + formulaString + "\" is invalid.");
    }
  }
}
