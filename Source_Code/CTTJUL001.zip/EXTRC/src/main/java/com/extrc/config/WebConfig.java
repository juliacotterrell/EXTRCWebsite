// src/main/java/com/extrc/config/WebConfig.java
/*
 * File: WebConfig.java
 * Package: com.extrc.config
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Developed for EXTRC project to support rational closure reasoning
 * and encrypted communication.
 * Purpose: Educational use only.
 */

package com.extrc.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.*;

@Configuration // Marks this as a Spring configuration class
public class WebConfig implements WebMvcConfigurer {

  @Override
  public void addCorsMappings(CorsRegistry registry) {
    // Allow cross-origin requests for API endpoints
    registry.addMapping("/api/**")
            // Permitted origins: deployed frontend + local dev
            .allowedOrigins("https://extrc.vercel.app",
                            "http://localhost:5173")
            // Allow standard HTTP methods
            .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
            // Allow any headers
            .allowedHeaders("*");
  }
}
