/*
 * File: RankDTO.java
 * Package: com.extrc.dtos
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Developed for EXTRC project to support rational closure reasoning
 * and encrypted communication.
 * Purpose: Educational use only.
 */

package com.extrc.dtos;

import java.util.List;

// Data Transfer Object (DTO) representing a single rank in the ranking sequence
public class RankDTO {

    // The number of this rank
    public int rankNumber;

    // The knowledge base formulas that belong to this rank
    public List<String> knowledgeBase;

    // Default constructor
    public RankDTO() {
    }

    // Constructor with fields
    public RankDTO(int rankNumber, List<String> knowledgeBase) {
        this.rankNumber = rankNumber;
        this.knowledgeBase = knowledgeBase;
    }
}
