/*
 * File: BaseRankServiceImplied.java
 * Package: com.extrc.services
 *
 * Original Author: Thabo Vincent Moloi , Honours Project (2024), University of Cape Town
 * Adapted by: Julia Cotterrell (2025 Honours Project, University of Cape Town) University of Cape Town) University of Cape Town)
 *
 * Status: Modified – Springboot use.
 * Context: Used in EXTRC project for rational closure reasoning.
 * Purpose: Educational use only.
 */package com.extrc.services;

import org.tweetyproject.logics.pl.reasoner.SatReasoner;
import org.tweetyproject.logics.pl.sat.Sat4jSolver;
import org.tweetyproject.logics.pl.sat.SatSolver;
import org.tweetyproject.logics.pl.syntax.Implication;
import org.tweetyproject.logics.pl.syntax.Negation;
import org.springframework.stereotype.Service;

import com.extrc.models.BaseRank;
import com.extrc.models.KnowledgeBase;
import com.extrc.models.Rank;
import com.extrc.models.Ranking;

@Service
public class BaseRankServiceImpl implements BaseRankService {

  public BaseRankServiceImpl() {
    // no shared solver/reasoner here anymore
  }

  @Override
  public BaseRank constructBaseRank(KnowledgeBase knowledgeBase) {
    long startTime = System.nanoTime();

    // Fresh solver & reasoner PER CALL (thread-safe)
    SatSolver.setDefaultSolver(new Sat4jSolver());
    SatReasoner reasoner = new SatReasoner();

    // Separate defeasible and classical statements
    KnowledgeBase[] kb = knowledgeBase.separate();
    KnowledgeBase defeasible = kb[0];
    KnowledgeBase classical  = kb[1];

    // ranking and exceptionality sequence
    Ranking ranking = new Ranking();
    Ranking sequence = new Ranking();

    KnowledgeBase current  = defeasible;
    KnowledgeBase previous = new KnowledgeBase();

    int i = 0;
    while (!previous.equals(current)) {
      previous = current;             
      current  = new KnowledgeBase();     

      KnowledgeBase exceptionals = getExceptionals(previous, classical, reasoner);

      Rank rank = new Rank();
      constructRank(rank, previous, current, exceptionals);

      if (!rank.getFormulas().isEmpty()) {
        rank.setRankNumber(i);
        ranking.add(rank); 
      }

      sequence.addRank(previous.equals(current) ? Integer.MAX_VALUE : i, previous);
      i++;
    }

    // Everything not placed in a finite rank lives at infinite rank together with classical
    ranking.addRank(Integer.MAX_VALUE, classical.union(current));

    long endTime = System.nanoTime();
    return new BaseRank(
        knowledgeBase, 
        sequence,
        ranking,
        (endTime - startTime) / 1_000_000_000.0
    );
  }

  private KnowledgeBase getExceptionals(KnowledgeBase defeasible, KnowledgeBase classical, SatReasoner reasoner) {
    KnowledgeBase exceptionals = new KnowledgeBase();
    KnowledgeBase union = defeasible.union(classical);

    // sequential (no shared state / no sync needed)
    for (var antecedent : defeasible.antecedents()) {
      if (reasoner.query(union, new Negation(antecedent))) {
        exceptionals.add(antecedent);
      }
    }
    return exceptionals;
  }

  private void constructRank(Rank rank, KnowledgeBase previous, KnowledgeBase current, KnowledgeBase exceptionals) {
    // sequential (no shared state / no sync needed)
    for (var formula : previous) {
      var ant = ((Implication) formula).getFormulas().getFirst();
      if (exceptionals.contains(ant)) {
        current.add(formula);
      } else {
        rank.getFormulas().add(formula);
      }
    }
  }
}
