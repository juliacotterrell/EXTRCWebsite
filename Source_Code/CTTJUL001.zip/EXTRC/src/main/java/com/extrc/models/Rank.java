/*
 * File: Rank.java
 * Package: com.extrc.models
 *
 * Original Author: Thabo Vincent Moloi , Honours Project (2024), University of Cape Town
 * Adapted by: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 *
 * Status: Modified – Spring Boot use.
 * Context: Used in EXTRC project for rational closure reasoning.
 * Purpose: Educational use only.
 */

package com.extrc.models;

import java.util.Collection;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.tweetyproject.logics.pl.syntax.PlFormula;

import com.extrc.dtos.RankDTO;

/**
 * Represents a single ranked layer within a ranked knowledge base.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Rank {

    // The position or level of this rank (e.g., 0, 1, 2...). 
    private int rankNumber;

    // The formulas associated with this rank. 
    private KnowledgeBase formulas;

    // --- Constructors ---

    // Default constructor: creates an empty rank with number 0
    public Rank() {
        this(0, new KnowledgeBase());
    }

    // Constructor with rank number and formulas
    public Rank(int rankNumber, Collection<? extends PlFormula> formulas) {
        this.rankNumber = rankNumber;
        this.formulas = new KnowledgeBase(formulas);
    }

    // Copy constructor
    public Rank(Rank other) {
        this.rankNumber = other.rankNumber;
        this.formulas = new KnowledgeBase(other.formulas);
    }
    // --- Getters, setters, and DTO conversion ---

    /** 
     * @return int
     */
    public int getRankNumber() {
        return rankNumber;
    }

    /** 
     *  Convert this Rank into a RankDTO (for frontend transport)
     * @return RankDTO
     */
    public RankDTO toDTO() {
        return new RankDTO(
            this.rankNumber,
            this.formulas.stream()
                .map(Object::toString)
                .collect(Collectors.toList())
        );
    }

    /** 
     * @param rankNumber
     */
    public void setRankNumber(int rankNumber) {
        this.rankNumber = rankNumber;
    }

    /** 
     * @return KnowledgeBase
     */
    public KnowledgeBase getFormulas() {
        return formulas;
    }

    /** 
     * @param formulas
     */
    public void setFormulas(KnowledgeBase formulas) {
        this.formulas = formulas;
    }
}
