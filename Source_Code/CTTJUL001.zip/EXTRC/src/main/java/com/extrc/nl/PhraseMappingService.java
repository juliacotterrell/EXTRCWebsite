/*
 * File: PhraseMappingService.java
 * Package: com.extrc.nl
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Provides mapping between symbolic atoms and natural language phrases
 *          for use in EXTRC project explanations.
 * Purpose: Educational use only.
 */

package com.extrc.nl;

import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Service // Marks this as a Spring-managed service
public class PhraseMappingService {

  private final ResourceLoader resourceLoader;

  // Map of atom -> phrase (e.g. "p" → "Penguin")
  private final Map<String,String> atomMap = new HashMap<>();

  // List of example natural language sentences
  private final List<String> phrases = new ArrayList<>();

  // Constructor injection of resource loader
  public PhraseMappingService(ResourceLoader resourceLoader) {
    this.resourceLoader = resourceLoader;
  }

  // Load resources when the service is initialized
  @PostConstruct
  void init() throws Exception {
    loadMap("classpath:nl/AtomMap.txt", atomMap);
    loadList("classpath:nl/sentences.txt", phrases);
  }

  // Helper to load key-value mappings from a file
  private void loadMap(String location, Map<String,String> out) throws Exception {
    Resource r = resourceLoader.getResource(location);
    try (BufferedReader br = new BufferedReader(
          new InputStreamReader(r.getInputStream(), StandardCharsets.UTF_8))) {
      String line;
      while ((line = br.readLine()) != null) {
        line = line.trim();
        if (line.isEmpty() || line.startsWith("#")) continue;
        String[] parts = line.split("\\s+", 2);
        if (parts.length == 2) out.put(parts[0], parts[1]);
      }
    }
  }

  // Helper to load a plain list of phrases from a file
  private void loadList(String location, List<String> out) throws Exception {
    Resource r = resourceLoader.getResource(location);
    try (BufferedReader br = new BufferedReader(
          new InputStreamReader(r.getInputStream(), StandardCharsets.UTF_8))) {
      String line;
      while ((line = br.readLine()) != null) {
        line = line.trim();
        if (!line.isEmpty()) out.add(line);
      }
    }
  }

  /**
   * Decode a proposition into natural language using the loaded atom map.
   * Example: "ab" → "A AND B" (if 'a' maps to "A" and 'b' maps to "B").
   *
   * @param prop the symbolic proposition (e.g. "ab")
   * @param rank the rank number (not currently used, but available for context)
   * @return natural language representation of the proposition
   */
  public String decodeProposition(String prop, int rank) {
    StringBuilder sb = new StringBuilder();
    for (char c: prop.toCharArray()) {
      String k = String.valueOf(c);
      sb.append(atomMap.getOrDefault(k, k)).append(" ");
    }
    return sb.toString().trim();
  }
}
