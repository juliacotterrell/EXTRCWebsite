/*
 * File: DemoApplication.java
 * Package: com.extrc
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Developed for EXTRC project to support rational closure reasoning
 * and encrypted communication.
 * Purpose: Educational use only.
 */
package com.extrc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import com.extrc.config.ObjectMapperConfig;


@SpringBootApplication
@Import(ObjectMapperConfig.class)
public class DemoApplication {
  public static void main(String[] args) {
    SpringApplication.run(DemoApplication.class, args);
  }
}