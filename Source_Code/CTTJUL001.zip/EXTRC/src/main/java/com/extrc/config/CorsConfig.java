// src/main/java/com/extrc/config/CorsConfig.java
/*
 * File: CorsConfig.java
 * Package: com.extrc.config
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Developed for EXTRC project to support rational closure reasoning
 * and encrypted communication.
 * Purpose: Educational use only.
 */

package com.extrc.config;

import java.util.List;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

@Configuration  // Marks this as a Spring configuration class
public class CorsConfig {

  @Bean // Registers this method as a Spring bean
  public CorsFilter corsFilter() {
    CorsConfiguration cfg = new CorsConfiguration();

    // Do not allow credentials (cookies, auth headers)
    cfg.setAllowCredentials(false);

    // Allowed origins (frontend on Vercel + localhost for testing)
    cfg.setAllowedOriginPatterns(List.of(
        "https://extrc.vercel.app",
        "https://*.vercel.app",
        "http://localhost:*",
        "http://127.0.0.1:*"
    ));

    // Allowed HTTP methods
    cfg.setAllowedMethods(List.of("GET","POST","PUT","DELETE","OPTIONS"));

    // Allow all headers
    cfg.setAllowedHeaders(List.of("*"));

    // Apply this configuration to all endpoints
    UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
    source.registerCorsConfiguration("/**", cfg);

    // Return the CORS filter bean
    return new CorsFilter(source);
  }
}
