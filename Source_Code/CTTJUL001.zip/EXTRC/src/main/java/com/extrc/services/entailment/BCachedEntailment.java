/*
 * File: BCachedEntailment.java
 * Package: com.extrc.services.entailment
 *
 * Original Author: Nevaniah (2025 Honours Project, University of Cape Town)
 * Status: Unmodified – reused in full for EXTRC.
 * Context: Incorporated into Julia Cotterrell's Honours Project (2025) as part of the EXTRC system.
 * Purpose: Educational use only.
 */

/* Originally modified by Maqhobosheane Mohlerepe, changed by Nevaniah Gounden for current approach */

package com.extrc.services.entailment;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.tweetyproject.logics.pl.reasoner.SatReasoner;
import org.tweetyproject.logics.pl.syntax.PlBeliefSet;
import org.tweetyproject.logics.pl.syntax.PlFormula;
import com.extrc.utils.FormulaUtils;
import com.extrc.utils.CacheUtils;

public class BCachedEntailment  implements EntailmentStrategy {

    // Cache to store previously computed query results
    private final Map<String, Boolean> queryCache = new ConcurrentHashMap<>();

    // Cache to store the final filtered belief set for each negated antecedent
    private final Map<String, PlBeliefSet> filteredKBCache = new ConcurrentHashMap<>();

    // Cache hit counter
    private int cacheHitCounter = 0;

    /** 
     * Main method to check entailment using binary rational closure with caching
     * @param rankedKB
     * @param formula
     * @param infiniteRankEmpty
     * @return boolean
     */
   @Override
    public boolean rationalQuery(PlBeliefSet[] rankedKB, PlFormula formula, boolean infiniteRankEmpty) {

        // Generate a unique key for the query cache based on the formula and rankedKB
        String queryCacheKey = CacheUtils.cacheKey(rankedKB, formula);

        // Check if the result for the full query is already in the cache
        if (queryCache.containsKey(queryCacheKey)) {
            cacheHitCounter++; // Increment the cache hit counter
            return queryCache.get(queryCacheKey);
        }

        // Generate a unique key for the filtered KB cache based on the negated
        // antecedent + KB
        PlFormula negatedAntecedent = FormulaUtils.negateAntecedent(formula);

        String negatedAntecedentKey = CacheUtils.kbSignature(rankedKB) + "|" + negatedAntecedent.toString();

        // Check if the filtered knowledge base is already cached for this negated
        // antecedent
        PlBeliefSet cachedFilteredKB = filteredKBCache.get(negatedAntecedentKey);
        if (cachedFilteredKB != null) {
            cacheHitCounter++; // Increment the cache hit counter
            SatReasoner reasoner = new SatReasoner();
            boolean result = reasoner.query(cachedFilteredKB, formula);
            queryCache.put(queryCacheKey, result); // Cache the result
            return result;
        }

        // If not cached, proceed with the normal logic
        infiniteRankEmpty = rankedKB.length == 0 || rankedKB[rankedKB.length - 1].isEmpty();
        int high = infiniteRankEmpty ? rankedKB.length - 1 : rankedKB.length;
        int low = 0;
        int originalLow = low;
        int originalHigh = high;

        SatReasoner reasoner = new SatReasoner();

        while (high > low) {
            int mid = low + (high - low) / 2;

            PlBeliefSet combinedBeliefSetMidToEnd = combineRanks(rankedKB, mid + 1, high - 1);
            if (!infiniteRankEmpty) {
                combinedBeliefSetMidToEnd.addAll(rankedKB[rankedKB.length - 1]); // Always add infinite rank
            }

            if (reasoner.query(combinedBeliefSetMidToEnd, FormulaUtils.negateAntecedent(formula))) {
                low = mid + 1;
            } else {
                PlBeliefSet combinedBeliefSetMinToMid = combineRanks(rankedKB, low, mid);
                if (!infiniteRankEmpty) {
                    combinedBeliefSetMinToMid.addAll(rankedKB[rankedKB.length - 1]); // Always add infinite rank
                }

                if (reasoner.query(combinedBeliefSetMinToMid, FormulaUtils.negateAntecedent(formula))) {
                    high = mid;
                } else {
                    int highestRank = mid;

                    // If no ranks were removed, use the entire original belief set
                    if (low == originalLow && high == originalHigh) {
                        boolean result = reasoner.query(combineRanks(rankedKB, 0, rankedKB.length - 1), formula);
                        queryCache.put(queryCacheKey, result); // Cache the result
                        return result;
                    }

                    PlBeliefSet finalFilteredBeliefSet = combineRanks(rankedKB, highestRank + 1, rankedKB.length - 1);
                    if (!infiniteRankEmpty) {
                        finalFilteredBeliefSet.addAll(rankedKB[rankedKB.length - 1]); // Always add infinite rank
                    }

                    // Cache filtered KB for this (KB,negation)
                    filteredKBCache.put(negatedAntecedentKey, finalFilteredBeliefSet);

                    boolean result = reasoner.query(finalFilteredBeliefSet, formula);
                    queryCache.put(queryCacheKey, result); // Cache the result
                    return result;
                }
            }
        }

        // Final entailment check with the combined belief set from low to high-1
        PlBeliefSet finalCombinedBeliefSet = combineRanks(rankedKB, low, high - 1);
        if (!infiniteRankEmpty) {
            finalCombinedBeliefSet.addAll(rankedKB[rankedKB.length - 1]); // Always add infinite rank
        }

        boolean finalResult = reasoner.query(finalCombinedBeliefSet, formula);
        queryCache.put(queryCacheKey, finalResult);
        return finalResult;
    }

    /** 
     * Combine the belief sets from the specified range (start to end)
     * @param rankedKB
     * @param start
     * @param end
     * @return PlBeliefSet
     */
    private PlBeliefSet combineRanks(PlBeliefSet[] rankedKB, int start, int end) {
        PlBeliefSet combinedBeliefSet = new PlBeliefSet();
        for (int i = start; i <= end; i++) {
            if (i >= 0 && i < rankedKB.length && rankedKB[i] != null) {
                combinedBeliefSet.addAll(rankedKB[i]);
            }
        }
        return combinedBeliefSet;
    }

    // Method to clear cache and reset cache hit counter
    public void clearCache() {
        queryCache.clear();
        filteredKBCache.clear();
        cacheHitCounter = 0; // Reset the cache hit counter
    }

    /** 
     * Getter method for cache hit counter
     * @return int
     */
    public int getCacheHitCounter() {
        return cacheHitCounter;
    }
}
