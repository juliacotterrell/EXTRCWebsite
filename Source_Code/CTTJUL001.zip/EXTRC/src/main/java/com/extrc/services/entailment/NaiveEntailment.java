/*
 * File: NaiveEntailment.java
 * Package: com.extrc.services.entailment
 *
 * Original Author: Nevaniah (2025 Honours Project, University of Cape Town)
 * Status: Modified – to work with my set up
 * Adapted by: Julia Cotterrell (2025 Honours Project, UCT)
 * Context: Incorporated into Julia Cotterrell's Honours Project (2025) as part of the EXTRC system.
 * Purpose: Educational use only.
 */

package com.extrc.services.entailment;

import org.tweetyproject.logics.pl.reasoner.SatReasoner;
import org.tweetyproject.logics.pl.sat.Sat4jSolver;
import org.tweetyproject.logics.pl.syntax.PlBeliefSet;
import org.tweetyproject.logics.pl.syntax.PlFormula;

public class NaiveEntailment implements EntailmentStrategy {
  private final SatReasoner reasoner;

  public NaiveEntailment() {
    Sat4jSolver.setDefaultSolver(new Sat4jSolver());
    this.reasoner = new SatReasoner();
  }

  @Override public boolean query(PlBeliefSet kb, PlFormula phi) { return reasoner.query(kb, phi); }
  @Override public SatReasoner getReasoner() { return reasoner; }
}
