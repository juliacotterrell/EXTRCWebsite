/*
 * File: RankingDTO.java
 * Package: com.extrc.dtos
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Developed for EXTRC project to support rational closure reasoning
 * and encrypted communication.
 * Purpose: Educational use only.
 */

package com.extrc.dtos;

import java.util.List;

// Data Transfer Object (DTO) representing a collection of ranks
public class RankingDTO {

    // The list of individual ranks in the ranking
    public List<RankDTO> ranks;

    // Default constructor
    public RankingDTO() {}

    // Constructor with ranks
    public RankingDTO(List<RankDTO> ranks) {
        this.ranks = ranks;
    }
}
