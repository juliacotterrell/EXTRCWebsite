/*
 * File: HybridEntailment.java
 * Package: com.extrc.services.entailment
 *
 * Original Author: Nevaniah (2025 Honours Project, University of Cape Town)
 * Status: Unmodified - reused in full for EXTRC.
 * Context: Incorporated into Julia Cotterrell's Honours Project (2025) as part of the EXTRC system.
 * Purpose: Educational use only.
 */

package com.extrc.services.entailment;

import org.tweetyproject.logics.pl.syntax.PlBeliefSet;
import org.tweetyproject.logics.pl.syntax.PlFormula;

public class HybridEntailment implements EntailmentStrategy {

    private static final int NAIVE_THRESHOLD = 11;
    private static final int BINARY_THRESHOLD = 31;

    /** 
     * @param rankedKB
     * @param formula
     * @param infiniteRankEmpty
     * @return boolean
     */
    @Override
    public boolean rationalQuery(PlBeliefSet[] rankedKB, PlFormula formula, boolean infiniteRankEmpty) {
        NaiveEntailment naive = new NaiveEntailment();
        BinaryEntailment binary = new BinaryEntailment();
        TernaryEntailment ternary = new TernaryEntailment();

        String method;
        boolean result;

        if (rankedKB.length <= NAIVE_THRESHOLD) {
            method = "Naive";
            result = naive.rationalQuery(rankedKB, formula, infiniteRankEmpty);
        } else if (rankedKB.length <= BINARY_THRESHOLD) {
            method = "Binary";
            result = binary.rationalQuery(rankedKB, formula, infiniteRankEmpty);
        } else {
            method = "Ternary";
            result = ternary.rationalQuery(rankedKB, formula, infiniteRankEmpty);
        }

        System.out.println("[HybridEntailment] Used " + method + " for query: " + formula);
        return result;
    }
}
