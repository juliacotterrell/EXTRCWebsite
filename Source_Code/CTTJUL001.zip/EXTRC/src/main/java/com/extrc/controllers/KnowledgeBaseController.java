/*
 * File: KnowledgeBaseController.java
 * Package: com.extrc.controllers
 *
 * Original Author: Thabo Vincent Moloi , Honours Project (2024), University of Cape Town
 * Adapted by: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 *
 * Status: Modified – Spring Boot use.
 * Context: Used in EXTRC project for rational closure reasoning.
 * Purpose: Educational use only.
 */

package com.extrc.controllers;

import com.extrc.models.ErrorResponse;
import com.extrc.models.KnowledgeBase;
import com.extrc.dtos.KnowledgeBaseDTO;
import com.extrc.services.KnowledgeBaseService;
import com.extrc.utils.DefeasibleParser;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.stream.Collectors;
import org.tweetyproject.logics.pl.syntax.PlFormula;

@RestController // Marks this class as a REST controller
@RequestMapping("/api/knowledge-base") // Base URL for KB endpoints
public class KnowledgeBaseController {

    private final KnowledgeBaseService kbService;

    // Constructor injection of the service
    public KnowledgeBaseController(KnowledgeBaseService kbService) {
        this.kbService = kbService;
    }

    // Endpoint: GET /api/knowledge-base
    // Returns the current knowledge base as a DTO
    @GetMapping
    public KnowledgeBaseDTO getKnowledgeBase() {
        return new KnowledgeBaseDTO(
            kbService.getKnowledgeBase().toStringList()
        );
    }

    // Endpoint: POST /api/knowledge-base/create-knowledge-base
    // Creates a new KB from formulas provided in the request body
    @PostMapping("/create-knowledge-base")
    public ResponseEntity<Void> createKb(@RequestBody KnowledgeBaseDTO dto) {
        DefeasibleParser parser = new DefeasibleParser();

        // Parse each formula string into a PlFormula
        List<PlFormula> formulas = dto.getFormulas().stream()
            .map(f -> {
                try {
                    return (PlFormula) parser.parseFormula(f);
                } catch (Exception e) {
                    throw new RuntimeException("Invalid formula: " + f, e);
                }
            })
            .collect(Collectors.toList());

        // Build KB and save it in the service
        KnowledgeBase kb = new KnowledgeBase(formulas);
        kbService.setKnowledgeBase(kb);

        return ResponseEntity.ok().build();
    }

    // Endpoint: POST /api/knowledge-base/file
    // Creates a KB from an uploaded file
    @PostMapping("/file")
    public ResponseEntity<?> createKbFromFile(@RequestParam("file") MultipartFile file) {
        try {
            if (file != null && !file.isEmpty()) {
                DefeasibleParser parser = new DefeasibleParser();
                KnowledgeBase kb = parser.parseInputStream(file.getInputStream());
                return ResponseEntity.ok(kb);
            } else {
                // No file provided
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(new ErrorResponse(400, "Bad Request", "No file uploaded"));
            }
        } catch (Exception e) {
            // Parsing or file errors
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ErrorResponse(400, "Bad Request", "The knowledge base is invalid."));
        }
    }
}
