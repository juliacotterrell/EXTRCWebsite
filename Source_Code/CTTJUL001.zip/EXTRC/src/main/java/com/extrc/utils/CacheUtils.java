/*
 * File: CacheUtils.java
 * Package: com.extrc.utils
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Developed for EXTRC project to cache utils.
 * Purpose: Educational use only.
 */package com.extrc.utils;

import org.tweetyproject.logics.pl.syntax.PlBeliefSet;
import org.tweetyproject.logics.pl.syntax.PlFormula;

public final class CacheUtils {
    private CacheUtils() {
    }

    /** 
     * @param rankedKB
     * @param formula
     * @return String
     */
    public static String cacheKey(PlBeliefSet[] rankedKB, PlFormula formula) {
        int h = 1;
        for (PlBeliefSet r : rankedKB) {
            h = 31 * h + (r != null ? r.hashCode() : 0);
        }
        return h + "|" + formula.hashCode();
    }

    /** 
     * @param rankedKB
     * @return String
     */
    public static String kbSignature(PlBeliefSet[] rankedKB) {
        int h = 1;
        for (PlBeliefSet r : rankedKB) {
            h = 31 * h + (r != null ? r.hashCode() : 0);
        }
        return Integer.toHexString(h);
    }
}
