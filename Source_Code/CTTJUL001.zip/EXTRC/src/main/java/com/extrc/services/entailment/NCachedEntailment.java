/*
 * File: NCachedEntailment.java
 * Package: com.extrc.services.entailment
 *
 * Original Author: Nevaniah (2025 Honours Project, University of Cape Town)
 * Status: Unmodified – reused in full for EXTRC.
 * Context: Incorporated into Julia Cotterrell's Honours Project (2025) as part of the EXTRC system.
 * Purpose: Educational use only.
 */

/* Originally created by Maqhobosheane Mohlerepe, changed by Nevaniah Gounden for current approach */

package com.extrc.services.entailment;

import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.tweetyproject.logics.pl.reasoner.SatReasoner;
import org.tweetyproject.logics.pl.syntax.PlBeliefSet;
import org.tweetyproject.logics.pl.syntax.PlFormula;

import com.extrc.utils.CacheUtils;
import com.extrc.utils.FormulaUtils;


public class NCachedEntailment implements EntailmentStrategy {

    // Cache to store previously computed query results
    private final Map<String, Boolean> queryCache = new ConcurrentHashMap<>();

    // Cache to store the filtered knowledge base for each negated antecedent
    private final Map<String, PlBeliefSet[]> filteredKBCache = new ConcurrentHashMap<>();

    // Cache hit counter
    private int cacheHitCounter = 0;

    /** 
     * @param rankedKB
     * @param formula
     * @param infiniteRankEmpty
     * @return boolean
     */
    @Override
    public boolean rationalQuery(PlBeliefSet[] rankedKB, PlFormula formula, boolean infiniteRankEmpty) {
        // Generate a unique key for the query cache based on the formula and rankedKB
        String queryCacheKey = CacheUtils.cacheKey(rankedKB, formula);

        // Check if the result for the full query is already in the cache
        if (queryCache.containsKey(queryCacheKey)) {
            cacheHitCounter++; // Increment the cache hit counter
            return queryCache.get(queryCacheKey);
        }

        // Generate a unique key for the filtered KB cache based on the negated
        // antecedent + KB
        PlFormula negatedAntecedent = FormulaUtils.negateAntecedent(formula);
        String negatedAntecedentKey = CacheUtils.kbSignature(rankedKB) + "|" + negatedAntecedent.toString();

        PlBeliefSet[] filteredKB;
        if (filteredKBCache.containsKey(negatedAntecedentKey)) {
            cacheHitCounter++; // Increment the cache hit counter
            filteredKB = filteredKBCache.get(negatedAntecedentKey);
        } else {
            // Otherwise compute and cache
            filteredKB = filterKnowledgeBase(rankedKB, negatedAntecedent);
            filteredKBCache.put(negatedAntecedentKey, filteredKB);
        }

        boolean result = checkEntailmentForFilteredKB(filteredKB, formula);
        queryCache.put(queryCacheKey, result);
        return result;
    }

    /** 
     * Method to filter the knowledge base by removing inconsistent ranks based on
     * the negated antecedent
     * @param rankedKB
     * @param negatedAntecedent
     * @return PlBeliefSet[]
     */
    private PlBeliefSet[] filterKnowledgeBase(PlBeliefSet[] rankedKB, PlFormula negatedAntecedent) {
        SatReasoner reasoner = new SatReasoner();
        ArrayList<PlBeliefSet> filteredKBList = new ArrayList<>();

        for (int i = 0; i < rankedKB.length; i++) {
            PlBeliefSet combinedBeliefSet = combineRanks(rankedKB, i, rankedKB.length - 1);
            if (!reasoner.query(combinedBeliefSet, negatedAntecedent)) {
                filteredKBList.add(rankedKB[i]);
            }
        }
        return filteredKBList.toArray(new PlBeliefSet[0]);
    }

    /** 
     * Method to check entailment using a cached filtered knowledge base
     * @param filteredKB
     * @param formula
     * @return boolean
     */
    private boolean checkEntailmentForFilteredKB(PlBeliefSet[] filteredKB, PlFormula formula) {
        SatReasoner reasoner = new SatReasoner();
        PlBeliefSet combinedFilteredKB = combineRanks(filteredKB, 0, filteredKB.length - 1);
        return reasoner.query(combinedFilteredKB, formula);
    }

    /** 
     * Method to combine ranks within a specific range
     * @param rankedKB
     * @param start
     * @param end
     * @return PlBeliefSet
     */
    private PlBeliefSet combineRanks(PlBeliefSet[] rankedKB, int start, int end) {
        PlBeliefSet combinedBeliefSet = new PlBeliefSet();
        for (int i = start; i <= end; i++) {
            if (i >= 0 && i < rankedKB.length && rankedKB[i] != null) {
                combinedBeliefSet.addAll(rankedKB[i]);
            }
        }
        return combinedBeliefSet;
    }

    // Method to clear cache and reset cache hit counter
    public void clearCache() {
        queryCache.clear();
        filteredKBCache.clear();
        cacheHitCounter = 0; // Reset the cache hit counter
    }

    /** 
     * Getter method for cache hit counter
     * @return int
     */
    public int getCacheHitCounter() {
        return cacheHitCounter;
    }
}
