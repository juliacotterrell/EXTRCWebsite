/*
 * File: BaseRankController.java
 * Package: com.extrc.controllers
 *
 * Original Author: Thabo Vincent Moloi , Honours Project (2024), University of Cape Town
 * Adapted by: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 *
 * Status: Modified – Spring Boot use.
 * Context: Used in EXTRC project for rational closure reasoning.
 * Purpose: Educational use only.
 */

package com.extrc.controllers;

import com.extrc.models.ErrorResponse;
import com.extrc.models.KnowledgeBase;
import com.extrc.services.BaseRankService;
import com.extrc.utils.DefeasibleParser;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.tweetyproject.logics.pl.syntax.PlFormula;

import com.extrc.dtos.KnowledgeBaseDTO;

@RestController // Marks this class as a REST controller
@RequestMapping("/api") // Base URL prefix for endpoints
public class BaseRankController {

    private final BaseRankService baseRankService;

    // Constructor injection for BaseRankService
    public BaseRankController(BaseRankService baseRankService) {
        this.baseRankService = baseRankService;
    }

    // Endpoint: POST /api/base-rank
    @PostMapping("/base-rank")
    public ResponseEntity<?> getBaseRank(@RequestBody KnowledgeBaseDTO dto) {
        try {
            KnowledgeBase kb = new KnowledgeBase();
            DefeasibleParser parser = new DefeasibleParser();

            // Parse each formula from the DTO into PlFormula and add to KB
            for (String f : dto.getFormulas()) {
                PlFormula formula = parser.parseFormula(f); 
                kb.add(formula);
            }

            // Return the constructed base rank from the service
            return ResponseEntity.ok(baseRankService.constructBaseRank(kb));

        } catch (Exception e) {
            e.printStackTrace();

            // Return error response if parsing or ranking fails
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(new ErrorResponse(400, "Bad Request", "The knowledge base is invalid"));
        }
    }
}
