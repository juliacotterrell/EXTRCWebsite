/*
 * File: BaseRank.java
 * Package: com.extrc.models
 *
 * Original Author: Thabo Vincent Moloi , Honours Project (2024), University of Cape Town
 * Adapted by: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 *
 * Status: Modified – Added DTO conversion methods, error handling, and structural refinements.
 * Context: Used in EXTRC project for modelling ranked knowledge bases in Rational Closure.
 * Purpose: Educational use only.
 */

package com.extrc.models;

import com.extrc.utils.DefeasibleParser;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.extrc.dtos.RankDTO;
import com.extrc.dtos.BaseRankDTO;

/**
 * Represents the base rank of a knowledge base in rational closure reasoning.
 *
 * <p>This class maintains the knowledge base, its associated sequence,
 * the computed ranking, and the time taken to produce it. It also provides
 * methods for converting to and from data transfer objects (DTOs) for
 * serialization and transport.</p>
 */
public class BaseRank {

  // The original knowledge base
  private final KnowledgeBase knowledgeBase;

  // The computed final ranking
  @JsonManagedReference
  private Ranking ranking;

  // The sequence of ranks generated along the way
  @JsonManagedReference
  private Ranking sequence;

  // Time taken to compute the ranking
  private final double timeTaken;

  // Default constructor (builds an empty base rank)
  public BaseRank() {
    this(new KnowledgeBase(), new Ranking(), new Ranking(), 0);
  }

  // Constructor with explicit components
  public BaseRank(KnowledgeBase knowledgeBase, Ranking sequence, Ranking ranking, double timeTaken) {
    this.sequence = sequence;
    this.ranking = ranking;
    this.timeTaken = timeTaken;
    this.knowledgeBase = knowledgeBase;
  }

  // Copy constructor
  public BaseRank(BaseRank baseRank) {
    this(baseRank.getKnowledgeBase(), baseRank.getSequence(), baseRank.getRanking(), baseRank.getTimeTaken());
  }
  // --- Getters ---
  /** 
   * @return Ranking
   */
  public Ranking getRanking() {
    return new Ranking(ranking);
  }

  /** 
   * @return Ranking
   */
  public Ranking getSequence() {
    return new Ranking(sequence);
  }

  /** 
   * @return double
   */
  public double getTimeTaken() {
    return timeTaken;
  }

  /** 
   * @return KnowledgeBase
   */
  public KnowledgeBase getKnowledgeBase() {
    return new KnowledgeBase(knowledgeBase);
  }
  // --- DTO conversion ---
  /** 
   * Convert this BaseRank into a BaseRankDTO
   * @return BaseRankDTO
   */
  public BaseRankDTO toDTO() { 
    BaseRankDTO dto = new BaseRankDTO();

    dto.setKnowledgeBase(this.knowledgeBase.toStringList());
    dto.setRanking(this.ranking.stream()
        .map(Rank::toDTO)
        .toList());
    dto.setSequence(this.sequence.stream()
        .map(Rank::toDTO)
        .toList());
    dto.setTimeTaken(this.timeTaken);

    return dto;
  }

  /** 
   * Build a BaseRank object back from a BaseRankDTO
   * @param dto
   * @param parser
   * @return BaseRank
   */
  public static BaseRank fromDTO(BaseRankDTO dto, DefeasibleParser parser) {  
    KnowledgeBase kb = new KnowledgeBase();

    // Parse KB formulas
    for (String f : dto.knowledgeBase) {
        try {
            kb.add(parser.parseFormula(f));
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse formula in knowledgeBase: " + f, e);
        }
    }

    // Parse sequence ranks
    Ranking sequence = new Ranking();
    for (RankDTO rankDto : dto.sequence) {
        KnowledgeBase rankKB = new KnowledgeBase();
        for (String f : rankDto.knowledgeBase) {
            try {
                rankKB.add(parser.parseFormula(f));
            } catch (Exception e) {
                throw new RuntimeException("Failed to parse formula in sequence rank " + rankDto.rankNumber + ": " + f, e);
            }
        }
        sequence.add(new Rank(rankDto.rankNumber, rankKB));
    }

    // Parse final ranking
    Ranking ranking = new Ranking();
    for (RankDTO rankDto : dto.ranking) {
        KnowledgeBase rankKB = new KnowledgeBase();
        for (String f : rankDto.knowledgeBase) {
            try {
                rankKB.add(parser.parseFormula(f));
            } catch (Exception e) {
                throw new RuntimeException("Failed to parse formula in ranking rank " + rankDto.rankNumber + ": " + f, e);
            }
        }
        ranking.add(new Rank(rankDto.rankNumber, rankKB));
    }

    return new BaseRank(kb, sequence, ranking, dto.timeTaken);
  }
}
