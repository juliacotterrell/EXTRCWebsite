/*
 * File: TCachedEntailment.java
 * Package: com.extrc.services.entailment
 *
 * Original Author: Nevaniah (2025 Honours Project, University of Cape Town)
 * Status: Unmodified – reused in full for EXTRC.
 * Context: Incorporated into Julia Cotterrell's Honours Project (2025) as part of the EXTRC system.
 * Purpose: Educational use only.
 */

/* Originally created by Maqhobosheane Mohlerepe, changed by Nevaniah Gounden for current approach */

package com.extrc.services.entailment;

import java.util.Arrays;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.tweetyproject.logics.pl.reasoner.SatReasoner;
import org.tweetyproject.logics.pl.sat.Sat4jSolver;
import org.tweetyproject.logics.pl.sat.SatSolver;
import org.tweetyproject.logics.pl.syntax.PlBeliefSet;
import org.tweetyproject.logics.pl.syntax.PlFormula;

import com.extrc.utils.CacheUtils;
import com.extrc.utils.FormulaUtils;


public class TCachedEntailment implements EntailmentStrategy{

    // Cache to store previously computed query results
    private final Map<String, Boolean> queryCache = new ConcurrentHashMap<>();

    // Cache to store the final filtered belief set for each negated antecedent
    private final Map<String, PlBeliefSet> filteredKBCache = new ConcurrentHashMap<>();

    // Cache hit counter
    private int cacheHitCounter = 0;

    // Constructor to accept rankedKB and formula
    public TCachedEntailment() {
        // Initialize the SAT solver and reasoner
        SatSolver.setDefaultSolver(new Sat4jSolver());
    }

    /** 
     * @param rankedKB
     * @param formula
     * @param infiniteRankEmpty
     * @return boolean
     */
    @Override
    public boolean rationalQuery(PlBeliefSet[] rankedKB, PlFormula formula, boolean infiniteRankEmpty) {
        SatReasoner reasoner = new SatReasoner();
        PlFormula negation = FormulaUtils.negateAntecedent(formula);

        // Key for full-query cache
        String queryCacheKey = CacheUtils.cacheKey(rankedKB, formula);
        if (queryCache.containsKey(queryCacheKey)) {
            cacheHitCounter++;
            return queryCache.get(queryCacheKey);
        }

        String negatedAntecedentKey = CacheUtils.kbSignature(rankedKB) + "|" + negation.toString();
        PlBeliefSet cachedFilteredKB = filteredKBCache.get(negatedAntecedentKey);
        if (cachedFilteredKB != null) {
            cacheHitCounter++;
            boolean result = reasoner.query(cachedFilteredKB, formula);
            queryCache.put(queryCacheKey, result);
            return result;
        }

        // Find the highest rank to remove using ternary-like search
        int rankToRemove = findRankToRemove(rankedKB, negation);

        // Cache the filtered KB for this (KB,negation) pair
        cacheFilteredKB(rankedKB, negation, rankToRemove);

        // Evaluate the query on the surviving ranks
        boolean result;
        if (rankToRemove + 1 < rankedKB.length) {
            result = reasoner.query(combine(Arrays.copyOfRange(rankedKB, rankToRemove + 1, rankedKB.length)), formula);
        } else {
            result = true; 
        }

        // Cache and return
        queryCache.put(queryCacheKey, result);
        return result;
    }

    /** 
     * Iteratively searches to remove highest rank
     * @param rankedKB
     * @param negation
     * @return int
     */
    private int findRankToRemove(PlBeliefSet[] rankedKB, PlFormula negation) {
        SatReasoner reasoner = new SatReasoner();
        int left = 0;
        int right = rankedKB.length;

        if (right > left) {
            while (right - left > 1) {
                int mid = left + (right - left) / 3;
                int mid2 = right - (right - left) / 3;

                if (mid == 0) {
                    if (mid2 < rankedKB.length) {
                        if (reasoner.query(combine(Arrays.copyOfRange(rankedKB, mid2 + 1, rankedKB.length)),
                                negation)) {
                            left = mid2 + 1;
                        } else {
                            if (reasoner.query(combine(Arrays.copyOfRange(rankedKB, mid2, rankedKB.length)),
                                    negation)) {
                                return mid2;
                            } else {
                                right = mid2 - 1;
                            }
                        }
                    } else if (mid2 == rankedKB.length) {
                        right = mid2 - 1;
                    }
                } else {
                    if (reasoner.query(combine(Arrays.copyOfRange(rankedKB, mid, rankedKB.length)), negation)) {
                        return mid;
                    } else {
                        right = mid;
                    }
                }
            }

            int rr = Math.max(0, right - 1);
            if (!reasoner.query(combine(Arrays.copyOfRange(rankedKB, rr, rankedKB.length)), negation)) {
                rr -= 1;
            }
            return rr;
        } else {
            int rr = right == left ? right : -1;
            if (rr >= 0 && rr < rankedKB.length) {
                if (!reasoner.query(combine(Arrays.copyOfRange(rankedKB, rr, rankedKB.length)), negation)) {
                    rr -= 1;
                }
                return rr;
            }
            return -1;
        }
    }

    /** 
     * Change cache key to include KB signature as well
     * @param rankedKB
     * @param negation
     * @param rankRemove
     */
    private void cacheFilteredKB(PlBeliefSet[] rankedKB, PlFormula negation, int rankRemove) {
        String negatedAntecedentKey = CacheUtils.kbSignature(rankedKB) + "|" + negation.toString();
        PlBeliefSet finalFilteredBeliefSet = combine(Arrays.copyOfRange(rankedKB, rankRemove + 1, rankedKB.length));
        filteredKBCache.put(negatedAntecedentKey, finalFilteredBeliefSet);
    }

    /** 
     * @param ranks
     * @return PlBeliefSet
     */
    private PlBeliefSet combine(PlBeliefSet[] ranks) {
        PlBeliefSet combined = new PlBeliefSet();
        for (PlBeliefSet rank : ranks) {
            combined.addAll(rank);
        }
        return combined;
    }

    // Method to clear cache and reset cache hit counter
    public void clearCache() {
        queryCache.clear();
        filteredKBCache.clear();
        cacheHitCounter = 0; // Reset the cache hit counter
    }

    /** 
     * Getter method for cache hit counter
     * @return int
     */
    public int getCacheHitCounter() {
        return cacheHitCounter;
    }
}
