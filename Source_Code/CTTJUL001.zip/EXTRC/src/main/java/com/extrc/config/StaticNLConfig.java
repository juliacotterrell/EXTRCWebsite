// com.extrc.config.StaticNLConfig.java
/*
 * File: StaticNLConfig.java
 * Package: com.extrc.config
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Developed for EXTRC project to serve static natural language files.
 * Purpose: Educational use only.
 */

package com.extrc.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.CacheControl;
import org.springframework.web.servlet.config.annotation.*;

import java.util.concurrent.TimeUnit;

@Configuration // Marks this as a Spring configuration class
public class StaticNLConfig implements WebMvcConfigurer {

  @Override
  public void addResourceHandlers(ResourceHandlerRegistry registry) {
    // Map requests to /api/nl/** to static files inside classpath:/nl/
    registry.addResourceHandler("/api/nl/**")
      .addResourceLocations("classpath:/nl/")
      // Cache the static resources for 30 days
      .setCacheControl(CacheControl.maxAge(30, TimeUnit.DAYS).cachePublic());
  }
}
