/*
 * File: MultiStrategyEntailment.java
 * Package: com.extrc.services.entailment
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work. * Purpose: Educational use only.
 */

package com.extrc.services.entailment;

import java.util.LinkedHashMap;
import java.util.Map;

import org.tweetyproject.logics.pl.syntax.PlBeliefSet;
import org.tweetyproject.logics.pl.syntax.PlFormula;

/**
 * Runs multiple strategies on the same query and compares results.
 */
public class MultiStrategyEntailment implements EntailmentStrategy {
  private final EntailmentStrategy[] strategies;
  private final Map<String, Double> lastTimes = new LinkedHashMap<>();

  public MultiStrategyEntailment(EntailmentStrategy... strategies) {
    this.strategies = strategies;
  }

  /** 
   * @param rankedKB
   * @param formula
   * @param infiniteRankEmpty
   * @return boolean
   */
  @Override
  public boolean rationalQuery(PlBeliefSet[] rankedKB, PlFormula formula, boolean infiniteRankEmpty) {
    lastTimes.clear();
    Boolean reference = null;
    boolean consistent = true;

    for (EntailmentStrategy s : strategies) {
      String name = s.getClass().getSimpleName();
      long start = System.nanoTime();
      boolean result = s.rationalQuery(rankedKB, formula, infiniteRankEmpty);
      long end = System.nanoTime();
      double ms = (end - start) / 1_000_000.0;
      lastTimes.put(name, ms);

      if (reference == null) reference = result;
      else if (reference != result) consistent = false;
    }

    if (!consistent) {
      System.err.println("[MultiStrategy] Inconsistent results for: " + formula);
    }
    return reference != null && reference;
  }

  /** 
   * @return Map<String, Double>
   */
  public Map<String, Double> getLastTimes() {
    return lastTimes;
  }
}
