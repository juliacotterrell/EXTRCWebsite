/*
 * File: FormulaController.java
 * Package: com.extrc.controllers
 *
 * Original Author: Thabo Vincent Moloi , Honours Project (2024), University of Cape Town
 * Adapted by: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 *
 * Status: Modified – Spring Boot use.
 * Context: Used in EXTRC project for rational closure reasoning.
 * Purpose: Educational use only.
 */

package com.extrc.controllers;

import com.extrc.services.FormulaService;
import com.extrc.utils.DefeasibleParser;
import com.extrc.utils.FormulaParseException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.tweetyproject.logics.pl.syntax.PlFormula;

import java.util.Map;

@RestController // Marks this as a REST controller
@RequestMapping("/api/formula") // Base URL for formula endpoints
public class FormulaController {

  private final DefeasibleParser parser;
  private final FormulaService formulaService;

  // Constructor injection of parser and service
  public FormulaController(DefeasibleParser parser, FormulaService formulaService) {
    this.parser = parser;
    this.formulaService = formulaService;
  }

  // Endpoint: GET /api/formula/render
  @GetMapping("/render")
  public ResponseEntity<?> render(
      @RequestParam String formula,                   // input formula as string
      @RequestParam(defaultValue="false") boolean explain, // flag: explain or raw
      @RequestParam(defaultValue="0") int rank) {     // optional rank parameter

        final PlFormula pf;
        try {
            // Try parsing the input string into a PlFormula
            pf = parser.parseFormula(formula);
        } catch (Exception e) {
            // Throw custom exception if parsing fails
            throw new FormulaParseException("Could not parse formula: " + formula, e);
        }

        // If explanation not requested, return raw formula string
        if (!explain) {
          return ResponseEntity.ok(Map.of("raw", pf.toString()));
        }

        // Otherwise, return rendered formula with explanation at given rank
        return ResponseEntity.ok(formulaService.renderFormula(pf, rank));
  }
}
