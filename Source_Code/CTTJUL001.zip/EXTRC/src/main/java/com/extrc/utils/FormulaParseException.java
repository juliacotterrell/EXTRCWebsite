/* 
 * File: FormulaParseException.java
 * Package: com.extrc.utils
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Developed for EXTRC project to deal with exceptions for parse defeasible formulas.
 * Purpose: Educational use only.
 */
package com.extrc.utils;

public class FormulaParseException extends RuntimeException{
    public FormulaParseException(String message, Throwable cause) {
    super(message, cause);
    }
}
