/*
 * File: RationalReasonerImpl.java
 * Package: com.extrc.services
 *
 * Original Author: Thabo Vincent Moloi , Honours Project (2024), University of Cape Town
 * Adapted by: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 *
 * Status: Modified – Springboot use.
 * Context: Used in EXTRC project for rational closure reasoning.
 * Purpose: Educational use only.
 */
package com.extrc.services;

import org.tweetyproject.logics.pl.reasoner.SatReasoner;
import org.tweetyproject.logics.pl.sat.Sat4jSolver;
import org.tweetyproject.logics.pl.sat.SatSolver;
import org.tweetyproject.logics.pl.syntax.Implication;
import org.tweetyproject.logics.pl.syntax.Negation;
import org.tweetyproject.logics.pl.syntax.PlBeliefSet;
import org.tweetyproject.logics.pl.syntax.PlFormula;

import com.extrc.models.BaseRank;
import com.extrc.models.Entailment;
import com.extrc.models.KnowledgeBase;
import com.extrc.models.Ranking;
import com.extrc.models.RationalEntailment;
import com.extrc.services.entailment.BCachedEntailment;
import com.extrc.services.entailment.BinaryEntailment;
import com.extrc.services.entailment.EntailmentStrategy;
import com.extrc.services.entailment.HybridEntailment;
import com.extrc.services.entailment.MultiStrategyEntailment;
import com.extrc.services.entailment.NaiveEntailment;
import com.extrc.services.entailment.SatEntailment;
import com.extrc.services.entailment.TernaryEntailment;

public class RationalReasonerImpl implements ReasonerService {

  private final EntailmentStrategy strategy;

  public RationalReasonerImpl() {
    SatSolver.setDefaultSolver(new Sat4jSolver());

    this.strategy = new MultiStrategyEntailment(
        new BinaryEntailment(),
        new BCachedEntailment(),
        new HybridEntailment(),
        new NaiveEntailment(),
        new TernaryEntailment(),
        new SatEntailment()
    );
  }

  /** 
   * @param baseRank
   * @param queryFormula
   * @return Entailment
   */
  @Override
  public Entailment getEntailment(BaseRank baseRank, PlFormula queryFormula) {
    long startTime = System.nanoTime();

    // Inputs
    KnowledgeBase knowledgeBase = baseRank.getKnowledgeBase();
    Ranking       baseRanking   = baseRank.getRanking();

    // --- Compute removedRanking using the classic RC "union vs ¬antecedent" pass ---
    Ranking        removedRanking = new Ranking();
    KnowledgeBase  union          = new KnowledgeBase();
    baseRanking.forEach(rank -> union.addAll(rank.getFormulas()));

    // Negation of the antecedent α of (α ~> β)
    PlFormula negation = new Negation(((Implication) queryFormula).getFirstFormula());
    SatReasoner reasoner = new SatReasoner();

    int i = 0;
    while (!union.isEmpty() && reasoner.query(union, negation) && i < baseRanking.size() - 1) {
      // remove the current (lowest) rank that causes α to be exceptional
      removedRanking.add(baseRanking.get(i));
      union.removeAll(baseRanking.get(i).getFormulas());
      i++;
    }

    // --- Build rankedKB for the strategy runner ---
    PlBeliefSet[] rankedKB = toPlBeliefSetArray(baseRanking);
    boolean infiniteRankEmpty = rankedKB.length == 0 || rankedKB[rankedKB.length - 1].isEmpty();

    // --- Delegate to the multi-strategy engine for the final RC entailment verdict ---
    boolean entailed = strategy.rationalQuery(rankedKB, queryFormula, infiniteRankEmpty);

    long endTime = System.nanoTime();

    // --- Build response (include removedRanking + per-strategy timings when available) ---
    RationalEntailment.RationalEntailmentBuilder builder =
        new RationalEntailment.RationalEntailmentBuilder()
            .withKnowledgeBase(knowledgeBase)
            .withQueryFormula(queryFormula)
            .withBaseRanking(baseRanking)
            .withRemovedRanking(removedRanking)
            .withEntailed(entailed)
            .withTimeTaken((endTime - startTime) / 1_000_000_000.0);

    if (strategy instanceof MultiStrategyEntailment multi) {
      builder.withStrategyTimes(multi.getLastTimes());
    }

    return builder.build();
  }
  /** 
   * @param ranking
   * @return PlBeliefSet[]
   */
  private PlBeliefSet[] toPlBeliefSetArray(Ranking ranking) {
    return ranking.stream().map(rank -> {
      PlBeliefSet set = new PlBeliefSet();
      set.addAll(rank.getFormulas()); 
      return set;
    }).toArray(PlBeliefSet[]::new);
  }
}
