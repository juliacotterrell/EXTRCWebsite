/*
 * File: EntailmentStrategy.java
 * Package: com.extrc.services.entailment
 *
 * Original Author: Nevaniah (2025 Honours Project, University of Cape Town)
 * Status: Modified – [brief note, e.g., “Spring Boot integration”]
 *  Adapted by: Julia Cotterrell (2025 Honours Project, UCT)
 * Purpose: Educational use only.
 */

package com.extrc.services.entailment;

import org.tweetyproject.logics.pl.reasoner.SatReasoner;
import org.tweetyproject.logics.pl.sat.Sat4jSolver;
import org.tweetyproject.logics.pl.syntax.PlBeliefSet;
import org.tweetyproject.logics.pl.syntax.PlFormula;

public interface EntailmentStrategy {
    default SatReasoner getReasoner() {
        Sat4jSolver.setDefaultSolver(new Sat4jSolver());
        return new SatReasoner();
    }

    default boolean query(PlBeliefSet kb, PlFormula phi) {
        return getReasoner().query(kb, phi);
    }

    /** Rational-closure entailment: classes override this if they have a faster algorithm. */
    default boolean rationalQuery(PlBeliefSet[] rankedKB, PlFormula phi, boolean infiniteRankEmpty) {
        PlBeliefSet combined = new PlBeliefSet();
        for (PlBeliefSet r : rankedKB) combined.addAll(r);
        return query(combined, phi);
    }
}
