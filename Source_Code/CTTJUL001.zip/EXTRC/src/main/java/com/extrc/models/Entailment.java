/*
 * File: Entailment.java
 * Package: com.extrc.models
 *
 * Original Author: Thabo Vincent Moloi , Honours Project (2024), University of Cape Town
 * Adapted by: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 *
 * Status: Modified – Spring Boot use.
 * Context: Used in EXTRC project for rational closure reasoning.
 * Purpose: Educational use only.
 */

package com.extrc.models;

import java.util.LinkedHashMap;
import java.util.Map;

import org.tweetyproject.logics.pl.syntax.Implication;
import org.tweetyproject.logics.pl.syntax.Negation;
import org.tweetyproject.logics.pl.syntax.PlFormula;

// Abstract base class for all Entailment results
public abstract class Entailment {

  // The knowledge base used for the entailment check
  protected final KnowledgeBase knowledgeBase;

  // The query formula being tested
  protected final PlFormula queryFormula;

  // The base ranking of the knowledge base
  protected final Ranking baseRanking;

  // Whether the query is entailed or not
  protected final boolean entailed;

  // Time taken to compute the entailment
  protected final double timeTaken;

  // Ranking of formulas that were removed during reasoning
  protected final Ranking removedRanking;

  // Execution times of different strategies (if applicable)
  protected final Map<String, Double> strategyTimes;

  // Constructor using the builder pattern
  protected Entailment(EntailmentBuilder<?> builder) {
    this.knowledgeBase = builder.knowledgeBase;
    this.queryFormula = builder.queryFormula;
    this.baseRanking = builder.baseRanking;
    this.entailed = builder.entailed;
    this.timeTaken = builder.timeTaken;
    this.removedRanking = builder.removedRanking;
    this.strategyTimes = builder.strategyTimes;
  }
  // --- Getters ---
  /** 
   * @return KnowledgeBase
   */
  public KnowledgeBase getKnowledgeBase() {
    return knowledgeBase;
  }

  /** 
   * @return PlFormula
   */
  public PlFormula getQueryFormula() {
    return queryFormula;
  }

  /** 
   * Returns the negation of the query
   * @return PlFormula
   */
  public PlFormula getNegation() {
    return queryFormula == null ? null : new Negation(((Implication) queryFormula).getFirstFormula());
  }

  /** 
   * @return Ranking
   */
  public Ranking getRemovedRanking() {
    return removedRanking;
  }

  /** 
   * @return Ranking
   */
  public Ranking getBaseRanking() {
    return baseRanking;
  }

  /** 
   * @return boolean
   */
  public boolean getEntailed() {
    return entailed;
  }

  /** 
   * @return double
   */
  public double getTimeTaken() {
    return timeTaken;
  }

  /** 
   * @return Map<String, Double>
   */
  // Returns execution times for different strategies
  public Map<String, Double> getStrategyTimes() {
    return strategyTimes;
  }

  // --- Builder for Entailment ---
  public static abstract class EntailmentBuilder<T extends EntailmentBuilder<T>> {

    private KnowledgeBase knowledgeBase;
    private PlFormula queryFormula;
    private Ranking baseRanking;
    private boolean entailed;
    private double timeTaken;
    private Ranking removedRanking;
    protected Map<String, Double> strategyTimes = new LinkedHashMap<>();

    public T withRemovedRanking(Ranking removedRanking) {
      this.removedRanking = removedRanking;
      return self();
    }

    public T withKnowledgeBase(KnowledgeBase knowledgeBase) {
      this.knowledgeBase = knowledgeBase;
      return self();
    }

    public T withQueryFormula(PlFormula queryFormula) {
      this.queryFormula = queryFormula;
      return self();
    }

    public T withBaseRanking(Ranking baseRanking) {
      this.baseRanking = baseRanking;
      return self();
    }

    public T withEntailed(boolean entailed) {
      this.entailed = entailed;
      return self();
    }

    public T withTimeTaken(double timeTaken) {
      this.timeTaken = timeTaken;
      return self();
    }

    public T withStrategyTimes(Map<String, Double> strategyTimes) {
      if (strategyTimes != null) {
        this.strategyTimes = new LinkedHashMap<>(strategyTimes);
      }
      return self();
    }

    protected abstract T self();
    public abstract Entailment build();
  }
}
