/*
 * File: ErrorResponse.java
 * Package: com.extrc.models
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Used in EXTRC project to send structured error messages in API responses.
 * Purpose: Educational use only.
 */

package com.extrc.models;

// model for returning error details in API responses
public class ErrorResponse {

  // HTTP status code
  public final int code;

  // description of the error type
  public final String description;

  // Detailed error message
  public final String message;

  // Constructor
  public ErrorResponse(int code, String description, String message) {
    this.code = code;
    this.description = description;
    this.message = message;
  }
}
