/*
 * File: MemoizingEntailment.java
 * Package: com.extrc.services.entailment
 *
 * Original Author: Nevaniah (2025 Honours Project, University of Cape Town)
 * Status: Unmodified – reused in full for EXTRC.
 * Context: Incorporated into Julia Cotterrell's Honours Project (2025) as part of the EXTRC system.
 * Purpose: Educational use only.
 */

package com.extrc.services.entailment;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.tweetyproject.logics.pl.syntax.PlBeliefSet;
import org.tweetyproject.logics.pl.syntax.PlFormula;

public class MemoizingEntailment implements EntailmentStrategy {
    private final EntailmentStrategy inner;
    private final Map<String, Boolean> rcCache = new ConcurrentHashMap<>();

    public MemoizingEntailment(EntailmentStrategy inner) {
        this.inner = inner;
    }

    /** 
     * @param rankedKB
     * @param phi
     * @param inf
     * @return boolean
     */
    @Override
    public boolean rationalQuery(PlBeliefSet[] rankedKB, PlFormula phi, boolean inf) {
        int h=1; for (PlBeliefSet r: rankedKB) h=31*h+r.hashCode();
        String key = h+"|"+phi.hashCode()+"|"+inf;
        return rcCache.computeIfAbsent(key, k -> inner.rationalQuery(rankedKB, phi, inf));
    }
}
