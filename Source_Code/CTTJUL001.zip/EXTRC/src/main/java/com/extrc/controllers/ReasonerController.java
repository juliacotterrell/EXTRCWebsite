/*
 * File: ReasonerController.java
 * Package: com.extrc.controllers
 *
 * Original Author: Thabo Vincent Moloi , Honours Project (2024), University of Cape Town
 * Adapted by: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 *
 * Status: Modified – Spring Boot use.
 * Context: Used in EXTRC project for rational closure reasoning.
 * Purpose: Educational use only.
 */

package com.extrc.controllers;

import com.extrc.dtos.BaseRankDTO;
import com.extrc.models.BaseRank;
import com.extrc.models.ErrorResponse;
import com.extrc.models.KnowledgeBase;
import com.extrc.models.Entailment;
import com.extrc.services.ReasonerFactory;
import com.extrc.services.ReasonerService;
import com.extrc.services.BaseRankService;
import com.extrc.utils.DefeasibleParser;

import org.tweetyproject.logics.pl.syntax.PlFormula;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;

@RestController // Marks this as a REST controller
@RequestMapping("/api/entailment") // Base URL for entailment endpoints
public class ReasonerController {

    private final ReasonerFactory   reasonerFactory;
    private final DefeasibleParser  parser;
    private final BaseRankService   baseRankService;

    // Constructor injection of dependencies
    public ReasonerController(ReasonerFactory reasonerFactory,
                              DefeasibleParser parser,
                              BaseRankService baseRankService) {
        this.reasonerFactory = reasonerFactory;
        this.parser          = parser;
        this.baseRankService = baseRankService;
    }

    // Endpoint: POST /api/entailment/{reasoner}/{queryFormula}
    @PostMapping("/{reasoner}/{queryFormula}")
    public ResponseEntity<?> getEntailment(
            @PathVariable String reasoner,           // chosen reasoner type
            @PathVariable String queryFormula,       // query formula as string
            @RequestBody BaseRankDTO dto) {          // KB provided in body

        // 1) Build the KnowledgeBase from the request body
        KnowledgeBase kb;
        try {
            String joined = String.join("\n", dto.knowledgeBase);
            ByteArrayInputStream in = new ByteArrayInputStream(
                joined.getBytes(StandardCharsets.UTF_8)
            );
            kb = parser.parseInputStream(in);
        } catch (Exception e) {
            return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(new ErrorResponse(
                    HttpStatus.BAD_REQUEST.value(),
                    "Bad Request",
                    "Invalid request body or knowledge base"
                ));
        }

        // 2) Construct the base rank model from the KB
        BaseRank baseRank = baseRankService.constructBaseRank(kb);

        // 2b) Resolve the requested reasoner
        ReasonerService svc;
        try {
            svc = reasonerFactory.createReasoner(reasoner);
        } catch (IllegalArgumentException e) {
            ErrorResponse err = new ErrorResponse(
                HttpStatus.BAD_REQUEST.value(),
                "Bad Request",
                "Invalid reasoner: " + reasoner
            );
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(err);
        }

        // 3) Parse the query formula string into PlFormula
        PlFormula formula;
        try {
            formula = parser.parseFormula(queryFormula);
        } catch (Exception e) {
            ErrorResponse err = new ErrorResponse(
                HttpStatus.BAD_REQUEST.value(),
                "Bad Request",
                "Invalid query formula: " + queryFormula
            );
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(err);
        }

        // 4) Get the entailment result using the reasoner
        Entailment result = svc.getEntailment(baseRank, formula);
        System.out.println("Entailment result: " + result);

        // 5) Return result to the client
        return ResponseEntity.ok(result);
    }
}
