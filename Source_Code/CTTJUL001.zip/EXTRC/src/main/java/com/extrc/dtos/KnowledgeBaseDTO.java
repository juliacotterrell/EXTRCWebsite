/*
 * File: KnowledgeBaseDTO.java
 * Package: com.extrc.dtos
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Developed for EXTRC project to support rational closure reasoning
 * and encrypted communication.
 * Purpose: Educational use only.
 */

package com.extrc.dtos;

import java.util.List;

// Data Transfer Object (DTO) for carrying a knowledge base between backend and frontend
public class KnowledgeBaseDTO {

    // List of formulas in the knowledge base
    private List<String> formulas;

    // Default constructor
    public KnowledgeBaseDTO() {
    }

    // Constructor with formulas
    public KnowledgeBaseDTO(List<String> formulas) {
        this.formulas = formulas;
    }
    // --- Getters and setters ---
    /** 
     * @return List<String>
     */
    public List<String> getFormulas() {
        return formulas;
    }

    /** 
     * @param formulas
     */
    public void setFormulas(List<String> formulas) {
        this.formulas = formulas;
    }
}
