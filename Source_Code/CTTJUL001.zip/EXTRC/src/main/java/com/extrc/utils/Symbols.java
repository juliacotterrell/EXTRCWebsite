/*
 * File: Symbols.java
 * Package: com.extrc.utils
 *
 * Original Author: Thabo Vincent Moloi (2024), Honours Project, University of Cape Town
 * Status: Reused unchanged in this project.
 * Context: Incorporated into Julia Cotterrell's Honours Project (2025).
 * Purpose: Educational use only.
 */package com.extrc.utils;

public final class Symbols {

  /** 
   * @return String
   */
  public static String IMPLICATION() {
    return "=>";
  }

  /** 
   * @return String
   */
  public static String DISJUNCTION() {
    return "||";
  }

  /** 
   * @return String
   */
  public static String CONJUNCTION() {
    return "&&";
  }

  /** 
   * @return String
   */
  public static String EQUIVALENCE() {
    return "<=>";
  }

  /** 
   * @return String
   */
  public static String NEGATION() {
    return "!";
  }

  /** 
   * @return String
   */
  public static String DEFEASIBLE_IMPLICATION() {
    return "~>";
  }
}