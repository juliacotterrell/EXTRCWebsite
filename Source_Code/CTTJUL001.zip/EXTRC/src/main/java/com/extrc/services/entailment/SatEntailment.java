/*
 * File: SatEntailment.java
 * Package: com.extrc.services.entailment
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Purpose: Educational use only.
 */

package com.extrc.services.entailment;

import org.tweetyproject.logics.pl.reasoner.SatReasoner;
import org.tweetyproject.logics.pl.syntax.PlBeliefSet;
import org.tweetyproject.logics.pl.syntax.PlFormula;

public class SatEntailment implements EntailmentStrategy {

    private final SatReasoner reasoner = new SatReasoner();

    /** 
     * @param rankedKB
     * @param formula
     * @param infiniteRankEmpty
     * @return boolean
     */
    @Override
    public boolean rationalQuery(PlBeliefSet[] rankedKB, PlFormula formula, boolean infiniteRankEmpty) {
        // collapses all ranks into one belief set
        PlBeliefSet merged = new PlBeliefSet();
        for (PlBeliefSet rank : rankedKB) {
            if (rank != null) {
                merged.addAll(rank);
            }
        }
        return reasoner.query(merged, formula);
    }
}
