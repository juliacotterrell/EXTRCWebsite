/*
 * File: Ranking.java
 * Package: com.extrc.models
 *
 * Original Author: Thabo Vincent Moloi , Honours Project (2024), University of Cape Town
 * Adapted by: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 *
 * Status: Modified – Spring Boot use.
 * Context: Used in EXTRC project for rational closure reasoning.
 * Purpose: Educational use only.
 */

package com.extrc.models;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import com.extrc.dtos.RankingDTO;
import com.extrc.dtos.RankDTO;
import com.extrc.utils.DefeasibleParser;

/**
 * Represents a ranking of knowledge bases ordered by priority (rank number).
 * Each entry in the ranking corresponds to one rank level of formulas.
 *
 * Extends ArrayList<Rank> for convenience, while adding domain-specific methods.
 */
public class Ranking extends ArrayList<Rank> {

    // --- Constructors ---

    // Default constructor: empty ranking
    public Ranking() {
        super();
    }

    // Construct a ranking from a collection of ranks (supports JSON deserialization)
    @JsonCreator
    public Ranking(@JsonProperty("ranking") Collection<? extends Rank> ranks) {
        super(ranks);
    }
    // --- Domain-specific methods ---

    /** 
     * Add a new rank to the ranking
     * 
     * @param rankNumber
     * @param knowledgeBase
     */
    public void addRank(int rankNumber, KnowledgeBase knowledgeBase) {
        this.add(new Rank(rankNumber, knowledgeBase));
    }

    /** 
     * Get the rank with the given rank number
     * If rankNumber == Integer.MAX_VALUE, return the last rank
     * 
     * @param rankNumber
     * @return Rank
     */
    public Rank getRank(int rankNumber) {
        if (rankNumber == Integer.MAX_VALUE && !this.isEmpty()) {
            return this.get(this.size() - 1);
        }
        return this.get(rankNumber);
    }

    /** 
     * Convert this Ranking into a RankingDTO
     * @return RankingDTO
     */
    public RankingDTO toDTO() {
        return new RankingDTO(this.stream()
            .map(Rank::toDTO)
            .collect(Collectors.toList()));
    }

    /** 
     * Build a Ranking object back from a RankingDTO
     * @param dto
     * @param parser
     * @return Ranking
     */
    public static Ranking fromDTO(RankingDTO dto, DefeasibleParser parser) {
        Ranking ranking = new Ranking();
        for (RankDTO rankDto : dto.ranks) {
            KnowledgeBase kb = new KnowledgeBase();
            for (String f : rankDto.knowledgeBase) {
                try {
                    kb.add(parser.parseFormula(f));
                } catch (Exception e) {
                    throw new RuntimeException("Failed to parse formula", e);
                }
            }
            ranking.add(new Rank(rankDto.rankNumber, kb));
        }
        return ranking;
    }

    /** 
     * Expose ranks for serialization
     * @return List<Rank>
     */
    @JsonProperty("ranking")
    public List<Rank> getRanks() {
        return this;
    }
}
