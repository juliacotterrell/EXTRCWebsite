/*
 * File: BaseRankService.java
 * Package: com.extrc.services
 *
 * Original Author: Thabo Vincent Moloi , Honours Project (2024), University of Cape Town
 * Adapted by: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 *
 * Status: Modified – Springboot use.
 * Context: Used in EXTRC project for rational closure reasoning.
 * Purpose: Educational use only.
 */
package com.extrc.services;

import com.extrc.models.BaseRank;
import com.extrc.models.KnowledgeBase;

public interface BaseRankService {
  public BaseRank constructBaseRank(KnowledgeBase knowledgeBase);
}
