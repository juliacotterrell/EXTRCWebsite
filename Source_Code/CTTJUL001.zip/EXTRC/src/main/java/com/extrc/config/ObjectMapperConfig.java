
/*
 * File: ObjectMapperConfig.java
 * Package: com.extrc.config
 *
 * Author: Julia Cotterrell (2025 Honours Project, University of Cape Town)
 * Status: Original work.
 * Context: Developed for EXTRC project to support rational closure reasoning
 * and encrypted communication.
 * Purpose: Educational use only.
 */

package com.extrc.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import org.tweetyproject.logics.pl.syntax.PlFormula;
import com.extrc.serializers.FormulaSerializer;
import com.extrc.serializers.FormulaDeserializer;

@Configuration // Marks this as a Spring configuration class
public class ObjectMapperConfig {

    @Bean // Exposes a customized ObjectMapper bean for the whole app
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();

        // Create a module to handle PlFormula serialization/deserialization
        SimpleModule module = new SimpleModule();
        module.addSerializer(PlFormula.class, new FormulaSerializer());
        module.addDeserializer(PlFormula.class, new FormulaDeserializer());

        // Register the module with the mapper
        mapper.registerModule(module);

        // Return the configured ObjectMapper
        return mapper;
    }
}
