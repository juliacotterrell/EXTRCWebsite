# EXTRC

**EXTRC** is a web-based tool for exploring **entailment** and **ranking** of logical propositions under **rational closure**.  
It provides an interactive frontend for entering knowledge bases, querying entailments, and visualising reasoning steps.

**Live App:** [extrc.vercel.app](https://extrc.vercel.app)  
> **Note:** The backend runs on a free Render instance. If inactive, the first request may take over **50 seconds** to respond while it spins up. Subsequent requests are fast.

---

## Overview

- **Frontend:** TypeScript, React, Vite – deployed on **Vercel**.
- **Backend:** Java Spring Boot – deployed on **Render**. Uses the **Tweety Project** for reasoning with SAT solvers.
- **Reasoning Models:**  
  - **Rational Closure**  

---

## Features

- Input a **Knowledge Base (KB)** of logical formulas
- Test **entailment** of queries under rational closure
- Inspect the **base ranking** of formulas
- View which formulas are removed during reasoning
- Step-by-step explanations with **natural language support**
- Clear, interactive UI designed for **education** and **debugging**

---

## Quick Start

### Run Online
No installation required — open:  
[https://extrc.vercel.app](https://extrc.vercel.app)

---

### Run Locally

#### Backend
```bash
mvn spring-boot:run
```

#### Frontend
```bash

cd src/ui
npm install
npm run dev
```

## Features
- Enter a **Knowledge Base** (set of logical formulas)
- Query for **entailment** under:
  - **Rational closure**
- View **base ranking** of formulas
- See which formulas are removed during reasoning

---

## Example Usage

### Example Knowledge Base
```text
(p => b)
(b ~> f)
(b ~> w)
(p ~> !f)
```
### Example Queries
```text
p ~> b
p ~> w
b ~> f
```
```bash
+------------------+           +------------------------+           +-----------------------+
|    Frontend      |  HTTP/JSON|        Backend          |  Java API |  SAT Reasoning Engine |
|  (React + Vite)  +-----------> (Spring Boot REST API)  +-----------> (TweetyProject + SAT4j)|
|  Hosted: Vercel  |           |  Hosted: Render         |           |  Logical Entailment   |
+------------------+           +------------------------+           +-----------------------+
```
1. User enters KB + query in browser
2. Frontend sends request to backend API
3. Backend passes KB/query to SAT Reasoner
4. SAT Reasoner returns entailment results
5. Backend sends results to frontend for display

## Screenshots

### Knowledge Base & Query Input
![Knowledge Base Input](docs/screenshots/input.png)

### Summary Entailment Results
![Entailment Results](docs/screenshots/summary.png)

### Base Ranking Explorer
![Base Ranking Panel](docs/screenshots/BaseRankExplorer.png)

### Natural Language Explanations for Rational Closure
![Natural Language Output](docs/screenshots/RatClosureExplained.png)

## Troubleshooting

**Note:** The backend is hosted on a free service (Render). After a period of inactivity it may “go to sleep,” which can cause the front end to appear unresponsive at first.

If this happens:

1. Open the backend link once in your browser: [https://extrc-1.onrender.com](https://extrc-1.onrender.com)  
    (Wait until the **Reasoner API** page loads.)
2. Return to the front end: [https://extrc.vercel.app](https://extrc.vercel.app)  
3. Refresh the page. This should make the app work.



## Credits
- **Thabo Vincent Moloi** – Honours Project (2024), University of Cape Town, Extending Defeasibility Beyond Rational Closure (earlier Defeasible Reasoning User Interface work built on here)
- **Tweety Project** – Open-source Java framework for logical aspects of artificial intelligence
- **Nevaniah Gounden** – Honours Project (2025), University of Cape Town, Investigation of optimisation techniques for Rational Closure in Defeasible Reasoning(2025)  
- **Jethro Dunn** – Honours Project (2025), University of Cape Town, Implementing Natural Language Into Knowledge Base Generation (2025)  
